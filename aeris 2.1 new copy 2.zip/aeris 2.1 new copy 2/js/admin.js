/**
 * admin.js - Specific logic for admin dashboard, reports, recurring issues, and QR management
 */

function injectAdminEmergencyModal() {
    if (document.getElementById('admin-critical-modal')) return;
    const html = `
    <!-- Critical Login Modal -->
    <div id="admin-critical-modal" class="modal-overlay hidden" style="z-index: 9999; background: rgba(32, 38, 111, 0.85); backdrop-filter: blur(8px);">
        <div class="modal-content centered-modal" style="border: 4px solid var(--status-poor); max-width: 600px; padding: 48px 32px; box-shadow: 0 24px 48px rgba(240, 107, 103, 0.25);">
            <div style="color: var(--status-poor); font-size: 3rem; margin-bottom: 16px;">🚨</div>
            <h2 style="color: var(--status-poor); text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">Critical Emergency</h2>
            <div id="crit-modal-issue" style="font-size: 1.5rem; font-weight: 700; margin-bottom: 16px; text-transform: uppercase;"></div>
            
            <div style="background: var(--bg-color); border-radius: var(--radius-sm); padding: 24px; margin-bottom: 32px; text-align: left;">
                <div class="sd-row"><span>Location:</span> <strong id="crit-modal-loc" style="font-size:1.125rem;"></strong></div>
                <div class="sd-row"><span>Reported:</span> <strong id="crit-modal-time"></strong></div>
                <div class="sd-row"><span>Description:</span> <strong id="crit-modal-desc"></strong></div>
                <p style="color: var(--status-poor); font-weight: 600; margin-top: 16px; text-align: center;">Immediate attention required.</p>
            </div>
            
            <div style="display: flex; gap: 16px; justify-content: center;">
                <button class="btn btn-secondary full-width" onclick="dismissCriticalAlert()" style="font-size: 1.125rem;">DISMISS</button>
                <button class="btn btn-primary full-width" onclick="handleCriticalAlertNow()" style="background: var(--status-poor); font-size: 1.125rem;">HANDLE NOW</button>
            </div>
        </div>
    </div>
    
    <!-- Shared Report Detail Modal -->
    <div id="admin-report-detail-modal" class="modal-overlay hidden" style="z-index: 3000;">
        <div class="modal-content centered-modal admin-detail-modal" style="max-width: 620px; text-align:left;">
            <button class="close-btn" onclick="document.getElementById('admin-report-detail-modal').classList.add('hidden')">×</button>
            <div id="admin-rd-content"></div>
        </div>
    </div>

    <!-- Admin Room QR Placard Modal -->
    <div id="admin-qr-modal" class="modal-overlay hidden" style="z-index: 3100;">
        <div class="modal-content centered-modal" style="max-width: 440px; text-align: center;">
            <button class="close-btn" onclick="document.getElementById('admin-qr-modal').classList.add('hidden')">×</button>
            
            <div id="admin-printable-placard" style="background:white; padding:24px; border-radius:16px; border:2px solid var(--deep-navy); color:#20266F; margin-bottom:20px;">
                <div style="border-bottom:2px solid var(--soft-lavender); padding-bottom:12px; margin-bottom:14px;">
                    <div style="font-size:0.75rem; font-weight:800; letter-spacing:2px; color:var(--primary-blue);">UNIVERSITAS MULTIMEDIA NUSANTARA</div>
                    <h2 id="admin-qr-room-name" style="font-size:1.45rem; font-weight:800; color:var(--deep-navy); margin:4px 0 0;">Room Name</h2>
                    <div id="admin-qr-room-code" style="font-size:1rem; font-weight:700; color:var(--primary-blue); letter-spacing:1px;">CODE: A101</div>
                </div>

                <div id="admin-qr-svg-container" style="margin:16px auto; width:180px; height:180px; display:flex; justify-content:center; align-items:center;"></div>

                <div style="font-size:0.75rem; color:#64748B; line-height:1.4; max-width:280px; margin:0 auto;">
                    <strong>Door Identification &amp; Maintenance Tag</strong><br>
                    Scan to access live environmental quality, verify facility issues, or submit maintenance requests.
                </div>
            </div>

            <div class="flex-row" style="gap:8px; flex-wrap:wrap;">
                <button class="btn btn-secondary full-width" onclick="window.print()" style="flex:1; min-width:110px;">🖨️ Print</button>
                <button class="btn btn-primary full-width" onclick="downloadAdminQR()" style="flex:1; min-width:110px;">⬇️ PNG</button>
                <button class="btn btn-outline full-width" onclick="downloadAdminQRSvg()" style="flex:1; min-width:110px;">⬇️ SVG</button>
            </div>
        </div>
    </div>
    `;
    document.body.insertAdjacentHTML('beforeend', html);
}

let currentCriticalId = null;

function checkCriticalLogin() {
    const isNewLogin = localStorage.getItem('aeris_admin_login_flag') === 'true';
    const activeCrits = window.reports.filter(r => (r.priority === 'CRITICAL' || r.status === 'Critical') && r.status !== 'Resolved');
    
    if (isNewLogin && activeCrits.length > 0) {
        const c = activeCrits[0];
        currentCriticalId = c.id;
        document.getElementById('crit-modal-issue').innerText = c.issue;
        document.getElementById('crit-modal-loc').innerText = `${c.location.building} — Floor ${c.location.floor} — ${c.location.room}`;
        
        let timeStr = 'Just now';
        try {
            const msDiff = Date.now() - new Date(c.timestamp).getTime();
            if (msDiff > 60000) timeStr = Math.floor(msDiff / 60000) + ' mins ago';
        } catch(e) {}
        
        document.getElementById('crit-modal-time').innerText = timeStr;
        document.getElementById('crit-modal-desc').innerText = c.description || 'No additional details';
        
        document.getElementById('admin-critical-modal').classList.remove('hidden');
        localStorage.removeItem('aeris_admin_login_flag');
        
        document.getElementById('admin-global-banner').classList.add('hidden');
    }
}

function dismissCriticalAlert() {
    document.getElementById('admin-critical-modal').classList.add('hidden');
    checkAdminGlobalAlerts();
}

function handleCriticalAlertNow() {
    document.getElementById('admin-critical-modal').classList.add('hidden');
    checkAdminGlobalAlerts();
    if (currentCriticalId) {
        openAdminReportDetail(currentCriticalId);
    }
}

function checkAdminGlobalAlerts() {
    const latestCrit = window.reports.find(r => (r.priority === 'CRITICAL' || r.status === 'Critical') && r.status !== 'Resolved');
    const banner = document.getElementById('admin-global-banner');
    
    if (latestCrit && !document.getElementById('admin-critical-modal')?.classList.contains('hidden') === false) {
        const textSpan = document.getElementById('banner-issue-text');
        if (textSpan) textSpan.textContent = `${latestCrit.issue} reported at ${latestCrit.location.building} — ${latestCrit.location.room}`;
        if (banner) banner.classList.remove('hidden');
    } else {
        if (banner) banner.classList.add('hidden');
    }
}

function updateAdminBadges() {
    const active = window.reports.filter(r => r.status !== 'Resolved');
    const crits = active.filter(r => r.priority === 'CRITICAL' || r.status === 'Critical');
    const pendingCount = active.length;
    
    document.querySelectorAll('.alert-badge').forEach(b => {
        if (b.id === 'nav-badge-alerts') { 
            b.textContent = crits.length; 
            b.style.display = crits.length > 0 ? 'inline-block' : 'none'; 
        }
        if (b.id === 'nav-badge-reports') { 
            b.textContent = pendingCount; 
            b.style.display = pendingCount > 0 ? 'inline-block' : 'none'; 
        }
    });
    
    checkAdminGlobalAlerts();
}

function renderAdminDashboard() {
    const active = window.reports.filter(r => r.status !== 'Resolved');
    const crits = active.filter(r => r.priority === 'CRITICAL' || r.status === 'Critical');
    const inProgress = active.filter(r => r.status === 'In Progress');
    const warns = active.filter(r => r.priority === 'HIGH' || r.priority === 'MEDIUM');
    const infos = active.filter(r => r.priority === 'LOW');

    const dashCrit = document.getElementById('dash-critical');
    if (dashCrit) dashCrit.textContent = crits.length.toString().padStart(2, '0');
    const dashWarn = document.getElementById('dash-warning');
    if (dashWarn) dashWarn.textContent = warns.length.toString().padStart(2, '0');
    const dashInfo = document.getElementById('dash-info');
    if (dashInfo) dashInfo.textContent = infos.length.toString().padStart(2, '0');

    // Rooms overview
    const dashRooms = document.getElementById('dash-total-rooms');
    if (dashRooms) dashRooms.textContent = window.spaces.length.toString().padStart(2, '0');
    
    // Average Comfort Score calculation
    const totalScore = window.spaces.reduce((acc, s) => acc + (s.comfortScore || 80), 0);
    const avgScore = Math.round(totalScore / (window.spaces.length || 1));
    const dashAvg = document.getElementById('dash-avg-comfort');
    if (dashAvg) dashAvg.textContent = `${avgScore}%`;

    // Render Recurring Issues Banner/Feed
    renderRecurringIssuesWidget();

    // Render Smart Verification Consensus Feed
    renderVerificationConsensusWidget();
    
    // Anomaly Feed
    const feed = document.getElementById('admin-anomaly-feed');
    if (feed) {
        if (active.length === 0) {
            feed.innerHTML = '<div style="color:var(--text-muted); font-size:0.875rem; padding:16px 0;">No active anomalies. All campus zones clear.</div>';
        } else {
            active.sort((a,b) => {
                const map = {'CRITICAL':4, 'HIGH':3, 'MEDIUM':2, 'LOW':1};
                return (map[b.priority] || 1) - (map[a.priority] || 1);
            });
            
            feed.innerHTML = active.map(r => {
                let cls = 'info'; let label = 'INFO';
                if (r.priority === 'CRITICAL' || r.status === 'Critical') { cls = 'critical'; label = 'CRITICAL'; }
                if (r.priority === 'HIGH' || r.priority === 'MEDIUM') { cls = 'warning'; label = 'WARNING'; }
                
                const verif = r.verifications || { stillExists: 0, fixed: 0 };
                let verifSnippet = '';
                if (verif.stillExists > 0 || verif.fixed > 0) {
                    verifSnippet = `<div style="font-size:0.75rem; color:var(--primary-blue); font-weight:600; margin-top:4px;">
                        👥 ${verif.stillExists} users confirmed exists · ${verif.fixed} reported fixed
                    </div>`;
                }

                return `
                <div class="alert-card-mini ${cls}" onclick="openAdminReportDetail('${r.id}')">
                    <div class="acm-pri">${label} · ${r.status}</div>
                    <div><strong>${r.location.building} ${r.location.room}:</strong> ${r.issue}</div>
                    <div style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">${r.description || 'No additional details'}</div>
                    ${verifSnippet}
                </div>`;
            }).join('');
        }
    }
    
    if (document.getElementById('adminEnergyChart')) {
        renderAdminEnergyChart();
    }
}

// Recurring Issues Detection Widget for Admin Dashboard
function renderRecurringIssuesWidget() {
    const container = document.getElementById('admin-recurring-widget');
    if (!container) return;

    const recurring = window.getRecurringIssues();
    if (recurring.length === 0) {
        container.innerHTML = `
            <div style="background:var(--white); border-radius:var(--radius-md); padding:18px 24px; border:1px solid var(--soft-lavender); box-shadow:var(--shadow-sm); margin-bottom:24px; display:flex; align-items:center; gap:12px;">
                <span style="font-size:1.5rem;">✅</span>
                <div>
                    <strong style="color:var(--text-main); font-size:0.9375rem;">No Recurring Facility Issues Detected</strong>
                    <div style="font-size:0.8125rem; color:var(--text-muted);">All equipment failures in the last 30 days are isolated incidents.</div>
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div style="background:rgba(255, 152, 0, 0.08); border:2px solid var(--status-high); border-radius:var(--radius-md); padding:20px 24px; margin-bottom:24px; box-shadow:var(--shadow-sm);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:1.5rem;">⚠️</span>
                    <strong style="color:var(--text-main); font-size:1.0625rem;">Recurring Maintenance Alert (${recurring.length} Flagged)</strong>
                </div>
                <span class="status-badge pri-high">Needs Preventative Action</span>
            </div>
            <div style="display:flex; flex-direction:column; gap:10px;">
                ${recurring.map(item => `
                    <div style="background:var(--white); border-radius:var(--radius-sm); padding:12px 16px; border:1px solid rgba(255,152,0,0.3); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                        <div>
                            <strong>${item.roomName} (${item.building})</strong>
                            <div style="font-size:0.8125rem; color:var(--text-body); margin-top:2px;">
                                Experienced <strong>${item.count} ${item.category}</strong> reports in the past 30 days. Recommend comprehensive unit overhaul.
                            </div>
                        </div>
                        <button class="btn btn-secondary btn-sm" onclick="window.location.href='reports.html?room=${encodeURIComponent(item.roomId)}'">Inspect Reports</button>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Community Verification Consensus Widget for Admin Dashboard
function renderVerificationConsensusWidget() {
    const container = document.getElementById('admin-verification-widget');
    if (!container) return;

    const verifiedReports = window.reports.filter(r => r.verifications && (r.verifications.stillExists > 0 || r.verifications.fixed > 0));

    if (verifiedReports.length === 0) {
        container.innerHTML = '<div style="color:var(--text-muted); font-size:0.8125rem;">No active community verifications yet.</div>';
        return;
    }

    container.innerHTML = verifiedReports.slice(0, 4).map(r => {
        const v = r.verifications;
        const existsCount = v.stillExists || 0;
        const fixedCount = v.fixed || 0;
        const total = existsCount + fixedCount;
        const pctExists = total > 0 ? Math.round((existsCount / total) * 100) : 50;

        return `
            <div style="background:var(--bg-color); border-radius:var(--radius-sm); padding:12px 14px; border:1px solid var(--soft-lavender); margin-bottom:8px; cursor:pointer;" onclick="openAdminReportDetail('${r.id}')">
                <div class="flex-between">
                    <strong style="font-size:0.875rem; color:var(--text-main);">${r.location.building} ${r.location.room}: ${r.issue}</strong>
                    <span style="font-size:0.75rem; font-weight:700; color:${r.status==='Resolved'?'var(--status-optimal)':'var(--primary-blue)'}">${r.status}</span>
                </div>
                <div style="margin-top:6px; display:flex; align-items:center; gap:8px; font-size:0.75rem;">
                    <span style="color:var(--status-poor); font-weight:700;">${existsCount} still active</span>
                    <span>·</span>
                    <span style="color:var(--status-optimal); font-weight:700;">${fixedCount} reported fixed</span>
                </div>
            </div>
        `;
    }).join('');
}

function renderAdminReports() {
    const tbody = document.getElementById('admin-reports-tbody');
    if (!tbody) return;

    const filterPri = document.getElementById('filter-priority')?.value || 'All';
    const filterStat = document.getElementById('filter-status')?.value || 'All';
    const searchQuery = (document.getElementById('filter-search')?.value || '').trim().toLowerCase();
    const filterRoom = new URLSearchParams(window.location.search).get('room');
    
    let filtered = window.reports.filter(r => {
        if (filterPri !== 'All' && r.priority !== filterPri) return false;
        if (filterStat !== 'All' && r.status !== filterStat) return false;
        if (filterRoom && r.roomId !== filterRoom && (!r.location || r.location.room !== filterRoom)) return false;
        if (searchQuery) {
            const hay = (r.id + ' ' + r.issue + ' ' + (r.desc || '') + ' ' + (r.location ? r.location.building + ' ' + r.location.room : '')).toLowerCase();
            if (!hay.includes(searchQuery)) return false;
        }
        return true;
    });

    const priMap = { 'CRITICAL': 4, 'HIGH': 3, 'MEDIUM': 2, 'LOW': 1 };
    filtered.sort((a,b) => (priMap[b.priority] || 1) - (priMap[a.priority] || 1));
    
    tbody.innerHTML = filtered.map(r => {
        const cls = {'LOW':'pri-low', 'MEDIUM':'pri-medium', 'HIGH':'pri-high', 'CRITICAL':'pri-critical'}[r.priority] || 'pri-low';
        const v = r.verifications || { stillExists: 0, fixed: 0 };
        const verifPill = (v.stillExists || v.fixed) ? 
            `<div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">👍 ${v.stillExists} active / ${v.fixed} fixed</div>` : '';

        return `
        <tr>
            <td style="font-family:monospace; color:var(--text-muted);">${r.id}</td>
            <td>
                <strong>${r.issue}</strong>
                ${verifPill}
            </td>
            <td>${r.location.building} - ${r.location.room}</td>
            <td>${r.category}</td>
            <td><span class="priority-badge ${cls}">${r.priority}</span></td>
            <td><span style="font-weight:600; color: ${r.status==='Resolved'?'var(--status-optimal)': (r.status==='Critical'?'var(--status-poor)':'var(--primary-blue)')};">${r.status}</span></td>
            <td><button class="btn btn-secondary btn-sm" onclick="openAdminReportDetail('${r.id}')">Manage</button></td>
        </tr>
    `;
    }).join('');
}

function openAdminReportDetail(id) {
    const r = window.reports.find(x => x.id === id);
    if (!r) return;
    
    const cls = {'LOW':'pri-low', 'MEDIUM':'pri-medium', 'HIGH':'pri-high', 'CRITICAL':'pri-critical'}[r.priority] || 'pri-low';
    const v = r.verifications || { stillExists: 0, fixed: 0, lastVerified: r.timestamp };
    
    let photoHtml = '';
    if (r.photo) {
        photoHtml = `
            <div style="margin-top:14px;">
                <strong>Attached Photo Evidence:</strong>
                <div style="margin-top:6px; max-height:200px; border-radius:8px; overflow:hidden; border:1px solid var(--soft-lavender);">
                    <img src="${r.photo}" alt="Evidence" style="width:100%; height:100%; object-fit:contain; background:#000;">
                </div>
            </div>
        `;
    }

    let notesHtml = '';
    if (r.notes && r.notes.length > 0) {
        notesHtml = `
            <div style="margin-top:16px;">
                <strong>Maintenance Log Notes:</strong>
                <div style="display:flex; flex-direction:column; gap:6px; margin-top:6px;">
                    ${r.notes.map(n => `
                        <div style="background:var(--bg-color); padding:8px 12px; border-radius:6px; font-size:0.8125rem;">
                            <strong>${n.author}:</strong> ${n.note}
                            <span style="font-size:0.7rem; color:var(--text-muted); display:block; margin-top:2px;">${new Date(n.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    document.getElementById('admin-rd-content').innerHTML = `
        <h3 style="margin-bottom:20px; font-size:1.35rem;">Manage Facility Report ${r.id}</h3>
        <div style="text-align:left; font-size:0.875rem; margin-bottom:20px;">
            <div class="sd-row"><span>Priority:</span> <span class="priority-badge ${cls}">${r.priority}</span></div>
            <div class="sd-row"><span>Issue:</span> <strong>${r.issue}</strong></div>
            <div class="sd-row"><span>Location:</span> <strong>${r.location.building} - ${r.location.room}</strong></div>
            <div class="sd-row"><span>Category:</span> ${r.category}</div>
            <div class="sd-row"><span>Assigned Team:</span> <strong id="rep-assigned-team-val">${r.assignedTeam || 'General Facility Ops'}</strong></div>
            <div class="sd-row"><span>Reporter:</span> ${(r.reporter && r.reporter.name) || 'Student User'}</div>
            <div class="sd-row"><span>Reported At:</span> ${new Date(r.timestamp).toLocaleString()}</div>
            <div class="sd-row"><span>Status:</span> <strong style="color: ${r.status==='Resolved'?'var(--status-optimal)': (r.status==='Critical'?'var(--status-poor)':'var(--primary-blue)')};">${r.status}</strong></div>
            
            <!-- Smart Verification Consensus Breakdown -->
            <div style="background:rgba(127,143,243,0.1); border:1px solid var(--soft-lavender); border-radius:8px; padding:12px; margin-top:14px;">
                <div style="font-weight:700; color:var(--text-main); margin-bottom:4px;">Smart Crowd Verification Consensus:</div>
                <div style="font-size:0.8125rem; color:var(--text-body);">
                    ⚠️ <strong>${v.stillExists || 0} students</strong> confirmed issue still exists.<br>
                    ✅ <strong>${v.fixed || 0} students</strong> reported issue resolved.
                </div>
            </div>

            <div style="margin-top:14px;">
                <strong>Problem Description:</strong>
                <p style="background:var(--bg-color); padding:10px 14px; border-radius:8px; margin-top:6px; line-height:1.5;">${r.description || 'No description provided.'}</p>
            </div>

            ${photoHtml}
            ${notesHtml}

            <!-- Admin Note Input & Assignee -->
            <div style="margin-top:16px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Assign Maintenance Personnel / Team:</label>
                <select id="admin-assign-team" class="fac-select full-width" style="margin-bottom:12px;">
                    <option value="HVAC Maintenance Team" ${r.assignedTeam==='HVAC Maintenance Team'?'selected':''}>HVAC Maintenance Team (Pak Bambang)</option>
                    <option value="Electrical Engineering Ops" ${r.assignedTeam==='Electrical Engineering Ops'?'selected':''}>Electrical Engineering Ops (Pak Doni)</option>
                    <option value="Audio Visual & IT Ops" ${r.assignedTeam==='Audio Visual & IT Ops'?'selected':''}>Audio Visual &amp; IT Ops (Pak Hendra)</option>
                    <option value="Janitorial Services" ${r.assignedTeam==='Janitorial Services'?'selected':''}>Janitorial Services</option>
                    <option value="Carpentry & Facilities" ${r.assignedTeam==='Carpentry & Facilities'?'selected':''}>Carpentry &amp; Facilities</option>
                </select>

                <label style="font-weight:600; display:block; margin-bottom:6px;">Add Maintenance Action Note:</label>
                <input type="text" id="admin-action-note" class="form-control" placeholder="e.g. Technician dispatched with replacement part..." style="margin-bottom:12px;">
            </div>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end; border-top:1px solid var(--soft-lavender); padding-top:16px;">
            <button class="btn btn-secondary btn-sm" onclick="saveAdminAssignment('${r.id}')">Save Assignment &amp; Note</button>
            <button class="btn btn-outline btn-sm" onclick="updateReportStatus('${r.id}', 'In Progress')">Mark In Progress</button>
            <button class="btn btn-primary btn-sm" onclick="updateReportStatus('${r.id}', 'Resolved')">Officially Resolve</button>
            <button class="btn btn-secondary btn-sm" style="color:var(--status-poor);" onclick="updateReportStatus('${r.id}', 'Rejected')">Reject</button>
        </div>
    `;
    document.getElementById('admin-report-detail-modal').classList.remove('hidden');
}

function saveAdminAssignment(id) {
    const r = window.reports.find(x => x.id === id);
    if (!r) return;

    const team = document.getElementById('admin-assign-team').value;
    const noteText = document.getElementById('admin-action-note').value.trim();

    r.assignedTeam = team;
    if (noteText) {
        if (!r.notes) r.notes = [];
        r.notes.push({
            author: 'Facility Admin',
            role: 'admin',
            note: noteText,
            timestamp: new Date().toISOString()
        });

        // Log in maintenance history
        window.logMaintenanceEvent(
            r.roomId,
            r.id,
            'assigned',
            `Work Order Assigned to ${team}`,
            `Admin note: "${noteText}"`,
            'Assigned'
        );
    }

    window.saveReports();
    alert('Assignment and notes saved successfully.');
    openAdminReportDetail(id);
}

function updateReportStatus(id, newStatus) {
    const r = window.reports.find(x => x.id === id);
    if (r) {
        const oldStatus = r.status;
        r.status = newStatus;
        
        // Log in timeline
        window.logMaintenanceEvent(
            r.roomId,
            r.id,
            'status_change',
            `Status Changed: ${newStatus}`,
            `Admin updated report ${r.id} status from "${oldStatus}" to "${newStatus}".`,
            newStatus
        );

        window.saveReports();
        document.getElementById('admin-report-detail-modal').classList.add('hidden');
        checkAdminGlobalAlerts();
    }
}

// -------------------------------------------------------------
// QR Code Placard Generator & Room Management for admin/zones.html
// -------------------------------------------------------------
let adminSelectedRoom = null;

function renderAdminZonesPage() {
    const list = document.getElementById('admin-zones-list');
    if (!list) return;

    const filterBuilding = document.getElementById('filter-zone-bldg')?.value || 'All';
    const filterHealth = document.getElementById('filter-zone-health')?.value || 'All';

    const filtered = window.spaces.filter(s => {
        if (filterBuilding !== 'All' && s.building !== filterBuilding) return false;
        const health = window.calculateRoomHealth(s);
        if (filterHealth !== 'All' && health.status !== filterHealth) return false;
        return true;
    });

    list.innerHTML = filtered.map(room => {
        const health = window.calculateRoomHealth(room);
        const unresolved = window.getRoomVerificationIssues(room.id);
        const radar = window.calculateRadarColor ? window.calculateRadarColor(room.id) : { hex: '#5FCB82', label: 'Comfortable' };
        const isQrActive = room.qrActive !== false;

        return `
        <li class="zone-item expanded" style="margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <div>
                    <div style="font-weight:700; font-size:1.15rem; color:var(--text-main);">
                        🏢 ${room.name} <span style="font-size:0.8125rem; color:var(--text-muted); font-weight:normal;">(${room.roomCode || room.id})</span>
                    </div>
                    <div style="font-size:0.8125rem; color:var(--text-body); margin-top:2px;">
                        ${room.building} · Floor ${room.floor} · ${room.roomType || 'General'} · Capacity: ${room.capacity || 50}
                    </div>
                </div>

                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <!-- Facility Health Badge -->
                    <span class="status-badge ${health.badgeClass}">Health: ${health.label}</span>
                    
                    <!-- Environmental Radar Badge -->
                    <span class="status-badge" style="background:${radar.hex}22; color:${radar.hex}; border:1px solid ${radar.hex}; font-weight:700;">
                        ● Radar: ${radar.label}
                    </span>

                    <!-- QR Active Status -->
                    <span class="status-badge ${isQrActive ? 'status-optimal' : 'status-poor'}" style="font-size:0.6875rem;">
                        ${isQrActive ? '✓ QR Active' : '✕ QR Inactive'}
                    </span>

                    <!-- QR Actions -->
                    <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation(); openAdminRoomQR('${room.id}')" title="Preview or print placard">
                        📷 View / Print QR
                    </button>
                    <button class="btn btn-outline btn-sm" onclick="event.stopPropagation(); regenerateRoomQR('${room.id}')" title="Regenerate secure identifier">
                        🔄 Refresh
                    </button>
                    <button class="btn btn-outline btn-sm" onclick="event.stopPropagation(); toggleRoomQRActive('${room.id}')" style="color:${isQrActive ? 'var(--status-poor)' : '#2E9E58'};">
                        ${isQrActive ? 'Deactivate' : 'Activate'}
                    </button>
                </div>
            </div>

            <div class="sensor-list" style="display:block; margin-top:14px; padding-left:14px; border-left:3px solid var(--soft-lavender);">
                <div class="sensor-card">
                    <div>
                        <div style="font-weight:600;"><span class="sensor-status ${isQrActive ? 'online' : 'offline'}"></span> Sensor node: ${room.roomCode}-ENV</div>
                        <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">
                            ${unresolved.length > 0 ? `⚠️ ${unresolved.length} active unresolved report(s)` : '✅ No active incident reports'}
                        </div>
                    </div>
                    <div class="sensor-readings">
                        <span>🌡️ ${room.temperature.toFixed(1)}°C</span>
                        <span>💧 ${Math.round(room.humidity)}% RH</span>
                        <span>🌬️ ${room.co2} ppm</span>
                        <span>👥 ${Math.round(room.occupancy)}% Occupied</span>
                    </div>
                </div>
            </div>
        </li>
        `;
    }).join('');
}

function regenerateRoomQR(roomId) {
    const room = window.spaces.find(s => s.id === roomId);
    if (!room) return;
    room.qrCode = `AERIS-ROOM-${room.roomCode || room.id}-${Math.floor(Math.random() * 900 + 100)}`;
    window.saveSpaces();
    renderAdminZonesPage();
    alert(`QR Placard code successfully refreshed for ${room.name}: ${room.qrCode}`);
}

function toggleRoomQRActive(roomId) {
    const room = window.spaces.find(s => s.id === roomId);
    if (!room) return;
    room.qrActive = room.qrActive === false ? true : false;
    window.saveSpaces();
    renderAdminZonesPage();
}


function getRoomDirectUrl(roomId) {
    if (window.location.protocol === 'file:') {
        return window.location.href.replace(/\/admin\/.*$/, '/user/room.html?id=' + roomId);
    }
    return window.location.origin + window.location.pathname.replace(/\/admin\/.*$/, '') + `/user/room.html?id=${roomId}`;
}

function openAdminRoomQR(roomId) {
    adminSelectedRoom = window.spaces.find(s => s.id === roomId);
    if (!adminSelectedRoom || !window.AERIS_QR) return;

    document.getElementById('admin-qr-room-name').textContent = adminSelectedRoom.name;
    document.getElementById('admin-qr-room-code').textContent = `ROOM CODE: ${adminSelectedRoom.roomCode || adminSelectedRoom.id}`;

    // Generate link targeting user/room.html with this room's id
    const targetUrl = getRoomDirectUrl(adminSelectedRoom.id);
    const svg = window.AERIS_QR.toSVG(targetUrl, { size: 180, fgColor: '#20266F' });
    document.getElementById('admin-qr-svg-container').innerHTML = svg;

    document.getElementById('admin-qr-modal').classList.remove('hidden');
}

function downloadAdminQR() {
    if (!adminSelectedRoom || !window.AERIS_QR) return;
    const targetUrl = getRoomDirectUrl(adminSelectedRoom.id);
    const dataUrl = window.AERIS_QR.toDataURL(targetUrl, { size: 600, fgColor: '#20266F' });
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `AERIS-ROOM-QR-${adminSelectedRoom.roomCode || adminSelectedRoom.id}.png`;
    a.click();
}

function downloadAdminQRSvg() {
    if (!adminSelectedRoom || !window.AERIS_QR) return;
    const targetUrl = getRoomDirectUrl(adminSelectedRoom.id);
    const svgContent = window.AERIS_QR.toSVG(targetUrl, { size: 600, fgColor: '#20266F' });
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AERIS-ROOM-QR-${adminSelectedRoom.roomCode || adminSelectedRoom.id}.svg`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function openAddRoomModal() {
    document.getElementById('admin-add-room-modal')?.classList.remove('hidden');
}

function submitNewRoom() {
    const name = document.getElementById('new-room-name').value.trim();
    const code = document.getElementById('new-room-code').value.trim();
    const bldg = document.getElementById('new-room-bldg').value;
    const floor = parseInt(document.getElementById('new-room-floor').value, 10);
    const type = document.getElementById('new-room-type').value;
    const cap = parseInt(document.getElementById('new-room-capacity').value, 10) || 40;

    const newId = code.toLowerCase().replace(/[^a-z0-9]/g, '');

    const newSpace = {
        id: newId,
        name: name,
        roomCode: code,
        building: bldg,
        floor: floor,
        roomType: type,
        image: 'assets/study-hall.jpg',
        match: 90,
        comfortScore: 90,
        temperature: 23.5,
        humidity: 50,
        co2: 650,
        occupancy: 20,
        tablesAvailable: 10,
        tags: [type, 'Comfortable'],
        status: 'Optimal',
        statusLevel: 'optimal',
        walkTime: '4 min walk',
        qrCode: `AERIS-ROOM-${code}`,
        capacity: cap,
        equipment: ['Standard Split AC', 'LED Panels', 'Power Outlets (x12)', 'Lectern'],
        baseValues: { temp: 23.5, hum: 50, co2: 650, occ: 20, tbl: 10 }
    };

    window.spaces.push(newSpace);
    window.saveSpaces();

    document.getElementById('admin-add-room-modal')?.classList.add('hidden');
    alert(`Room "${name}" successfully registered with QR Code: ${newSpace.qrCode}`);
    renderAdminZonesPage();
}

let adminChartInstance = null;
function renderAdminEnergyChart() {
    const ctx = document.getElementById('adminEnergyChart');
    if (!ctx || typeof Chart === 'undefined') return;
    if (adminChartInstance) adminChartInstance.destroy();
    
    adminChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
            datasets: [
                { type: 'line', label: 'IEQ (%)', data: [95, 90, 85, 60, 55, 80, 82], borderColor: '#7F8FF3', borderWidth: 2, tension: 0.4, yAxisID: 'y1', pointRadius: 0 },
                { type: 'bar', label: 'Power (kWh)', data: [120, 110, 90, 40, 40, 100, 105], backgroundColor: 'rgba(217, 222, 250, 0.6)', borderRadius: 2, yAxisID: 'y' }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { position: 'left', display: false }, y1: { position: 'right', display: false, grid: { drawOnChartArea: false } }, x: { display: false } } }
    });
}

function renderAdminAlertCenter() {
    const container = document.getElementById('admin-alerts-container');
    if (!container) return;
    
    let active = window.reports.filter(r => r.status !== 'Resolved');

    const search = (document.getElementById('alert-search-input')?.value || '').trim().toLowerCase();
    const cat = document.getElementById('alert-category-select')?.value || 'All Categories';

    if (cat !== 'All Categories' && cat !== 'All') {
        if (cat === 'Emergency') {
            active = active.filter(r => r.priority === 'CRITICAL' || r.status === 'Critical' || r.category === 'Safety');
        } else if (cat === 'Environmental') {
            active = active.filter(r => r.category === 'HVAC' || r.category === 'Air Conditioning' || r.category === 'Cleanliness');
        } else {
            active = active.filter(r => r.category === cat || r.category === 'Equipment' || r.category === 'Electrical' || r.category === 'Furniture');
        }
    }

    if (search) {
        active = active.filter(r => {
            const hay = (r.id + ' ' + r.issue + ' ' + (r.desc || '') + ' ' + (r.location ? r.location.building + ' ' + r.location.room : '')).toLowerCase();
            return hay.includes(search);
        });
    }
    
    if (active.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding: 48px; color: var(--text-muted); background:var(--white); border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">No active alerts match your search/filter criteria.</div>';
        return;
    }
    
    active.sort((a,b) => {
        const map = {'CRITICAL':4, 'HIGH':3, 'MEDIUM':2, 'LOW':1};
        return (map[b.priority] || 1) - (map[a.priority] || 1);
    });
    
    container.innerHTML = active.map(r => {
        let cls = 'pri-low';
        if (r.priority === 'CRITICAL' || r.status === 'Critical') cls = 'pri-critical';
        if (r.priority === 'HIGH') cls = 'pri-high';
        if (r.priority === 'MEDIUM') cls = 'pri-medium';
        
        let borderCls = (r.priority === 'CRITICAL' || r.status === 'Critical') ? 'border-left: 4px solid var(--status-poor);' : 'border-left: 4px solid var(--soft-lavender);';
        const v = r.verifications || { stillExists: 0, fixed: 0 };
        const verifPill = (v.stillExists || v.fixed) ? 
            `<span style="font-size:0.75rem; color:var(--primary-blue); font-weight:600; display:block; margin-top:4px;">👥 ${v.stillExists} confirmed exists · ${v.fixed} fixed</span>` : '';

        return `
        <div class="admin-panel" style="margin-bottom: 16px; flex-direction: row; justify-content: space-between; align-items: center; ${borderCls} padding: 16px 24px;">
            <div>
                <span class="priority-badge ${cls}" style="margin-bottom: 8px; font-size: 0.65rem;">${r.priority}</span>
                <div style="font-weight: 600; font-size: 1.125rem;">${r.issue}</div>
                <div style="font-size: 0.875rem; color: var(--text-body); margin-top: 4px;">📍 ${r.location.building} — ${r.location.room}</div>
                ${verifPill}
            </div>
            <div style="text-align: right; display: flex; flex-direction: column; align-items: flex-end; gap: 8px;">
                <span style="font-size: 0.875rem; font-weight: 600; color: ${r.status==='Critical'?'var(--status-poor)':'var(--primary-blue)'};">${r.status}</span>
                <button class="btn btn-secondary btn-sm" onclick="openAdminReportDetail('${r.id}')">Manage</button>
            </div>
        </div>
        `;
    }).join('');
}

// Global Sync
window.addEventListener('storage_reports_updated', () => {
    if (window.location.pathname.includes('admin/')) {
        updateAdminBadges();
        if (document.getElementById('dash-critical')) renderAdminDashboard();
        if (document.getElementById('admin-reports-tbody')) renderAdminReports();
        if (document.getElementById('admin-alerts-container')) renderAdminAlertCenter();
        if (document.getElementById('admin-zones-list')) renderAdminZonesPage();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.includes('admin/')) {
        injectAdminEmergencyModal();
        updateAdminBadges();
        checkAdminGlobalAlerts();
        checkCriticalLogin();
        
        if (document.getElementById('dash-critical')) renderAdminDashboard();
        if (document.getElementById('admin-reports-tbody')) renderAdminReports();
        if (document.getElementById('admin-alerts-container')) renderAdminAlertCenter();
        if (document.getElementById('admin-zones-list')) renderAdminZonesPage();
    }
});

// Exports
window.openAdminReportDetail = openAdminReportDetail;
window.updateReportStatus = updateReportStatus;
window.saveAdminAssignment = saveAdminAssignment;
window.dismissCriticalAlert = dismissCriticalAlert;
window.handleCriticalAlertNow = handleCriticalAlertNow;
window.openAdminRoomQR = openAdminRoomQR;
window.downloadAdminQR = downloadAdminQR;
window.downloadAdminQRSvg = downloadAdminQRSvg;
window.renderAdminZonesPage = renderAdminZonesPage;
window.regenerateRoomQR = regenerateRoomQR;
window.toggleRoomQRActive = toggleRoomQRActive;
window.openAddRoomModal = openAddRoomModal;
window.submitNewRoom = submitNewRoom;
window.renderAdminReports = renderAdminReports;
window.renderAdminAlertCenter = renderAdminAlertCenter;


