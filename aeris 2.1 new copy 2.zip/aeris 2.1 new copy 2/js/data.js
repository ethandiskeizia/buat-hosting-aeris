/**
 * data.js - AERIS Unified State Management & Telemetry Engine
 * 
 * Manages:
 * - Campus Rooms & Environmental Telemetry (Temp, Humidity, CO2, PM2.5, Noise, TVOC)
 * - Smart Environmental Radar Mode & Dynamic Color Calculation (RED, ORANGE, YELLOW, GREEN, BLUE)
 * - Fast Community Thermal Comfort Feedback (1-2 tap submission with time-decay)
 * - Facility Incident Reports & Priority Engine
 * - Smart Community Verification (Google Maps-style crowdsourced validation)
 * - Dynamic Facility Health Status Indicator (GOOD, NEEDS ATTENTION, CRITICAL, UNDER MAINTENANCE)
 * - Comprehensive Maintenance Task Management & Timelines
 * - User Contribution, XP, Levels, and Achievement Badges
 * - Recurring Issue Detection System
 */

// Gumdrop Mascot SVG
const mascotSVG = `
<svg width="100%" height="100%" viewBox="0 0 100 110" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 4px 12px rgba(120, 185, 232, 0.4)); animation: floatMascot 4s ease-in-out infinite;">
  <defs>
    <linearGradient id="mascotGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#E1F0FF" />
      <stop offset="45%" stop-color="#90C8FA" />
      <stop offset="100%" stop-color="#1472D4" />
    </linearGradient>
  </defs>
  <!-- Gumdrop body -->
  <path d="M 25 50 C 25 15, 75 15, 75 50 C 95 90, 80 100, 50 100 C 20 100, 5 90, 25 50 Z" fill="url(#mascotGrad)" />
  <!-- Eyes -->
  <circle cx="36" cy="48" r="5" fill="#1A1C29" />
  <circle cx="64" cy="48" r="5" fill="#1A1C29" />
  <!-- Smile -->
  <path d="M 46 56 Q 50 63 54 56" fill="none" stroke="#1A1C29" stroke-width="2.5" stroke-linecap="round" />
  <!-- Blush -->
  <circle cx="26" cy="56" r="6" fill="#67B1EE" opacity="0.7"/>
  <circle cx="74" cy="56" r="6" fill="#67B1EE" opacity="0.7"/>
</svg>
`;

/**
 * Smart Asset URL Resolver: ensures images load correctly whether on root (index.html) or subdirectories (user/, admin/)
 */
function resolveAssetUrl(assetRelativePath) {
    if (!assetRelativePath) return '';
    if (assetRelativePath.startsWith('data:') || assetRelativePath.startsWith('http://') || assetRelativePath.startsWith('https://')) {
        return assetRelativePath;
    }
    const clean = assetRelativePath.replace(/^(\.\.\/)+/, '').replace(/^assets\//, '');
    const isSubdir = window.location.pathname.includes('/user/') || window.location.pathname.includes('/admin/');
    return (isSubdir ? '../assets/' : 'assets/') + clean;
}

// ----------------------------------------------------------------------------
// 1. Initial Room Registry across UMN Campus (including Canteen, Labs, Classrooms)
// ----------------------------------------------------------------------------
const defaultSpaces = [
    { 
        id: 'lib2', 
        name: 'Library — Floor 2', 
        roomCode: 'LIB-F2',
        building: 'Library', 
        floor: 2, 
        roomType: 'Library & Quiet Study',
        image: 'assets/library.jpg', 
        match: 98, 
        comfortScore: 98, 
        temperature: 23.1, 
        humidity: 48, 
        co2: 620, 
        pm25: 8.5,
        noiseLevel: 38, // dB
        tvoc: 65,
        occupancy: 42, 
        tablesAvailable: 14, 
        tags: ['Quiet', 'Fresh Air', 'Cool', 'Reading Nook'], 
        status: 'Optimal', 
        statusLevel: 'optimal',
        walkTime: '3 min walk', 
        qrCode: 'AERIS-ROOM-LIB2',
        qrActive: true,
        capacity: 120,
        equipment: ['Silent Study Cubicles (x40)', 'Central Dual HVAC', 'Filtered Air Diffuser', 'Reading Lamps (x28)', 'Quiet Zone Acoustic Sensors'],
        baseValues: { temp: 23.1, hum: 48, co2: 620, occ: 42, tbl: 14 } 
    },
    { 
        id: 'canteen', 
        name: 'Campus Canteen & Food Court', 
        roomCode: 'SC-C1',
        building: 'Student Center', 
        floor: 1, 
        roomType: 'Dining & Social Space',
        image: 'assets/student-lounge.png', 
        match: 64, 
        comfortScore: 62, 
        temperature: 28.2, 
        humidity: 68, 
        co2: 1040, 
        pm25: 22.0,
        noiseLevel: 72, // dB
        tvoc: 240,
        occupancy: 88, 
        tablesAvailable: 4, 
        tags: ['Dining', 'High Traffic', 'Warm', 'Social'], 
        status: 'Moderate', 
        statusLevel: 'moderate',
        walkTime: '1 min walk', 
        qrCode: 'AERIS-ROOM-CANTEEN',
        qrActive: true,
        capacity: 200,
        equipment: ['Exhaust Ventilation Hoods (x4)', 'Ceiling Industrial Fans (x8)', 'Food Court Seating (x50 tables)', 'Hand Washing Stations'],
        baseValues: { temp: 28.2, hum: 68, co2: 1040, occ: 88, tbl: 4 } 
    },
    { 
        id: 'lounge', 
        name: 'Student Lounge', 
        roomCode: 'SC-L1',
        building: 'Student Center', 
        floor: 1, 
        roomType: 'Student Social Lounge',
        image: 'assets/student-lounge.png', 
        match: 91, 
        comfortScore: 91, 
        temperature: 24.0, 
        humidity: 50, 
        co2: 680, 
        pm25: 11.0,
        noiseLevel: 54,
        tvoc: 80,
        occupancy: 58, 
        tablesAvailable: 8, 
        tags: ['Casual', 'Power Outlets', 'Coffee Bar Nearby'], 
        status: 'Optimal', 
        statusLevel: 'optimal',
        walkTime: '5 min walk', 
        qrCode: 'AERIS-ROOM-LOUNGE',
        qrActive: true,
        capacity: 80,
        equipment: ['Modular Sofas & Beanbags', 'Wall Power Hubs (x18)', 'High-Capacity Air Purifier', 'Ambient Display Monitors (x2)'],
        baseValues: { temp: 24.0, hum: 50, co2: 680, occ: 58, tbl: 8 } 
    },
    { 
        id: 'gedungD', 
        name: 'Gedung D — Lounge', 
        roomCode: 'GD-L1',
        building: 'Gedung D', 
        floor: 1, 
        roomType: 'Open Study Area',
        image: 'assets/gedung-d-lounge.jpg', 
        match: 52, 
        comfortScore: 52, 
        temperature: 27.4, 
        humidity: 74, 
        co2: 1180, 
        pm25: 19.5,
        noiseLevel: 62,
        tvoc: 195,
        occupancy: 87, 
        tablesAvailable: 2, 
        tags: ['Crowded', 'Stuffy', 'Warm'], 
        status: 'Poor', 
        statusLevel: 'poor',
        walkTime: '2 min walk', 
        qrCode: 'AERIS-ROOM-GD-L1',
        qrActive: true,
        capacity: 60,
        equipment: ['Daikin Cassette AC Unit #1 (Under Maintenance)', 'Power Strips', 'Round Tables (x8)'],
        baseValues: { temp: 27.4, hum: 74, co2: 1180, occ: 87, tbl: 2 } 
    },
    { 
        id: 'studyHall', 
        name: 'Academic Study Hall', 
        roomCode: 'AC-F3',
        building: 'Academic', 
        floor: 3, 
        roomType: 'Collaborative Workspace',
        image: 'assets/study-hall.jpg', 
        match: 94, 
        comfortScore: 94, 
        temperature: 22.8, 
        humidity: 52, 
        co2: 650, 
        pm25: 9.0,
        noiseLevel: 44,
        tvoc: 70,
        occupancy: 35, 
        tablesAvailable: 18, 
        tags: ['Quiet', 'Cool', 'Ergonomic Seating'], 
        status: 'Optimal', 
        statusLevel: 'optimal',
        walkTime: '8 min walk', 
        qrCode: 'AERIS-ROOM-AC-F3',
        qrActive: true,
        capacity: 90,
        equipment: ['Whiteboards (x6)', 'Dual Inverter Split AC', 'Ergonomic Task Chairs (x60)', 'Floor Electrical Outlets (x24)'],
        baseValues: { temp: 22.8, hum: 52, co2: 650, occ: 35, tbl: 18 } 
    },
    { 
        id: 'corridor', 
        name: 'Gedung B Corridor', 
        roomCode: 'GB-C1',
        building: 'Gedung B', 
        floor: 1, 
        roomType: 'Semi-Open Transit Area',
        image: 'assets/gedung-b-corridor.jpg', 
        match: 72, 
        comfortScore: 72, 
        temperature: 25.1, 
        humidity: 60, 
        co2: 800, 
        pm25: 14.0,
        noiseLevel: 58,
        tvoc: 110,
        occupancy: 65, 
        tablesAvailable: 4, 
        tags: ['Transit', 'Moderate', 'Benches'], 
        status: 'Moderate', 
        statusLevel: 'moderate',
        walkTime: '2 min walk', 
        qrCode: 'AERIS-ROOM-GB-C1',
        qrActive: true,
        capacity: 40,
        equipment: ['Benches (x10)', 'Ceiling Recessed LED Panels', 'Emergency Fire Extinguisher #B1-04'],
        baseValues: { temp: 25.1, hum: 60, co2: 800, occ: 65, tbl: 4 } 
    },
    { 
        id: 'A101', 
        name: 'Smart Classroom A101', 
        roomCode: 'A101',
        building: 'Academic', 
        floor: 1, 
        roomType: 'Lecture Classroom',
        image: 'assets/study-hall.jpg', 
        match: 86, 
        comfortScore: 86, 
        temperature: 23.6, 
        humidity: 54, 
        co2: 740, 
        pm25: 10.5,
        noiseLevel: 46,
        tvoc: 85,
        occupancy: 48, 
        tablesAvailable: 12, 
        tags: ['Classroom', 'Projector', 'Audio System'], 
        status: 'Optimal', 
        statusLevel: 'optimal',
        walkTime: '4 min walk', 
        qrCode: 'AERIS-ROOM-A101',
        qrActive: true,
        capacity: 65,
        equipment: ['Laser Projector & 120" Screen', 'Instructor Smart Podium', 'Ceiling Microphone Array', 'Classroom AC #A1', 'Classroom AC #A2'],
        baseValues: { temp: 23.6, hum: 54, co2: 740, occ: 48, tbl: 12 } 
    },
    { 
        id: 'B201', 
        name: 'Multimedia Design Lab B201', 
        roomCode: 'B201',
        building: 'Gedung B', 
        floor: 2, 
        roomType: 'Computer Laboratory',
        image: 'assets/library.jpg', 
        match: 89, 
        comfortScore: 89, 
        temperature: 22.4, 
        humidity: 49, 
        co2: 710, 
        pm25: 7.5,
        noiseLevel: 50,
        tvoc: 95,
        occupancy: 60, 
        tablesAvailable: 6, 
        tags: ['High-Performance PCs', 'Dual Monitors', 'Cool Climate'], 
        status: 'Optimal', 
        statusLevel: 'optimal',
        walkTime: '4 min walk', 
        qrCode: 'AERIS-ROOM-B201',
        qrActive: true,
        capacity: 45,
        equipment: ['iMac Workstations (x35)', 'Color-Calibrated Display', 'High-Output HVAC System', 'Gigabit Ethernet Drops (x36)'],
        baseValues: { temp: 22.4, hum: 49, co2: 710, occ: 60, tbl: 6 } 
    },
    { 
        id: 'D302', 
        name: 'Collaborative Studio D302', 
        roomCode: 'D302',
        building: 'Gedung D', 
        floor: 3, 
        roomType: 'Project Workshop Studio',
        image: 'assets/gedung-d-lounge.jpg', 
        match: 78, 
        comfortScore: 78, 
        temperature: 24.8, 
        humidity: 62, 
        co2: 850, 
        pm25: 12.0,
        noiseLevel: 56,
        tvoc: 115,
        occupancy: 50, 
        tablesAvailable: 10, 
        tags: ['Whiteboards', 'Flexible Layout', 'Project Work'], 
        status: 'Moderate', 
        statusLevel: 'moderate',
        walkTime: '6 min walk', 
        qrCode: 'AERIS-ROOM-D302',
        qrActive: true,
        capacity: 50,
        equipment: ['Rolling Glass Whiteboards (x8)', 'Overhead Power Drops', 'Mobile Workbenches (x10)', 'Wall Mounted AC'],
        baseValues: { temp: 24.8, hum: 62, co2: 850, occ: 50, tbl: 10 } 
    }
];

let storedSpaces = null;
try { storedSpaces = JSON.parse(localStorage.getItem('aeris_spaces')); } catch(e) {}
let spaces = [];

if (storedSpaces && Array.isArray(storedSpaces) && storedSpaces.length > 0) {
    const storedMap = new Map(storedSpaces.map(s => [s.id, s]));
    defaultSpaces.forEach(def => {
        if (storedMap.has(def.id)) {
            const merged = Object.assign({}, def, storedMap.get(def.id));
            if (!merged.qrCode) merged.qrCode = def.qrCode;
            if (merged.qrActive === undefined) merged.qrActive = true;
            if (!merged.equipment) merged.equipment = def.equipment;
            if (!merged.pm25) merged.pm25 = def.pm25;
            if (!merged.noiseLevel) merged.noiseLevel = def.noiseLevel;
            spaces.push(merged);
            storedMap.delete(def.id);
        } else {
            spaces.push(def);
        }
    });
    storedMap.forEach(custom => spaces.push(custom));
} else {
    spaces = defaultSpaces;
}

function saveSpaces() {
    localStorage.setItem('aeris_spaces', JSON.stringify(spaces));
    window.dispatchEvent(new Event('storage_spaces_updated'));
}
saveSpaces();

// ----------------------------------------------------------------------------
// 2. Fast Community Thermal Comfort Feedback & Dynamic Radar Engine
// ----------------------------------------------------------------------------
/**
 * Initial historical thermal feedback across rooms (creates genuine baseline consensus)
 */
const defaultThermalFeedback = [
    // Canteen - predominantly hot
    { id: 'TF-101', roomId: 'canteen', userId: 'alex_tan', rating: 'extremely_hot', timestamp: new Date(Date.now() - 1000 * 60 * 20).toISOString() },
    { id: 'TF-102', roomId: 'canteen', userId: 'kevin_j', rating: 'hot', timestamp: new Date(Date.now() - 1000 * 60 * 35).toISOString() },
    { id: 'TF-103', roomId: 'canteen', userId: 'sarah_m', rating: 'extremely_hot', timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString() },
    { id: 'TF-104', roomId: 'canteen', userId: 'budi_s', rating: 'hot', timestamp: new Date(Date.now() - 1000 * 60 * 70).toISOString() },
    { id: 'TF-105', roomId: 'canteen', userId: 'nasira', rating: 'hot', timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString() },
    // Library - comfortable
    { id: 'TF-201', roomId: 'lib2', userId: 'nasira', rating: 'comfortable', timestamp: new Date(Date.now() - 1000 * 60 * 25).toISOString() },
    { id: 'TF-202', roomId: 'lib2', userId: 'doni_w', rating: 'comfortable', timestamp: new Date(Date.now() - 1000 * 60 * 50).toISOString() },
    { id: 'TF-203', roomId: 'lib2', userId: 'hadi_p', rating: 'cool', timestamp: new Date(Date.now() - 1000 * 60 * 85).toISOString() },
    { id: 'TF-204', roomId: 'lib2', userId: 'citra_k', rating: 'comfortable', timestamp: new Date(Date.now() - 1000 * 60 * 110).toISOString() },
    // Classroom A101 - mixed / warm
    { id: 'TF-301', roomId: 'A101', userId: 'kevin_j', rating: 'hot', timestamp: new Date(Date.now() - 1000 * 60 * 40).toISOString() },
    { id: 'TF-302', roomId: 'A101', userId: 'rina_a', rating: 'comfortable', timestamp: new Date(Date.now() - 1000 * 60 * 65).toISOString() },
    { id: 'TF-303', roomId: 'A101', userId: 'student', rating: 'hot', timestamp: new Date(Date.now() - 1000 * 60 * 95).toISOString() },
    // Multimedia Lab B201 - cool
    { id: 'TF-401', roomId: 'B201', userId: 'ahmad_f', rating: 'cool', timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString() },
    { id: 'TF-402', roomId: 'B201', userId: 'alex_tan', rating: 'cold', timestamp: new Date(Date.now() - 1000 * 60 * 75).toISOString() },
    { id: 'TF-403', roomId: 'B201', userId: 'citra_k', rating: 'cool', timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString() }
];

let thermalFeedback = null;
try { thermalFeedback = JSON.parse(localStorage.getItem('aeris_thermal_feedback')); } catch(e) {}
if (!thermalFeedback || !Array.isArray(thermalFeedback)) {
    thermalFeedback = defaultThermalFeedback;
    localStorage.setItem('aeris_thermal_feedback', JSON.stringify(thermalFeedback));
}

function saveThermalFeedback() {
    localStorage.setItem('aeris_thermal_feedback', JSON.stringify(thermalFeedback));
    window.dispatchEvent(new Event('storage_thermal_feedback_updated'));
}

/**
 * 1-2 Tap Fast Environmental Thermal Comfort Feedback
 * Ratings: 'extremely_hot', 'hot', 'comfortable', 'cool', 'cold'
 */
function submitThermalFeedback(roomId, rating, customUserId) {
    const space = spaces.find(s => s.id === roomId || s.roomCode === roomId);
    if (!space) return { success: false, message: 'Room not found.' };

    const session = JSON.parse(localStorage.getItem('aeris_session')) || { username: 'guest', name: 'Guest User' };
    const user = customUserId || session.username || 'student';

    // Anti-spam cooldown: max 1 thermal feedback per room every 10 minutes per user
    const recentFromUser = thermalFeedback.find(f => f.roomId === space.id && f.userId === user);
    if (recentFromUser) {
        const msSince = Date.now() - new Date(recentFromUser.timestamp).getTime();
        if (msSince < 1000 * 60 * 10) {
            return { 
                success: false, 
                message: `You recently provided thermal feedback for ${space.name}. Please wait a few minutes before submitting again.` 
            };
        }
    }

    const newFeedback = {
        id: 'TF-' + Math.floor(Math.random() * 90000 + 10000),
        roomId: space.id,
        userId: user,
        userName: session.name || user,
        rating: rating,
        timestamp: new Date().toISOString(),
        tempSnapshot: space.temperature,
        humSnapshot: space.humidity
    };

    thermalFeedback.unshift(newFeedback);
    saveThermalFeedback();

    return { 
        success: true, 
        message: `Thank you! Your ${rating.replace('_', ' ')} comfort rating for ${space.name} has been recorded on the Environmental Radar.`,
        feedback: newFeedback
    };
}

/**
 * Dynamic Radar Color & Statistics Calculation
 * Colors: RED, ORANGE, YELLOW, GREEN, BLUE, INSUFFICIENT
 */
function calculateRadarColor(roomId) {
    const space = spaces.find(s => s.id === roomId || s.roomCode === roomId);
    if (!space) {
        return { color: 'INSUFFICIENT', label: 'Unknown Zone', hex: '#A0AEC0', confidence: 'None', totalRecent: 0 };
    }

    // Filter feedback within the last 4 hours (active thermal window)
    const fourHoursAgo = Date.now() - (1000 * 60 * 60 * 4);
    const roomFeedbacks = thermalFeedback.filter(f => f.roomId === space.id && new Date(f.timestamp).getTime() >= fourHoursAgo);

    // If fewer than 2 recent responses, consider data insufficient for standalone radar
    if (roomFeedbacks.length < 2) {
        // Fallback to recent 24h if any
        const oneDayAgo = Date.now() - (1000 * 60 * 60 * 24);
        const dayFeedbacks = thermalFeedback.filter(f => f.roomId === space.id && new Date(f.timestamp).getTime() >= oneDayAgo);
        
        if (dayFeedbacks.length === 0) {
            return {
                color: 'INSUFFICIENT',
                label: 'Insufficient recent data',
                hex: '#A0AEC0',
                totalRecent: 0,
                percentage: { extremelyHot: 0, hot: 0, comfortable: 0, cool: 0, cold: 0 },
                confidence: 'Insufficient Data',
                lastUpdated: 'No recent feedback',
                mostCommon: 'Unknown',
                actualHumidity: space.humidity,
                actualTemp: space.temperature
            };
        }
    }

    const feedbacks = roomFeedbacks.length >= 2 ? roomFeedbacks : thermalFeedback.filter(f => f.roomId === space.id);
    const total = feedbacks.length;

    let weights = { extremely_hot: 0, hot: 0, comfortable: 0, cool: 0, cold: 0 };
    let counts = { extremely_hot: 0, hot: 0, comfortable: 0, cool: 0, cold: 0 };
    let totalWeight = 0;

    feedbacks.forEach(f => {
        const ageHours = Math.max(0, (Date.now() - new Date(f.timestamp).getTime()) / (1000 * 60 * 60));
        // Exponential time-decay: weight = 1 / (1 + ageHours)
        const weight = 1 / (1 + ageHours * 0.8);
        if (weights[f.rating] !== undefined) {
            weights[f.rating] += weight;
            counts[f.rating]++;
            totalWeight += weight;
        }
    });

    const pct = {
        extremelyHot: Math.round(((counts.extremely_hot) / (total || 1)) * 100),
        hot: Math.round(((counts.hot) / (total || 1)) * 100),
        comfortable: Math.round(((counts.comfortable) / (total || 1)) * 100),
        cool: Math.round(((counts.cool) / (total || 1)) * 100),
        cold: Math.round(((counts.cold) / (total || 1)) * 100)
    };

    const weightedScore = (weights.extremely_hot * 5 + weights.hot * 4 + weights.comfortable * 3 + weights.cool * 2 + weights.cold * 1) / (totalWeight || 1);

    let color = 'GREEN';
    let label = 'Comfortable';
    let hex = '#5FCB82';

    if (weightedScore >= 4.3 || (pct.extremelyHot >= 40)) {
        color = 'RED';
        label = 'Extremely Hot / Uncomfortable';
        hex = '#F06B67';
    } else if (weightedScore >= 3.6 || (pct.extremelyHot + pct.hot >= 50)) {
        color = 'ORANGE';
        label = 'Hot / Uncomfortable';
        hex = '#FF9800';
    } else if (weightedScore >= 3.2 || (pct.hot >= 30 && pct.comfortable < 50)) {
        color = 'YELLOW';
        label = 'Mixed Thermal Comfort';
        hex = '#F4C542';
    } else if (weightedScore <= 2.2 || (pct.cool + pct.cold >= 50)) {
        color = 'BLUE';
        label = 'Cool / Cold Zone';
        hex = '#4A90E2';
    } else {
        color = 'GREEN';
        label = 'Comfortable';
        hex = '#5FCB82';
    }

    const confidence = total >= 8 ? 'High' : (total >= 4 ? 'Medium' : 'Low');
    const mostCommonEntry = Object.entries(counts).sort((a,b) => b[1] - a[1])[0];
    const mostCommonLabel = mostCommonEntry ? mostCommonEntry[0].replace('_', ' ') : 'comfortable';
    const lastUpdated = feedbacks[0] ? new Date(feedbacks[0].timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) : 'Just now';

    return {
        color,
        label,
        hex,
        totalRecent: total,
        percentage: pct,
        confidence,
        lastUpdated,
        mostCommon: mostCommonLabel,
        actualHumidity: space.humidity,
        actualTemp: space.temperature,
        co2: space.co2
    };
}

// ----------------------------------------------------------------------------
// 3. User Preferences (Radar Mode ON/OFF, Heatmap Layer Mode, Map Defaults)
// ----------------------------------------------------------------------------
function getRadarMode() {
    return localStorage.getItem('aeris_radar_mode') !== 'false'; // default true
}

function setRadarMode(enabled) {
    localStorage.setItem('aeris_radar_mode', enabled ? 'true' : 'false');
    window.dispatchEvent(new Event('storage_radar_mode_updated'));
}

function getHeatmapMode() {
    return localStorage.getItem('aeris_heatmap_mode') || 'thermal'; // 'thermal' | 'humidity' | 'health' | 'normal'
}

function setHeatmapMode(mode) {
    localStorage.setItem('aeris_heatmap_mode', mode);
    window.dispatchEvent(new Event('storage_heatmap_mode_updated'));
}

// ----------------------------------------------------------------------------
// 4. Initial Incident Reports with Rich Verification & Assignment Context
// ----------------------------------------------------------------------------
const defaultReports = [
    {
        id: '#R-101',
        roomId: 'A101',
        category: 'Equipment',
        issue: 'Projector Malfunction',
        description: 'HDMI input gives no signal and projector bulb flashes orange warning. Cannot project course lecture slides.',
        priority: 'HIGH',
        location: { building: 'Academic', floor: 1, room: 'A101' },
        status: 'Submitted',
        assignedTeam: 'Audio Visual & IT Ops',
        photo: '',
        reporter: { username: 'student', name: 'Nasira Siddiqa', role: 'student', email: 'nasira@umn.ac.id' },
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(),
        notes: [
            { author: 'Facility Admin', role: 'admin', note: 'Received report. Scheduled AV technician inspection.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString() }
        ],
        verifications: { stillExists: 4, fixed: 1, lastVerified: new Date(Date.now() - 1000 * 60 * 25).toISOString() }
    },
    {
        id: '#R-102',
        roomId: 'gedungD',
        category: 'Air Conditioning',
        issue: 'AC Water Dripping Heavily',
        description: 'Ceiling cassette AC unit #1 is dripping condensation water onto the study tables below. Floor is slippery.',
        priority: 'HIGH',
        location: { building: 'Gedung D', floor: 1, room: 'Lounge' },
        status: 'In Progress',
        assignedTeam: 'HVAC Maintenance Team',
        photo: '',
        reporter: { username: 'kevin_j', name: 'Kevin Jonathan', role: 'student', email: 'kevin@umn.ac.id' },
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(),
        notes: [
            { author: 'Facility Admin', role: 'admin', note: 'Dispatched HVAC technician Pak Bambang with bucket & drain pump.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 30).toISOString() },
            { author: 'HVAC Tech', role: 'staff', note: 'Drain pipe blocked by debris. Parts ordered for tray replacement.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString() }
        ],
        verifications: { stillExists: 6, fixed: 0, lastVerified: new Date(Date.now() - 1000 * 60 * 15).toISOString() }
    },
    {
        id: '#R-103',
        roomId: 'gedungD',
        category: 'Air Conditioning',
        issue: 'AC Blowing Warm Air',
        description: 'Earlier this week AC was not cooling properly, blowing humid room temperature air.',
        priority: 'MEDIUM',
        location: { building: 'Gedung D', floor: 1, room: 'Lounge' },
        status: 'Resolved',
        assignedTeam: 'HVAC Maintenance Team',
        photo: '',
        reporter: { username: 'student', name: 'Student User', role: 'student', email: 'student@umn.ac.id' },
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
        notes: [
            { author: 'Facility Admin', role: 'admin', note: 'Filter cleaned and freon pressure checked.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString() }
        ],
        verifications: { stillExists: 0, fixed: 5, lastVerified: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString() }
    },
    {
        id: '#R-104',
        roomId: 'B201',
        category: 'Electrical',
        issue: 'Loose Floor Power Outlet',
        description: 'Floor power socket row 3 has loose wiring and sparks intermittently when laptop charger is plugged in.',
        priority: 'CRITICAL',
        location: { building: 'Gedung B', floor: 2, room: 'B201' },
        status: 'Under Review',
        assignedTeam: 'Electrical Engineering Ops',
        photo: '',
        reporter: { username: 'ahmad_f', name: 'Ahmad Faiz', role: 'student', email: 'ahmad@umn.ac.id' },
        timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
        notes: [
            { author: 'Facility Admin', role: 'admin', note: 'Isolated circuit breaker row 3. Technician on site.', timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString() }
        ],
        verifications: { stillExists: 2, fixed: 0, lastVerified: new Date(Date.now() - 1000 * 60 * 30).toISOString() }
    },
    {
        id: '#R-105',
        roomId: 'lib2',
        category: 'Cleanliness',
        issue: 'Spilled Beverage on Desk 12',
        description: 'Coffee spilled on study carrel desk #12 near the window.',
        priority: 'LOW',
        location: { building: 'Library', floor: 2, room: 'Zone B' },
        status: 'Resolved',
        assignedTeam: 'Janitorial Services',
        photo: '',
        reporter: { username: 'student', name: 'Nasira Siddiqa', role: 'student', email: 'nasira@umn.ac.id' },
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
        notes: [
            { author: 'Janitorial Team', role: 'staff', note: 'Desk wiped and sanitized.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 70).toISOString() }
        ],
        verifications: { stillExists: 0, fixed: 3, lastVerified: new Date(Date.now() - 1000 * 60 * 60 * 70).toISOString() }
    }
];

let reports = null;
try { reports = JSON.parse(localStorage.getItem('aeris_reports')); } catch(e) {}
if (!reports || !Array.isArray(reports) || reports.length === 0) {
    reports = defaultReports;
    localStorage.setItem('aeris_reports', JSON.stringify(reports));
}

function saveReports() {
    localStorage.setItem('aeris_reports', JSON.stringify(reports));
    window.dispatchEvent(new Event('storage_reports_updated'));
}

// ----------------------------------------------------------------------------
// 5. Maintenance Tasks Management & Audit History
// ----------------------------------------------------------------------------
const defaultMaintenanceTasks = [
    {
        id: 'TASK-101',
        reportId: '#R-101',
        roomId: 'A101',
        roomName: 'Smart Classroom A101',
        title: 'Replace Classroom A101 Projector Bulb',
        description: 'Dispatched Audio Visual engineer to replace EPSON 1080p lamp and inspect HDMI splitter.',
        category: 'Equipment',
        priority: 'HIGH',
        status: 'Assigned', // Pending, Assigned, In Progress, On Hold, Completed, Cancelled
        assignedTo: 'Pak Hendra (Audio Visual Ops)',
        startDate: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
        expectedCompletionDate: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(),
        completionDate: null,
        notes: [
            { author: 'Facility Admin', note: 'Original stock verified in warehouse. Work scheduled.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 10).toISOString() }
        ]
    },
    {
        id: 'TASK-102',
        reportId: '#R-102',
        roomId: 'gedungD',
        roomName: 'Gedung D — Lounge',
        title: 'Clear AC Unit #1 Blocked Condensate Tray',
        description: 'Remove sludge from drainage line, seal condensation tray, test cold airflow.',
        category: 'Air Conditioning',
        priority: 'HIGH',
        status: 'In Progress',
        assignedTo: 'Pak Bambang (HVAC Ops)',
        startDate: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        expectedCompletionDate: new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString(),
        completionDate: null,
        notes: [
            { author: 'Pak Bambang', note: 'Tray replaced, currently testing drainage under continuous fan load.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6).toISOString() }
        ]
    },
    {
        id: 'TASK-103',
        reportId: '#R-104',
        roomId: 'B201',
        roomName: 'Multimedia Design Lab B201',
        title: 'Rewire & Secure Floor Socket Row 3',
        description: 'Emergency electrical service: rewire burnt grounding pin and replace faceplate.',
        category: 'Electrical',
        priority: 'CRITICAL',
        status: 'Pending',
        assignedTo: 'Pak Doni (Electrical Engineering)',
        startDate: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        expectedCompletionDate: new Date(Date.now() + 1000 * 60 * 60 * 4).toISOString(),
        completionDate: null,
        notes: []
    },
    {
        id: 'TASK-104',
        reportId: '#R-105',
        roomId: 'lib2',
        roomName: 'Library — Floor 2',
        title: 'Desk 12 Beverage Sanitation',
        description: 'Cleaned spilled beverage and sanitized work carrel surface.',
        category: 'Cleanliness',
        priority: 'LOW',
        status: 'Completed',
        assignedTo: 'Janitorial Team',
        startDate: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
        expectedCompletionDate: new Date(Date.now() - 1000 * 60 * 60 * 70).toISOString(),
        completionDate: new Date(Date.now() - 1000 * 60 * 60 * 70).toISOString(),
        notes: [
            { author: 'Janitorial Lead', note: 'Desk dried and disinfected with antimicrobial solution.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 70).toISOString() }
        ]
    }
];

let maintenanceTasks = null;
try { maintenanceTasks = JSON.parse(localStorage.getItem('aeris_maintenance_tasks')); } catch(e) {}
if (!maintenanceTasks || !Array.isArray(maintenanceTasks)) {
    maintenanceTasks = defaultMaintenanceTasks;
    localStorage.setItem('aeris_maintenance_tasks', JSON.stringify(maintenanceTasks));
}

function saveMaintenanceTasks() {
    localStorage.setItem('aeris_maintenance_tasks', JSON.stringify(maintenanceTasks));
    window.dispatchEvent(new Event('storage_tasks_updated'));
}

function createMaintenanceTask(task) {
    const space = spaces.find(s => s.id === task.roomId || s.roomCode === task.roomId);
    const newTask = {
        id: 'TASK-' + Math.floor(Math.random() * 9000 + 1000),
        reportId: task.reportId || null,
        roomId: space ? space.id : task.roomId,
        roomName: space ? space.name : task.roomId,
        title: task.title,
        description: task.description || '',
        category: task.category || 'Facility Maintenance',
        priority: task.priority || 'MEDIUM',
        status: task.status || 'Pending',
        assignedTo: task.assignedTo || 'Facility Maintenance Team',
        startDate: new Date().toISOString(),
        expectedCompletionDate: task.expectedCompletionDate || null,
        completionDate: null,
        notes: task.note ? [{ author: 'Facility Admin', note: task.note, timestamp: new Date().toISOString() }] : []
    };
    maintenanceTasks.unshift(newTask);
    saveMaintenanceTasks();

    logMaintenanceEvent(
        newTask.roomId,
        newTask.reportId,
        'assigned',
        `Maintenance Task Created: ${newTask.title}`,
        `Assigned to ${newTask.assignedTo}. Priority: ${newTask.priority}.`,
        'Task Created'
    );
    return newTask;
}

function updateMaintenanceTask(taskId, updates) {
    const task = maintenanceTasks.find(t => t.id === taskId);
    if (!task) return null;
    const oldStatus = task.status;
    Object.assign(task, updates);

    if (updates.status === 'Completed' && !task.completionDate) {
        task.completionDate = new Date().toISOString();
        if (task.reportId) {
            const relatedRep = reports.find(r => r.id === task.reportId);
            if (relatedRep) {
                relatedRep.status = 'Resolved';
                saveReports();
            }
        }
    }

    saveMaintenanceTasks();

    logMaintenanceEvent(
        task.roomId,
        task.reportId,
        'status_change',
        `Task Status: ${task.status}`,
        `Task "${task.title}" updated from ${oldStatus} to ${task.status}.`,
        task.status
    );
    return task;
}

// ----------------------------------------------------------------------------
// 6. Maintenance Event Timeline Logs
// ----------------------------------------------------------------------------
let maintenanceLogs = null;
try { maintenanceLogs = JSON.parse(localStorage.getItem('aeris_maintenance_logs')); } catch(e) {}
if (!maintenanceLogs || !Array.isArray(maintenanceLogs)) {
    maintenanceLogs = [
        {
            id: 'LOG-001',
            roomId: 'A101',
            roomName: 'Smart Classroom A101',
            reportId: '#R-101',
            type: 'report_created',
            title: 'Projector Malfunction Reported',
            description: 'Initial student report filed via room QR code.',
            actor: 'Nasira Siddiqa (Student)',
            actorRole: 'Student',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(),
            badge: 'Reported'
        },
        {
            id: 'LOG-002',
            roomId: 'A101',
            roomName: 'Smart Classroom A101',
            reportId: '#R-101',
            type: 'verification',
            title: 'Community Verification Received',
            description: '4 classroom attendees confirmed the projector is still unresponsive.',
            actor: 'Community Consensus',
            actorRole: 'Crowd Verify',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 14).toISOString(),
            badge: 'Verified'
        },
        {
            id: 'LOG-003',
            roomId: 'A101',
            roomName: 'Smart Classroom A101',
            reportId: '#R-101',
            type: 'assigned',
            title: 'Work Order Dispatched',
            description: 'Assigned to Audio Visual & IT Ops for bulb replacement.',
            actor: 'Facility Administrator',
            actorRole: 'Admin',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
            badge: 'Assigned'
        },
        {
            id: 'LOG-004',
            roomId: 'gedungD',
            roomName: 'Gedung D — Lounge',
            reportId: '#R-102',
            type: 'report_created',
            title: 'AC Leaking Water Reported',
            description: 'Water dripping onto study tables reported via QR scan.',
            actor: 'Kevin Jonathan (Student)',
            actorRole: 'Student',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(),
            badge: 'Reported'
        },
        {
            id: 'LOG-005',
            roomId: 'gedungD',
            roomName: 'Gedung D — Lounge',
            reportId: '#R-102',
            type: 'status_change',
            title: 'Maintenance In Progress',
            description: 'HVAC team Pak Bambang on site inspecting drainage tray.',
            actor: 'Facility Operations',
            actorRole: 'Staff',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 30).toISOString(),
            badge: 'In Progress'
        }
    ];
    localStorage.setItem('aeris_maintenance_logs', JSON.stringify(maintenanceLogs));
}

function saveMaintenanceLogs() {
    localStorage.setItem('aeris_maintenance_logs', JSON.stringify(maintenanceLogs));
    window.dispatchEvent(new Event('storage_logs_updated'));
}

function logMaintenanceEvent(roomId, reportId, type, title, description, badge = 'Update') {
    const space = spaces.find(s => s.id === roomId || s.roomCode === roomId);
    const session = JSON.parse(localStorage.getItem('aeris_session')) || { name: 'Campus User', role: 'student' };
    
    const event = {
        id: 'LOG-' + Math.floor(Math.random() * 9000 + 1000),
        roomId: space ? space.id : roomId,
        roomName: space ? space.name : roomId,
        reportId: reportId || null,
        type: type,
        title: title,
        description: description,
        actor: session.name + (session.role === 'admin' ? ' (Admin)' : ''),
        actorRole: session.role === 'admin' ? 'Admin' : 'Student',
        timestamp: new Date().toISOString(),
        badge: badge
    };

    maintenanceLogs.unshift(event);
    saveMaintenanceLogs();
    return event;
}

// ----------------------------------------------------------------------------
// 7. Smart Community Verification Storage & Logic
// ----------------------------------------------------------------------------
let verifications = JSON.parse(localStorage.getItem('aeris_verifications')) || [];

function saveVerifications() {
    localStorage.setItem('aeris_verifications', JSON.stringify(verifications));
    window.dispatchEvent(new Event('storage_verifications_updated'));
}

function submitVerification(reportId, response, userId) {
    const report = reports.find(r => r.id === reportId);
    if (!report) return { success: false, message: 'Report not found' };

    const session = JSON.parse(localStorage.getItem('aeris_session')) || {};
    const currentUser = userId || session.username || 'student';

    const existing = verifications.find(v => v.reportId === reportId && v.userId === currentUser);
    if (existing) {
        const msSince = Date.now() - new Date(existing.timestamp).getTime();
        if (msSince < 1000 * 60 * 30) {
            return { success: false, message: 'You have already verified this issue recently. Thank you!' };
        }
    }

    const record = {
        id: 'VERIF-' + Math.floor(Math.random() * 10000),
        reportId: reportId,
        roomId: report.roomId || report.location.room,
        userId: currentUser,
        userName: session.name || currentUser,
        response: response,
        timestamp: new Date().toISOString()
    };
    verifications.unshift(record);
    saveVerifications();

    if (!report.verifications) {
        report.verifications = { stillExists: 0, fixed: 0, lastVerified: new Date().toISOString() };
    }
    if (response === 'still_exists') {
        report.verifications.stillExists = (report.verifications.stillExists || 0) + 1;
    } else {
        report.verifications.fixed = (report.verifications.fixed || 0) + 1;
    }
    report.verifications.lastVerified = new Date().toISOString();
    saveReports();

    logMaintenanceEvent(
        report.roomId,
        report.id,
        'verification',
        'Community Verification Submitted',
        `${session.name || currentUser} verified: "${response === 'still_exists' ? 'Issue still persists' : 'Issue appears to be fixed'}"`,
        response === 'still_exists' ? 'Still Exists' : 'Reported Fixed'
    );

    return { success: true, message: 'Thank you! Your verification has been recorded.', record };
}

function getRoomVerificationIssues(roomId) {
    if (!roomId) return [];
    return reports.filter(r => {
        const matchRoom = (r.roomId && r.roomId === roomId) || 
                          (r.location && r.location.room && r.location.room.toLowerCase().includes(roomId.toLowerCase()));
        return matchRoom && r.status !== 'Resolved' && r.status !== 'Rejected';
    });
}

// ----------------------------------------------------------------------------
// 8. Dynamic Facility Health Calculator
// ----------------------------------------------------------------------------
function calculateRoomHealth(roomOrId) {
    const room = typeof roomOrId === 'string' ? spaces.find(s => s.id === roomOrId || s.roomCode === roomOrId) : roomOrId;
    if (!room) {
        return { status: 'GOOD', label: 'Good', class: 'health-good', badgeClass: 'status-optimal', reason: 'No known issues' };
    }

    const activeReports = reports.filter(r => {
        const match = (r.roomId && r.roomId === room.id) || 
                      (r.location && r.location.room && (r.location.room === room.name || r.location.room === room.roomCode));
        return match && r.status !== 'Resolved' && r.status !== 'Rejected';
    });

    const hasCritical = activeReports.some(r => r.priority === 'CRITICAL' || r.status === 'Critical');
    if (hasCritical) {
        return {
            status: 'CRITICAL',
            label: 'Critical',
            class: 'health-critical',
            badgeClass: 'status-poor',
            color: 'var(--status-poor)',
            reason: 'Critical safety or infrastructure emergency active in this zone.'
        };
    }

    const hasUnderMaintenance = activeReports.some(r => r.status === 'In Progress');
    if (hasUnderMaintenance) {
        return {
            status: 'UNDER MAINTENANCE',
            label: 'Under Maintenance',
            class: 'health-maintenance',
            badgeClass: 'status-maintenance',
            color: 'var(--primary-blue)',
            reason: 'Facility technician is actively performing on-site servicing.'
        };
    }

    const hasAttention = activeReports.some(r => r.priority === 'HIGH' || r.priority === 'MEDIUM') || 
                         (room.comfortScore && room.comfortScore < 65) ||
                         (room.co2 && room.co2 > 1050);
    if (hasAttention) {
        return {
            status: 'NEEDS ATTENTION',
            label: 'Needs Attention',
            class: 'health-attention',
            badgeClass: 'status-moderate',
            color: 'var(--status-moderate)',
            reason: 'Active complaints or environmental readings require inspection.'
        };
    }

    return {
        status: 'GOOD',
        label: 'Good',
        class: 'health-good',
        badgeClass: 'status-optimal',
        color: 'var(--status-optimal)',
        reason: 'All facilities operational and environmental comfort is optimal.'
    };
}

// ----------------------------------------------------------------------------
// 9. User Contributions & Achievement Gamification Engine
// ----------------------------------------------------------------------------
function calculateUserContributions(username) {
    const user = (username || '').trim().toLowerCase();
    
    // User reports
    const userReports = reports.filter(r => 
        (r.reporter && r.reporter.username && r.reporter.username.toLowerCase() === user) ||
        (r.reporter && r.reporter.name && r.reporter.name.toLowerCase().includes(user))
    );
    const resolvedReports = userReports.filter(r => r.status === 'Resolved');

    // User thermal feedbacks
    const userFeedbacks = thermalFeedback.filter(f => f.userId && f.userId.toLowerCase() === user);

    // User verifications
    const userVerifications = verifications.filter(v => v.userId && v.userId.toLowerCase() === user);

    // Points / XP:
    // 50 XP per report, 100 XP bonus for resolved reports, 20 XP per verification, 15 XP per thermal feedback
    const xp = (userReports.length * 50) + 
               (resolvedReports.length * 100) + 
               (userVerifications.length * 25) + 
               (userFeedbacks.length * 15);

    let levelNumber = 1;
    let levelTitle = 'Campus Explorer';
    let nextLevelXp = 300;

    if (xp >= 1500) {
        levelNumber = 4;
        levelTitle = 'Facility Champion';
        nextLevelXp = 3000;
    } else if (xp >= 700) {
        levelNumber = 3;
        levelTitle = 'Active Reporter';
        nextLevelXp = 1500;
    } else if (xp >= 300) {
        levelNumber = 2;
        levelTitle = 'Community Helper';
        nextLevelXp = 700;
    }

    // Achievements calculation
    const achievements = [
        {
            id: 'badge-contributor',
            title: 'Facility Contributor',
            desc: 'Submitted at least 1 verified campus facility report.',
            icon: '🛠️',
            unlocked: userReports.length >= 1
        },
        {
            id: 'badge-reporter',
            title: 'Active Reporter',
            desc: 'Consistent reporter helping keep campus infrastructure reliable (3+ reports).',
            icon: '📢',
            unlocked: userReports.length >= 3
        },
        {
            id: 'badge-helper',
            title: 'Community Helper',
            desc: 'Verified facility condition requests from other campus members (3+ verifications).',
            icon: '🤝',
            unlocked: userVerifications.length >= 3
        },
        {
            id: 'badge-radar',
            title: 'Environmental Watcher',
            desc: 'Regularly submitted community thermal comfort feedback on the radar (5+ feedbacks).',
            icon: '🌿',
            unlocked: userFeedbacks.length >= 5
        },
        {
            id: 'badge-champion',
            title: 'Facility Champion',
            desc: 'Demonstrated exceptional campus engagement across reports, verifications, and comfort radar.',
            icon: '🏆',
            unlocked: userReports.length >= 3 && userVerifications.length >= 2 && userFeedbacks.length >= 3
        }
    ];

    // Build Chronological User Activity List
    const activities = [];
    userReports.forEach(r => {
        activities.push({
            type: 'report',
            title: `Submitted report for ${r.location.building} ${r.location.room}`,
            subtitle: r.issue,
            status: r.status,
            timestamp: r.timestamp
        });
    });
    userFeedbacks.forEach(f => {
        const space = spaces.find(s => s.id === f.roomId);
        activities.push({
            type: 'feedback',
            title: `Provided comfort feedback for ${space ? space.name : f.roomId}`,
            subtitle: `Reported: ${f.rating.replace('_', ' ')}`,
            status: 'Recorded',
            timestamp: f.timestamp
        });
    });
    userVerifications.forEach(v => {
        const report = reports.find(r => r.id === v.reportId);
        activities.push({
            type: 'verification',
            title: `Verified issue ${v.reportId}`,
            subtitle: `Condition: ${v.response === 'still_exists' ? 'Still active' : 'Reported fixed'}`,
            status: 'Verified',
            timestamp: v.timestamp
        });
    });

    activities.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return {
        totalReports: userReports.length,
        resolvedReports: resolvedReports.length,
        totalFeedbacks: userFeedbacks.length,
        totalVerifications: userVerifications.length,
        totalContributions: userReports.length + userFeedbacks.length + userVerifications.length,
        xp,
        levelNumber,
        levelTitle,
        nextLevelXp,
        achievements,
        unlockedCount: achievements.filter(a => a.unlocked).length,
        recentActivity: activities.slice(0, 8)
    };
}

// ----------------------------------------------------------------------------
// 10. Recurring Issue Detection Engine
// ----------------------------------------------------------------------------
function getRecurringIssues() {
    const thirtyDaysAgo = Date.now() - 1000 * 60 * 60 * 24 * 30;
    const recent = reports.filter(r => new Date(r.timestamp).getTime() >= thirtyDaysAgo);

    const grouped = {};
    recent.forEach(r => {
        const roomKey = r.roomId || (r.location ? r.location.building + ' ' + r.location.room : 'Unknown');
        const key = roomKey + ':::' + r.category;
        if (!grouped[key]) {
            const space = spaces.find(s => s.id === r.roomId);
            grouped[key] = {
                roomId: r.roomId || roomKey,
                roomName: space ? space.name : (r.location ? r.location.building + ' ' + r.location.room : roomKey),
                building: r.location ? r.location.building : 'Campus',
                category: r.category,
                reports: []
            };
        }
        grouped[key].reports.push(r);
    });

    const recurring = [];
    Object.values(grouped).forEach(item => {
        if (item.reports.length >= 2) {
            recurring.push({
                ...item,
                count: item.reports.length,
                alertText: `${item.roomName} has experienced ${item.reports.length} ${item.category} reports in the last 30 days.`
            });
        }
    });

    return recurring;
}

// ----------------------------------------------------------------------------
// 11. Community Space Usability Feedback Storage
// ----------------------------------------------------------------------------
let spaceFeedback = JSON.parse(localStorage.getItem('aeris_space_feedback')) || [];

function submitSpaceFeedback(roomId, rating, comment, user) {
    const fb = {
        id: 'FB-' + Math.floor(Math.random() * 10000),
        roomId,
        rating,
        comment,
        user: user || (JSON.parse(localStorage.getItem('aeris_session')) || {}).name || 'Student',
        timestamp: new Date().toISOString()
    };
    spaceFeedback.unshift(fb);
    localStorage.setItem('aeris_space_feedback', JSON.stringify(spaceFeedback));
    window.dispatchEvent(new Event('storage_feedback_updated'));
    return fb;
}

function getSpaceFeedback(roomId) {
    return spaceFeedback.filter(f => f.roomId === roomId);
}

// ----------------------------------------------------------------------------
// 12. Priority Calculation Helper
// ----------------------------------------------------------------------------
function getPriority(cat, issue = '') {
    const issueLower = (issue || '').toLowerCase();
    if (issueLower.includes('fire') || issueLower.includes('explosion') || issueLower.includes('electrical hazard') || issueLower.includes('severe flooding') || issueLower.includes('spark')) {
        return 'CRITICAL';
    }
    if (cat === 'Safety') return 'CRITICAL';
    if (['Plumbing', 'Building / Structure'].includes(cat) || issueLower.includes('leak') || issueLower.includes('dripping')) {
        return 'HIGH';
    }
    if (['Air Conditioning', 'Electrical', 'Equipment'].includes(cat)) {
        return 'MEDIUM';
    }
    return 'LOW'; 
}

// ----------------------------------------------------------------------------
// 13. Live Cross-Tab Synchronization
// ----------------------------------------------------------------------------
window.addEventListener('storage', (e) => {
    if (e.key === 'aeris_reports') {
        try { reports = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_reports_updated'));
    }
    if (e.key === 'aeris_spaces') {
        try { spaces = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_spaces_updated'));
    }
    if (e.key === 'aeris_thermal_feedback') {
        try { thermalFeedback = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_thermal_feedback_updated'));
    }
    if (e.key === 'aeris_maintenance_tasks') {
        try { maintenanceTasks = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_tasks_updated'));
    }
    if (e.key === 'aeris_maintenance_logs') {
        try { maintenanceLogs = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_logs_updated'));
    }
    if (e.key === 'aeris_verifications') {
        try { verifications = JSON.parse(e.newValue) || []; } catch (err) { return; }
        window.dispatchEvent(new Event('storage_verifications_updated'));
    }
});

// ----------------------------------------------------------------------------
// 14. Sensor Telemetry Fluctuation Simulator (Temp, RH, CO2, PM2.5, Noise)
// ----------------------------------------------------------------------------
setInterval(() => {
    spaces.forEach(space => {
        if (!space.baseValues) {
            space.baseValues = { 
                temp: space.temperature, 
                hum: space.humidity, 
                co2: space.co2, 
                occ: space.occupancy, 
                tbl: space.tablesAvailable 
            };
        }
        space.temperature = Math.max(18, Math.min(32, Number((space.baseValues.temp + (Math.random() * 0.4 - 0.2)).toFixed(1))));
        space.humidity = Math.max(30, Math.min(85, Math.round(space.baseValues.hum + (Math.random() * 2 - 1))));
        space.co2 = Math.max(400, Math.round(space.baseValues.co2 + (Math.random() * 20 - 10)));
        if (space.noiseLevel) {
            space.noiseLevel = Math.max(30, Math.min(85, Math.round(space.noiseLevel + (Math.random() * 2 - 1))));
        }
    });
    localStorage.setItem('aeris_spaces', JSON.stringify(spaces));
    window.dispatchEvent(new Event('storage_spaces_updated'));
}, 5000);

// Global Exports
window.mascotSVG = mascotSVG;
window.resolveAssetUrl = resolveAssetUrl;
window.spaces = spaces;
window.reports = reports;
window.maintenanceTasks = maintenanceTasks;
window.maintenanceLogs = maintenanceLogs;
window.verifications = verifications;
window.thermalFeedback = thermalFeedback;
window.saveSpaces = saveSpaces;
window.saveReports = saveReports;
window.saveMaintenanceTasks = saveMaintenanceTasks;
window.saveMaintenanceLogs = saveMaintenanceLogs;
window.saveVerifications = saveVerifications;
window.saveThermalFeedback = saveThermalFeedback;
window.logMaintenanceEvent = logMaintenanceEvent;
window.createMaintenanceTask = createMaintenanceTask;
window.updateMaintenanceTask = updateMaintenanceTask;
window.submitVerification = submitVerification;
window.getRoomVerificationIssues = getRoomVerificationIssues;
window.calculateRoomHealth = calculateRoomHealth;
window.calculateRadarColor = calculateRadarColor;
window.submitThermalFeedback = submitThermalFeedback;
window.getRadarMode = getRadarMode;
window.setRadarMode = setRadarMode;
window.getHeatmapMode = getHeatmapMode;
window.setHeatmapMode = setHeatmapMode;
window.calculateUserContributions = calculateUserContributions;
window.getRecurringIssues = getRecurringIssues;
window.submitSpaceFeedback = submitSpaceFeedback;
window.getSpaceFeedback = getSpaceFeedback;
window.getPriority = getPriority;
