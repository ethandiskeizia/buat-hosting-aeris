/**
 * radar.js - Smart Environmental Radar & Interactive Heatmap Engine
 * 
 * Capabilities:
 * - Smart Environmental Radar Mode (Red, Orange, Yellow, Green, Blue)
 * - Independent Radar Mode ON/OFF preference with live dispatch
 * - Interactive Heatmap Modes:
 *     1. Thermal Comfort (Crowdsourced Radar distribution)
 *     2. Actual Relative Humidity (% sensor telemetry)
 *     3. Facility Health (Good, Needs Attention, Critical, Under Maintenance)
 *     4. Normal Architectural Blueprint Map
 * - Separation of Actual Sensor Telemetry vs Community Thermal Comfort Ratings
 * - Fast 1-2 Tap Thermal Comfort Feedback widget and modal
 * - Dynamic SVG floor plan tinting and radial heat spot overlay
 */

(function () {
    'use strict';

    // -------------------------------------------------------------------------
    // 1. Radar & Heatmap State
    // -------------------------------------------------------------------------
    function isRadarModeEnabled() {
        const val = localStorage.getItem('aeris_radar_mode');
        return val === null ? true : val === 'true';
    }

    function setRadarMode(enabled) {
        localStorage.setItem('aeris_radar_mode', enabled ? 'true' : 'false');
        window.dispatchEvent(new CustomEvent('aeris_radar_mode_changed', { detail: { enabled } }));
    }

    function getHeatmapMode() {
        return localStorage.getItem('aeris_heatmap_mode') || 'thermal';
    }

    function setHeatmapMode(mode) {
        localStorage.setItem('aeris_heatmap_mode', mode);
        window.dispatchEvent(new CustomEvent('aeris_heatmap_mode_changed', { detail: { mode } }));
    }

    // -------------------------------------------------------------------------
    // 2. Heatmap Color Engine
    // -------------------------------------------------------------------------
    function getSpaceHeatmapColor(space, mode) {
        if (!space) return '#A0AEC0';

        // When Radar Mode is disabled, revert map to crisp architectural blueprint
        if (!isRadarModeEnabled()) {
            return '#E2E8F0'; // Clean neutral architectural blueprint tint
        }

        const currentMode = mode || getHeatmapMode();

        if (currentMode === 'normal') {
            return '#E2E8F0'; // Clean neutral blueprint tint
        }

        if (currentMode === 'humidity') {
            const hum = space.humidity || 50;
            if (hum < 40) return '#F4C542'; // Dry (<40%) - Yellow
            if (hum <= 60) return '#5FCB82'; // Optimal (40-60%) - Green
            if (hum <= 70) return '#4A90E2'; // Elevated (61-70%) - Blue
            return '#8A4AF3'; // High/Humid (>70%) - Purple/Deep Blue
        }

        if (currentMode === 'health') {
            const health = window.calculateRoomHealth ? window.calculateRoomHealth(space) : { status: 'GOOD' };
            switch (health.status) {
                case 'CRITICAL': return '#F06B67';
                case 'UNDER MAINTENANCE': return '#7F8FF3';
                case 'NEEDS ATTENTION': return '#FF9800';
                case 'GOOD': default: return '#5FCB82';
            }
        }

        // Default: 'thermal' comfort radar mode
        if (window.calculateRadarColor) {
            const radar = window.calculateRadarColor(space.id);
            return radar.hex || '#5FCB82';
        }

        return '#5FCB82';
    }

    function getHeatmapLegendData(mode) {
        if (!isRadarModeEnabled()) {
            return [
                { label: 'Campus Zone', color: '#CBD5E0', desc: 'Architectural Blueprint Layout (Radar OFF)' }
            ];
        }

        const currentMode = mode || getHeatmapMode();

        if (currentMode === 'thermal') {
            return [
                { label: 'Extremely Hot', color: '#F06B67', desc: 'Stuffy / Severe Heat Discomfort' },
                { label: 'Hot / Warm', color: '#FF9800', desc: 'Warm / Elevating Temp' },
                { label: 'Mixed / Fair', color: '#F4C542', desc: 'Slightly Warm or Variable' },
                { label: 'Comfortable', color: '#5FCB82', desc: 'Optimal Thermal Comfort' },
                { label: 'Cool / Cold', color: '#4A90E2', desc: 'Overcooled / Crisp' }
            ];
        }

        if (currentMode === 'humidity') {
            return [
                { label: 'High (>70%)', color: '#8A4AF3', desc: 'Humid, Risk of condensation/mold' },
                { label: 'Elevated (61–70%)', color: '#4A90E2', desc: 'Slightly high ambient moisture' },
                { label: 'Optimal (40–60%)', color: '#5FCB82', desc: 'Ideal indoor air standard' },
                { label: 'Dry (<40%)', color: '#F4C542', desc: 'Low moisture / air dryness' }
            ];
        }

        if (currentMode === 'health') {
            return [
                { label: 'Good', color: '#5FCB82', desc: 'All equipment verified operational' },
                { label: 'Needs Attention', color: '#FF9800', desc: 'Active complaints or sensor alert' },
                { label: 'Critical', color: '#F06B67', desc: 'Urgent infrastructure breakdown' },
                { label: 'Under Maintenance', color: '#7F8FF3', desc: 'Technician on-site servicing' }
            ];
        }

        // Normal Map
        return [
            { label: 'Campus Zone', color: '#CBD5E0', desc: 'Architectural Blueprint Layout' }
        ];
    }

    // -------------------------------------------------------------------------
    // 3. Smart Environmental Radar Card Component (Inspired by Reference 7)
    // -------------------------------------------------------------------------
    function createRadarCardHtml(roomId) {
        const space = window.spaces.find(s => s.id === roomId || s.roomCode === roomId) || window.spaces[0];
        if (!space) return '';

        const radar = window.calculateRadarColor ? window.calculateRadarColor(space.id) : {
            color: 'GREEN', label: 'Comfortable', hex: '#5FCB82', totalRecent: 0,
            percentage: { extremelyHot: 0, hot: 10, comfortable: 80, cool: 10, cold: 0 },
            confidence: 'Moderate', lastUpdated: 'Just now', actualHumidity: space.humidity, actualTemp: space.temperature, score: '3.1'
        };

        const pct = radar.percentage || { extremelyHot: 0, hot: 0, comfortable: 100, cool: 0, cold: 0 };
        const radarEnabled = isRadarModeEnabled();

        // Actual Humidity vs Crowdsourced Rating badge
        let humStatus = 'Optimal';
        let humColor = '#5FCB82';
        if (space.humidity > 70) { humStatus = 'Humid'; humColor = '#8A4AF3'; }
        else if (space.humidity > 60) { humStatus = 'Elevated'; humColor = '#4A90E2'; }
        else if (space.humidity < 40) { humStatus = 'Dry'; humColor = '#F4C542'; }

        return `
        <div class="aeris-radar-card" id="radar-card-${space.id}" style="
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 24px;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--soft-lavender);
            position: relative;
            overflow: hidden;
        ">
            <!-- Radar Header -->
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px;">
                <div>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:1.15rem; font-weight:700; color:var(--text-main);">Smart Environmental Radar</span>
                        <span style="
                            background: ${radarEnabled ? 'rgba(95,203,130,0.15)' : 'rgba(160,174,192,0.2)'};
                            color: ${radarEnabled ? '#2E9E58' : '#718096'};
                            font-size: 0.6875rem;
                            font-weight: 700;
                            padding: 3px 8px;
                            border-radius: 99px;
                            text-transform: uppercase;
                            letter-spacing: 0.05em;
                        ">${radarEnabled ? '● LIVE RADAR' : 'OFFLINE'}</span>
                    </div>
                    <div style="font-size:0.8125rem; color:var(--text-muted); margin-top:2px;">
                        ${space.name} · ${space.building} (Floor ${space.floor})
                    </div>
                </div>

                <div style="
                    background: ${radar.hex}22;
                    border: 1px solid ${radar.hex};
                    color: ${radar.hex};
                    font-size: 0.75rem;
                    font-weight: 700;
                    padding: 4px 10px;
                    border-radius: 99px;
                    display: flex;
                    align-items: center;
                    gap: 6px;
                ">
                    <span style="width:8px; height:8px; border-radius:50%; background:${radar.hex}; display:inline-block;"></span>
                    ${radar.label}
                </div>
            </div>

            <!-- Two-Stream Telemetry Separation -->
            <div style="
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 12px;
                margin-bottom: 20px;
                background: var(--bg-color);
                padding: 14px;
                border-radius: var(--radius-md);
            ">
                <!-- Stream A: Physical Telemetry Sensor -->
                <div style="border-right: 1px solid var(--soft-lavender); padding-right:12px;">
                    <div style="font-size:0.6875rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:4px;">
                        📡 Physical Telemetry
                    </div>
                    <div style="display:flex; align-items:baseline; gap:6px;">
                        <span style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${Math.round(space.humidity)}%</span>
                        <span style="font-size:0.75rem; font-weight:600; color:${humColor};">${humStatus}</span>
                    </div>
                    <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">
                        Actual Humidity · 🌡️ ${space.temperature.toFixed(1)}°C
                    </div>
                </div>

                <!-- Stream B: Crowdsourced Thermal Consensus -->
                <div style="padding-left:4px;">
                    <div style="font-size:0.6875rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:4px;">
                        👥 Community Thermal Rating
                    </div>
                    <div style="display:flex; align-items:baseline; gap:6px;">
                        <span style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${radar.score || '3.0'}<span style="font-size:0.875rem; font-weight:500; color:var(--text-muted);">/5</span></span>
                        <span style="font-size:0.75rem; font-weight:600; color:${radar.hex};">${radar.confidence} Confidence</span>
                    </div>
                    <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">
                        ${radar.totalRecent} feedback reports in active window
                    </div>
                </div>
            </div>

            <!-- Reference 7 5-Segment Comfort Distribution Bar -->
            <div style="margin-bottom: 20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; font-size:0.75rem;">
                    <span style="font-weight:700; color:var(--text-main);">Thermal Comfort Distribution</span>
                    <span style="color:var(--text-muted); font-size:0.6875rem;">Last update: ${radar.lastUpdated}</span>
                </div>

                <!-- Multi-segment progress bar -->
                <div style="
                    display: flex;
                    height: 12px;
                    border-radius: 99px;
                    overflow: hidden;
                    background: #E2E8F0;
                    margin-bottom: 8px;
                ">
                    <div title="Extremely Hot (${pct.extremelyHot}%)" style="width:${pct.extremelyHot}%; background:#F06B67; transition:width 0.4s ease;"></div>
                    <div title="Hot (${pct.hot}%)" style="width:${pct.hot}%; background:#FF9800; transition:width 0.4s ease;"></div>
                    <div title="Comfortable (${pct.comfortable}%)" style="width:${pct.comfortable}%; background:#5FCB82; transition:width 0.4s ease;"></div>
                    <div title="Cool (${pct.cool}%)" style="width:${pct.cool}%; background:#4A90E2; transition:width 0.4s ease;"></div>
                    <div title="Cold (${pct.cold}%)" style="width:${pct.cold}%; background:#20266F; transition:width 0.4s ease;"></div>
                </div>

                <!-- Micro-legend for distribution -->
                <div style="display:flex; flex-wrap:wrap; justify-content:space-between; font-size:0.6875rem; color:var(--text-muted);">
                    <span><i style="display:inline-block; width:8px; height:8px; border-radius:2px; background:#F06B67; margin-right:4px;"></i>${pct.extremelyHot}% Extr. Hot</span>
                    <span><i style="display:inline-block; width:8px; height:8px; border-radius:2px; background:#FF9800; margin-right:4px;"></i>${pct.hot}% Hot</span>
                    <span><i style="display:inline-block; width:8px; height:8px; border-radius:2px; background:#5FCB82; margin-right:4px;"></i>${pct.comfortable}% Comfortable</span>
                    <span><i style="display:inline-block; width:8px; height:8px; border-radius:2px; background:#4A90E2; margin-right:4px;"></i>${pct.cool}% Cool</span>
                    <span><i style="display:inline-block; width:8px; height:8px; border-radius:2px; background:#20266F; margin-right:4px;"></i>${pct.cold}% Cold</span>
                </div>
            </div>

            <!-- Fast 1-2 Tap Thermal Feedback Section -->
            <div style="border-top: 1px dashed var(--soft-lavender); padding-top: 16px;">
                <div style="font-size:0.8125rem; font-weight:700; color:var(--text-main); margin-bottom:4px;">
                    How does this area feel to you right now?
                </div>
                <p style="font-size:0.75rem; color:var(--text-muted); margin-bottom:10px;">
                    1-Tap Fast Response to help synchronize real-time campus HVAC:
                </p>
                <div style="display:grid; grid-template-columns: repeat(5, 1fr); gap:6px;">
                    <button type="button" class="aeris-feedback-btn" onclick="submitQuickThermal('${space.id}', 'extremely_hot', this)" style="
                        background: rgba(240,107,103,0.1);
                        border: 1px solid rgba(240,107,103,0.3);
                        color: #D64540;
                        padding: 8px 4px;
                        border-radius: var(--radius-sm);
                        font-size: 0.6875rem;
                        font-weight: 700;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s ease;
                    ">
                        <div style="font-size:1.1rem; margin-bottom:2px;">🔥</div>
                        Ex. Hot
                    </button>

                    <button type="button" class="aeris-feedback-btn" onclick="submitQuickThermal('${space.id}', 'hot', this)" style="
                        background: rgba(255,152,0,0.1);
                        border: 1px solid rgba(255,152,0,0.3);
                        color: #D17F00;
                        padding: 8px 4px;
                        border-radius: var(--radius-sm);
                        font-size: 0.6875rem;
                        font-weight: 700;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s ease;
                    ">
                        <div style="font-size:1.1rem; margin-bottom:2px;">☀️</div>
                        Warm
                    </button>

                    <button type="button" class="aeris-feedback-btn" onclick="submitQuickThermal('${space.id}', 'comfortable', this)" style="
                        background: rgba(95,203,130,0.12);
                        border: 1px solid rgba(95,203,130,0.35);
                        color: #2E9E58;
                        padding: 8px 4px;
                        border-radius: var(--radius-sm);
                        font-size: 0.6875rem;
                        font-weight: 700;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s ease;
                    ">
                        <div style="font-size:1.1rem; margin-bottom:2px;">😊</div>
                        Ideal
                    </button>

                    <button type="button" class="aeris-feedback-btn" onclick="submitQuickThermal('${space.id}', 'cool', this)" style="
                        background: rgba(74,144,226,0.1);
                        border: 1px solid rgba(74,144,226,0.3);
                        color: #2A6EB4;
                        padding: 8px 4px;
                        border-radius: var(--radius-sm);
                        font-size: 0.6875rem;
                        font-weight: 700;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s ease;
                    ">
                        <div style="font-size:1.1rem; margin-bottom:2px;">❄️</div>
                        Cool
                    </button>

                    <button type="button" class="aeris-feedback-btn" onclick="submitQuickThermal('${space.id}', 'cold', this)" style="
                        background: rgba(32,38,111,0.08);
                        border: 1px solid rgba(32,38,111,0.25);
                        color: var(--deep-navy);
                        padding: 8px 4px;
                        border-radius: var(--radius-sm);
                        font-size: 0.6875rem;
                        font-weight: 700;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s ease;
                    ">
                        <div style="font-size:1.1rem; margin-bottom:2px;">🧊</div>
                        Cold
                    </button>
                </div>
                <div id="radar-feedback-msg-${space.id}" style="font-size:0.75rem; color:#2E9E58; margin-top:8px; display:none; font-weight:600;"></div>
            </div>
        </div>
        `;
    }

    // -------------------------------------------------------------------------
    // 4. Quick Thermal Submission Handler
    // -------------------------------------------------------------------------
    function submitQuickThermal(roomId, rating, btnElement) {
        if (!window.submitThermalFeedback) {
            alert('Thermal feedback system initializing. Please try again.');
            return;
        }

        const res = window.submitThermalFeedback(roomId, rating);
        const msgEl = document.getElementById(`radar-feedback-msg-${roomId}`);

        if (btnElement) {
            btnElement.style.transform = 'scale(0.92)';
            setTimeout(() => { btnElement.style.transform = 'scale(1)'; }, 150);
        }

        if (res.success) {
            if (msgEl) {
                msgEl.style.display = 'block';
                msgEl.style.color = '#2E9E58';
                msgEl.textContent = `✓ Feedback recorded! Thank you for improving campus comfort.`;
                setTimeout(() => { msgEl.style.display = 'none'; }, 4000);
            }
            // Trigger UI updates
            window.dispatchEvent(new CustomEvent('aeris_thermal_feedback_submitted', { detail: { roomId, rating } }));
            
            // Re-render radar card if mounted
            const cardParent = document.getElementById(`radar-card-${roomId}`)?.parentElement;
            if (cardParent && cardParent.dataset.radarRoom === roomId) {
                cardParent.innerHTML = createRadarCardHtml(roomId);
            }
        } else {
            if (msgEl) {
                msgEl.style.display = 'block';
                msgEl.style.color = '#D17F00';
                msgEl.textContent = res.message;
                setTimeout(() => { msgEl.style.display = 'none'; }, 4000);
            } else {
                alert(res.message);
            }
        }
    }

    // Global Modal for Thermal Feedback
    function openThermalFeedbackModal(roomId) {
        const space = window.spaces.find(s => s.id === roomId || s.roomCode === roomId);
        if (!space) return;

        let modal = document.getElementById('aeris-thermal-modal');
        if (!modal) {
            const html = `
            <div id="aeris-thermal-modal" class="modal-overlay hidden" style="z-index: 9999;">
                <div class="modal-content centered-modal" style="max-width:440px; padding:24px;">
                    <button class="close-btn" onclick="document.getElementById('aeris-thermal-modal').classList.add('hidden')">×</button>
                    <div style="font-size:2rem; margin-bottom:8px;">🌡️</div>
                    <h3 id="atm-room-title" style="margin-bottom:4px; font-size:1.15rem; color:var(--text-main);">Environmental Comfort</h3>
                    <p id="atm-room-desc" style="font-size:0.8125rem; color:var(--text-muted); margin-bottom:16px;">
                        Help other campus members and HVAC operators know how this space feels right now.
                    </p>
                    <div id="atm-radar-card-slot" style="margin-bottom:16px;"></div>
                </div>
            </div>`;
            document.body.insertAdjacentHTML('beforeend', html);
            modal = document.getElementById('aeris-thermal-modal');
        }

        const slot = document.getElementById('atm-radar-card-slot');
        if (slot) {
            slot.dataset.radarRoom = space.id;
            slot.innerHTML = createRadarCardHtml(space.id);
        }

        modal.classList.remove('hidden');
    }

    // -------------------------------------------------------------------------
    // 5. Expose Public API
    // -------------------------------------------------------------------------
    window.AerisRadar = {
        isRadarModeEnabled,
        setRadarMode,
        getHeatmapMode,
        setHeatmapMode,
        getSpaceHeatmapColor,
        getHeatmapLegendData,
        createRadarCardHtml,
        submitQuickThermal,
        openThermalFeedbackModal
    };

    window.isRadarModeEnabled = isRadarModeEnabled;
    window.setRadarMode = setRadarMode;
    window.getHeatmapMode = getHeatmapMode;
    window.setHeatmapMode = setHeatmapMode;
    window.getSpaceHeatmapColor = getSpaceHeatmapColor;
    window.getHeatmapLegendData = getHeatmapLegendData;
    window.createRadarCardHtml = createRadarCardHtml;
    window.submitQuickThermal = submitQuickThermal;
    window.openThermalFeedbackModal = openThermalFeedbackModal;

})();
