/**
 * components.js - Shared UI components (Header, Footer, Modals)
 */

let sharedPhotoDataUrl = '';

function injectHeader(role = 'student') {
    const headerHtml = `
    <!-- Admin Global Alert Banner -->
    <div id="admin-global-banner" class="admin-global-banner hidden">
        <div class="banner-content">
            <div class="banner-text">
                <span class="banner-icon">🚨</span>
                <strong>CRITICAL EMERGENCY ALERT</strong>
                <span id="banner-issue-text"></span>
            </div>
            <div class="banner-actions">
                <button class="btn btn-outline-white btn-sm" onclick="window.location.href='../admin/dashboard.html'">View Alert</button>
                <button class="icon-btn-white" onclick="document.getElementById('admin-global-banner').classList.add('hidden')">×</button>
            </div>
        </div>
    </div>

    <nav class="navbar" id="main-nav">
        <div class="nav-container">
            <div class="logo" onclick="window.location.href='${role === 'admin' ? '../admin/dashboard.html' : '../user/home.html'}'">
                <span class="logo-text">AERIS</span>
            </div>
            
            ${role === 'student' ? `
            <div class="nav-links mobile-hidden" style="align-items:center;">
                <a href="../index.html" class="nav-link" style="color:var(--text-muted);">Overview</a>
                <a href="../user/home.html" class="nav-link">Home</a>
                <a href="../user/study-spots.html" class="nav-link">Directory</a>
                <a href="../user/campus-map.html" class="nav-link">Campus Map</a>
                <a href="../user/reports.html" class="nav-link">Reports</a>
                <a href="../user/achievements.html" class="nav-link">🏆 Achievements</a>
                <button type="button" class="btn btn-outline btn-sm music-toggle-btn" onclick="if(window.AerisAudio) AerisAudio.toggle()" style="padding:5px 10px; font-size:0.75rem; border-radius:var(--radius-pill); display:inline-flex; align-items:center; gap:4px;">
                    <span>🎵</span> <b>Sound: OFF</b>
                </button>
                <button class="btn btn-secondary btn-sm" onclick="openUserQrScanModal()" style="padding:6px 12px; font-size:0.8125rem;">📷 QR</button>
                <div class="nav-divider"></div>
                <div class="header-actions" style="display:flex; align-items:center; gap:10px;">
                    <div class="avatar header-avatar-container" onclick="window.location.href='../user/profile.html'" title="Profile"></div>
                    <button class="btn btn-secondary btn-sm" onclick="logout()">Logout</button>
                </div>
            </div>
            <div style="display:flex; gap:8px;" class="desktop-hidden">
                <button class="btn btn-secondary btn-sm" onclick="openUserQrScanModal()">📷 QR</button>
                <button class="btn btn-emergency" onclick="openEmergencyModal()">🚨 Alert</button>
            </div>
            ` : `
            <div class="nav-links" style="align-items:center;">
                <a href="../index.html" class="nav-link" style="color:var(--text-muted);">Public Overview</a>
                <button type="button" class="btn btn-outline btn-sm music-toggle-btn" onclick="if(window.AerisAudio) AerisAudio.toggle()" style="padding:5px 10px; font-size:0.75rem; border-radius:var(--radius-pill); display:inline-flex; align-items:center; gap:4px;">
                    <span>🎵</span> <b>Sound: OFF</b>
                </button>
                <div class="header-actions" style="display:flex; align-items:center; gap:10px;">
                    <div class="avatar header-avatar-container" onclick="window.location.href='../admin/profile.html'" title="Admin Profile"></div>
                    <button class="btn btn-secondary btn-sm" onclick="logout()">Logout</button>
                </div>
            </div>
            `}
        </div>
    </nav>

    ${role === 'student' ? `
    <!-- Mobile Bottom Navigation -->
    <nav class="mobile-nav" id="mobile-nav">
        <a href="../user/home.html" class="mob-link" data-route="home"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg><span>Home</span></a>
        <a href="../user/study-spots.html" class="mob-link" data-route="directory"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg><span>Rooms</span></a>
        <a href="javascript:void(0)" class="mob-link" onclick="openUserQrScanModal()"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="12" cy="12" r="3"></circle></svg><span>Scan QR</span></a>
        <a href="../user/campus-map.html" class="mob-link" data-route="map"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon><line x1="8" y1="2" x2="8" y2="18"></line><line x1="16" y1="6" x2="16" y2="22"></line></svg><span>3D Map</span></a>
        <a href="../user/reports.html" class="mob-link" data-route="reports"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg><span>Reports</span></a>
    </nav>
    <button class="fab-emergency" onclick="openEmergencyModal()" id="fab-emergency">🚨 Alert</button>
    ` : ''}
    `;
    
    document.body.insertAdjacentHTML('afterbegin', headerHtml);
    
    const currentPath = window.location.pathname;
    document.querySelectorAll('.mob-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href && href !== 'javascript:void(0)' && currentPath.includes(href.split('/').pop())) {
            link.classList.add('active');
        }
    });

    checkGlobalAlerts();
    updateHeaderAvatar();
}

function updateHeaderAvatar() {
    try {
        const session = JSON.parse(localStorage.getItem('aeris_session')) || {};
        const username = session.username || 'student';
        const users = JSON.parse(localStorage.getItem('aeris_users')) || [];
        const userObj = users.find(u => u.username === username) || session;
        const avatarUrl = userObj.avatar_url || localStorage.getItem('aeris_avatar_' + username);

        const containers = document.querySelectorAll('.header-avatar-container');
        containers.forEach(c => {
            if (avatarUrl) {
                c.innerHTML = `<img src="${avatarUrl}" alt="Avatar" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
            } else {
                const initials = (userObj.name || username).split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
                c.textContent = initials || 'NS';
            }
        });
    } catch(e) {}
}

window.addEventListener('aeris_avatar_updated', updateHeaderAvatar);
window.updateHeaderAvatar = updateHeaderAvatar;

function injectFooter() {
    const footerHtml = `
    <footer class="aeris-footer" id="main-footer">
        <div class="footer-container">
            <div class="footer-brand">
                <div class="logo-text">AERIS</div>
                <p>Campus Facility &amp; Environmental Intelligence.</p>
                <div class="footer-mascot" id="footer-mascot">${window.mascotSVG}</div>
            </div>
            <div class="footer-links">
                <div class="footer-col">
                    <h4>ABOUT AERIS</h4>
                    <a href="../index.html">Public Overview</a>
                    <a href="../index.html#features">Features</a>
                    <a href="../index.html#how-it-works">How It Works</a>
                </div>
                <div class="footer-col">
                    <h4>PLATFORM</h4>
                    <a href="../user/home.html">Student Portal</a>
                    <a href="../user/study-spots.html">Room Directory</a>
                    <a href="../admin/dashboard.html">Facility Ops Portal</a>
                    <a href="../admin/maintenance.html">Maintenance Logs</a>
                </div>
                <div class="footer-col">
                    <h4>CAMPUS</h4>
                    <a href="https://www.umn.ac.id" target="_blank" rel="noopener">Universitas Multimedia Nusantara</a>
                    <a href="../user/campus-map.html">Interactive Campus Map</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 AERIS. Universitas Multimedia Nusantara. All Rights Reserved.</p>
        </div>
    </footer>
    `;
    document.body.insertAdjacentHTML('beforeend', footerHtml);
}

function injectModals() {
    const modalsHtml = `
    <!-- Shared Modals Container -->
    <div id="shared-modals">
        <!-- Pulse Modal -->
        <div id="pulse-modal" class="modal-overlay hidden">
            <div class="modal-content centered-modal pulse-content">
                <button class="close-btn" onclick="closeModal('pulse-modal')">×</button>
                <h3>How does this spot feel right now?</h3>
                <div class="pulse-options">
                    <button class="pulse-btn" onclick="submitSharedPulse('Too Cold')"><div class="emoji">🥶</div><span>Too Cold</span></button>
                    <button class="pulse-btn" onclick="submitSharedPulse('Just Right')"><div class="emoji">😌</div><span>Just Right</span></button>
                    <button class="pulse-btn" onclick="submitSharedPulse('Too Stuffy')"><div class="emoji">😮‍💨</div><span>Too Stuffy</span></button>
                    <button class="pulse-btn" onclick="submitSharedPulse('Too Hot')"><div class="emoji">🥵</div><span>Too Hot</span></button>
                </div>
            </div>
        </div>

        <!-- Facility Report Modal -->
        <div id="report-modal" class="modal-overlay hidden">
            <div class="modal-content centered-modal form-modal" style="max-width: 520px;">
                <button class="close-btn" onclick="closeModal('report-modal')">×</button>
                <h3>Report a Facility Issue</h3>
                <p style="font-size:0.8125rem; color:var(--text-muted); margin-bottom:16px;">Directly alert the campus facility maintenance team.</p>
                
                <div class="form-group">
                    <label>Where is the problem?</label>
                    <div class="flex-row">
                        <select id="rep-bldg" class="form-control">
                            <option value="Library">Library</option>
                            <option value="Gedung B">Gedung B</option>
                            <option value="Gedung D">Gedung D</option>
                            <option value="Student Center">Student Center</option>
                            <option value="Academic">Academic Building</option>
                        </select>
                        <select id="rep-floor" class="form-control">
                            <option value="1">Floor 1</option>
                            <option value="2">Floor 2</option>
                            <option value="3">Floor 3</option>
                        </select>
                    </div>
                    <input type="text" id="rep-room" class="form-control mt-2" placeholder="Room / Zone (e.g. A101, Lounge, D204)">
                </div>
                
                <div class="form-group">
                    <label>Report Category</label>
                    <select id="rep-cat" class="form-control">
                        <option value="Air Conditioning">Air Conditioning / HVAC</option>
                        <option value="Equipment">Projector &amp; Equipment</option>
                        <option value="Electrical">Electrical &amp; Outlets</option>
                        <option value="Furniture">Furniture &amp; Tables</option>
                        <option value="Lighting">Lighting &amp; Lamps</option>
                        <option value="Plumbing">Plumbing &amp; Water Leaks</option>
                        <option value="Cleanliness">Cleanliness &amp; Trash</option>
                        <option value="Safety">Safety &amp; Hazards</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Specific Problem Description</label>
                    <textarea id="rep-desc" class="form-control" rows="3" placeholder="Describe what happened so technicians can prepare parts..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Photo Evidence (Optional)</label>
                    <input type="file" id="shared-rep-photo" accept="image/*" class="form-control" onchange="handleSharedPhotoUpload(this)">
                    <div id="shared-photo-preview" style="display:none; margin-top:8px; max-height:140px; border-radius:8px; overflow:hidden; border:1px solid var(--soft-lavender);">
                        <img id="shared-photo-img" src="" alt="Preview" style="width:100%; height:100%; object-fit:cover;">
                    </div>
                </div>

                <button class="btn btn-primary full-width" onclick="submitSharedFacilityReport()">Submit Facility Report</button>
            </div>
        </div>

        <!-- Emergency Modal -->
        <div id="emergency-modal" class="modal-overlay hidden">
            <div class="modal-content centered-modal emergency-form-modal">
                <button class="close-btn" onclick="closeModal('emergency-modal')">×</button>
                <h3 class="emergency-title">Report an Emergency</h3>
                <p class="emergency-sub">Use this only for critical situations that require immediate response.</p>
                
                <div class="form-group">
                    <label>Where is the emergency?</label>
                    <div class="flex-row">
                        <select id="em-bldg" class="form-control">
                            <option value="Library">Library</option>
                            <option value="Gedung B">Gedung B</option>
                            <option value="Gedung D">Gedung D</option>
                            <option value="Student Center">Student Center</option>
                            <option value="Academic">Academic Building</option>
                        </select>
                        <select id="em-floor" class="form-control">
                            <option value="1">Floor 1</option>
                            <option value="2">Floor 2</option>
                            <option value="3">Floor 3</option>
                        </select>
                    </div>
                    <input type="text" id="em-room" class="form-control mt-2" placeholder="Room / Zone">
                </div>
                
                <div class="form-group">
                    <label>What is happening?</label>
                    <div class="emergency-options">
                        <button class="em-chip" onclick="selectEmType(this, 'Fire')">🔥 Fire</button>
                        <button class="em-chip" onclick="selectEmType(this, 'Explosion')">💥 Explosion</button>
                        <button class="em-chip" onclick="selectEmType(this, 'Medical Emergency')">🚑 Medical</button>
                        <button class="em-chip" onclick="selectEmType(this, 'Electrical Hazard')">⚡ Electrical</button>
                        <button class="em-chip" onclick="selectEmType(this, 'Other')">⚠️ Other</button>
                    </div>
                    <input type="hidden" id="em-cat" value="">
                </div>

                <div id="em-confirm-area" class="hidden" style="margin-top: 24px;">
                    <p class="em-confirm-text" style="margin-bottom: 16px;">Are you sure you want to send this emergency alert?</p>
                    <div class="flex-row">
                        <button class="btn btn-secondary full-width" onclick="cancelEmergency()">Cancel</button>
                        <button class="btn btn-emergency full-width" onclick="submitSharedEmergency()">SEND ALERT</button>
                    </div>
                </div>
                <button id="em-pre-submit" class="btn btn-emergency full-width" style="margin-top:24px;" onclick="showEmergencyConfirm()">SEND EMERGENCY ALERT</button>
            </div>
        </div>

        <!-- Success Modal -->
        <div id="success-modal" class="modal-overlay hidden">
            <div class="modal-content centered-modal success-modal">
                <div class="mascot-wrapper" id="success-mascot">${window.mascotSVG}</div>
                <h2 id="succ-title">Report Submitted!</h2>
                <p id="succ-sub">Your facility report has been sent to the Admin.</p>
                <div class="success-details" id="succ-details"></div>
                <div class="flex-row" style="margin-top:24px;">
                    <button class="btn btn-secondary full-width" onclick="closeModal('success-modal')">Close</button>
                    <button class="btn btn-primary full-width" id="succ-action-btn" onclick="window.location.href='../user/reports.html'">View My Reports</button>
                </div>
            </div>
        </div>
    </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalsHtml);
}

function handleSharedPhotoUpload(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            sharedPhotoDataUrl = e.target.result;
            const img = document.getElementById('shared-photo-img');
            const box = document.getElementById('shared-photo-preview');
            if (img && box) {
                img.src = sharedPhotoDataUrl;
                box.style.display = 'block';
            }
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Helper functions for modals
function openModal(id) { 
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden'); 
}
function closeModal(id) { 
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden'); 
}
function openEmergencyModal() {
    document.querySelectorAll('.em-chip').forEach(c => c.classList.remove('selected'));
    document.getElementById('em-cat').value = '';
    document.getElementById('em-confirm-area').classList.add('hidden');
    document.getElementById('em-pre-submit').classList.remove('hidden');
    openModal('emergency-modal');
}
function selectEmType(btn, type) {
    document.querySelectorAll('.em-chip').forEach(c => c.classList.remove('selected'));
    btn.classList.add('selected');
    document.getElementById('em-cat').value = type;
}
function showEmergencyConfirm() {
    if(!document.getElementById('em-cat').value) return alert("Please select what is happening.");
    document.getElementById('em-pre-submit').classList.add('hidden');
    document.getElementById('em-confirm-area').classList.remove('hidden');
}
function cancelEmergency() {
    document.getElementById('em-confirm-area').classList.add('hidden');
    document.getElementById('em-pre-submit').classList.remove('hidden');
}

function submitSharedEmergency() {
    const bldg = document.getElementById('em-bldg').value;
    const floor = document.getElementById('em-floor').value;
    const room = document.getElementById('em-room').value || 'Unknown Zone';
    const type = document.getElementById('em-cat').value;
    const session = JSON.parse(localStorage.getItem('aeris_session')) || { name: 'Student' };
    
    const id = '#E-' + Math.floor(Math.random()*1000).toString().padStart(3, '0');
    
    const report = {
        id, 
        category: 'Safety', 
        issue: type, 
        description: 'Critical emergency reported via user portal.', 
        priority: 'CRITICAL',
        location: { building: bldg, floor, room }, 
        status: 'Critical', 
        timestamp: new Date().toISOString(),
        reporter: { name: session.name, role: session.role || 'student' },
        assignedTeam: 'Campus Emergency Team',
        verifications: { stillExists: 1, fixed: 0, lastVerified: new Date().toISOString() },
        notes: [{ author: 'System Dispatch', note: 'Critical alert triggered and broadcast campus-wide.', timestamp: new Date().toISOString() }]
    };
    
    window.reports.unshift(report);
    window.saveReports();

    if (window.logMaintenanceEvent) {
        window.logMaintenanceEvent(room, id, 'report_created', `EMERGENCY ALERT: ${type}`, `Critical alert reported at ${bldg} Floor ${floor} ${room}.`, 'Critical');
    }
    
    closeModal('emergency-modal');
    showSharedSuccess("Emergency Alert Sent!", "Campus safety teams have been notified immediately.", "", false);
}

function openReportModal(building) {
    document.getElementById('rep-bldg').value = (typeof building === 'string' && building) ? building : 'Library';
    document.getElementById('rep-room').value = '';
    document.getElementById('rep-desc').value = '';
    sharedPhotoDataUrl = '';
    const box = document.getElementById('shared-photo-preview');
    if (box) box.style.display = 'none';
    openModal('report-modal');
}

function submitSharedFacilityReport() {
    const bldg = document.getElementById('rep-bldg').value;
    const floor = document.getElementById('rep-floor').value;
    const room = document.getElementById('rep-room').value || 'General Zone';
    const cat = document.getElementById('rep-cat').value;
    const desc = document.getElementById('rep-desc').value;
    const session = JSON.parse(localStorage.getItem('aeris_session')) || { name: 'Student' };
    
    const priority = window.getPriority(cat, desc);
    const id = '#R-' + Math.floor(Math.random()*1000).toString().padStart(3, '0');
    
    const matchedSpace = window.spaces ? window.spaces.find(s => s.name.toLowerCase().includes(room.toLowerCase()) || (s.roomCode && s.roomCode.toLowerCase() === room.toLowerCase())) : null;

    const report = {
        id, 
        roomId: matchedSpace ? matchedSpace.id : null,
        category: cat, 
        issue: cat + ' Issue', 
        description: desc, 
        priority,
        location: { building: bldg, floor, room }, 
        status: 'Submitted', 
        assignedTeam: 'Facility Maintenance',
        photo: sharedPhotoDataUrl,
        reporter: { name: session.name, role: session.role || 'student' },
        timestamp: new Date().toISOString(),
        verifications: { stillExists: 1, fixed: 0, lastVerified: new Date().toISOString() },
        notes: []
    };
    
    window.reports.unshift(report);
    window.saveReports();

    if (window.logMaintenanceEvent) {
        window.logMaintenanceEvent(matchedSpace ? matchedSpace.id : room, id, 'report_created', `${cat} Issue Reported`, `${desc || 'Report submitted via portal.'}`, priority === 'CRITICAL' ? 'Critical' : 'Submitted');
    }
    
    closeModal('report-modal');
    const details = `
        <div class="sd-row"><span>Report ID:</span> <strong>${id}</strong></div>
        <div class="sd-row"><span>Location:</span> <strong>${bldg} — Fl ${floor} — ${room}</strong></div>
        <div class="sd-row"><span>Category:</span> <strong>${cat}</strong></div>
    `;
    showSharedSuccess("Report Submitted!", "Your facility report has been dispatched to administrators.", details, true);
}

function submitSharedPulse(value) {
    closeModal('pulse-modal');
    showSharedSuccess("Feedback Sent!", "Thanks! Your pulse feedback helps AERIS tune campus comfort.", "", false);
}

function showSharedSuccess(title, sub, detailsHtml, showAction) {
    document.getElementById('succ-title').innerText = title;
    document.getElementById('succ-sub').innerText = sub;
    document.getElementById('succ-details').innerHTML = detailsHtml;
    if(showAction) {
        document.getElementById('succ-action-btn').classList.remove('hidden');
    } else {
        document.getElementById('succ-action-btn').classList.add('hidden');
    }
    openModal('success-modal');
}

function checkGlobalAlerts() {
    const latestCrit = window.reports.find(r => (r.priority === 'CRITICAL' || r.status === 'Critical') && r.status !== 'Resolved');
    const banner = document.getElementById('admin-global-banner');
    const session = JSON.parse(localStorage.getItem('aeris_session'));
    
    if(latestCrit && session && session.role === 'admin') {
        const textSpan = document.getElementById('banner-issue-text');
        if (textSpan) textSpan.textContent = `${latestCrit.issue} reported at ${latestCrit.location.building} — ${latestCrit.location.room}`;
        if(banner) banner.classList.remove('hidden');
    } else {
        if(banner) banner.classList.add('hidden');
    }
}

window.addEventListener('storage_reports_updated', checkGlobalAlerts);

window.injectHeader = injectHeader;
window.injectFooter = injectFooter;
window.injectModals = injectModals;
window.openEmergencyModal = openEmergencyModal;
window.openReportModal = openReportModal;
window.handleSharedPhotoUpload = handleSharedPhotoUpload;
