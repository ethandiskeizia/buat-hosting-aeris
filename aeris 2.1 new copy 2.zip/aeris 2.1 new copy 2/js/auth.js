/**
 * auth.js - AERIS Secure Authentication & Session State Management
 *
 * Implements:
 * - PBKDF2 Password Hashing (SHA-256, per-user 16-byte random salt, 100k iterations) via Web Crypto API
 * - Secure Registration & Account Creation
 * - Verification with automatic migration for legacy/plaintext credentials
 * - Role-Based Access Control (Student vs Admin)
 */

const PBKDF2_ITERATIONS = 100000;
const DEMO_PASSWORD = 'password';

function bytesToHex(bytes) {
    return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(hex) {
    const matched = hex.match(/.{2}/g);
    if (!matched) return new Uint8Array();
    return new Uint8Array(matched.map(h => parseInt(h, 16)));
}

function generateSalt() {
    return bytesToHex(crypto.getRandomValues(new Uint8Array(16)));
}

/**
 * Turn plain text + salt into a PBKDF2 hex string using browser Web Crypto API
 */
async function hashPassword(text, saltHex) {
    const keyMaterial = await crypto.subtle.importKey(
        'raw', 
        new TextEncoder().encode(text), 
        'PBKDF2', 
        false, 
        ['deriveBits']
    );
    const bits = await crypto.subtle.deriveBits(
        { 
            name: 'PBKDF2', 
            salt: hexToBytes(saltHex), 
            iterations: PBKDF2_ITERATIONS, 
            hash: 'SHA-256' 
        },
        keyMaterial, 
        256
    );
    return bytesToHex(new Uint8Array(bits));
}

/**
 * Seed demo users (student and admin) with salted PBKDF2 hashes
 */
async function seedUsers() {
    let stored = null;
    try { stored = JSON.parse(localStorage.getItem('aeris_users') || 'null'); } catch (e) {}

    const demo = [
        { username: 'student', role: 'student', name: 'Nasira Siddiqa Nurrahman', email: 'nasira@umn.ac.id' },
        { username: 'admin', role: 'admin', name: 'Facility Operations Team', email: 'facility@umn.ac.id' }
    ];

    if (!stored || !Array.isArray(stored) || stored.length === 0) {
        for (const u of demo) {
            u.salt = generateSalt();
            u.passwordHash = await hashPassword(DEMO_PASSWORD, u.salt);
        }
        localStorage.setItem('aeris_users', JSON.stringify(demo));
        return;
    }

    // Migration check: ensure existing demo accounts have proper salted hashes
    let modified = false;
    for (const d of demo) {
        const found = stored.find(u => u.username === d.username);
        if (!found) {
            d.salt = generateSalt();
            d.passwordHash = await hashPassword(DEMO_PASSWORD, d.salt);
            stored.push(d);
            modified = true;
        } else if (!found.passwordHash || !found.salt) {
            found.salt = generateSalt();
            found.passwordHash = await hashPassword(found.password || DEMO_PASSWORD, found.salt);
            delete found.password;
            modified = true;
        }
    }
    if (modified) {
        localStorage.setItem('aeris_users', JSON.stringify(stored));
    }
}
const usersReady = seedUsers();

/**
 * Log in user with password verification & safe migration
 */
async function login(username, password) {
    await usersReady;
    const cleanUser = (username || '').trim().toLowerCase();
    const users = JSON.parse(localStorage.getItem('aeris_users') || '[]');
    const user = users.find(u => u.username.toLowerCase() === cleanUser);
    if (!user) return { success: false, message: 'Invalid username or password.' };

    let isMatch = false;
    // Check PBKDF2 hash
    if (user.passwordHash && user.salt) {
        const hash = await hashPassword(password, user.salt);
        if (hash === user.passwordHash) isMatch = true;
    } 
    // Fallback migration if old account had plaintext
    else if (user.password && user.password === password) {
        isMatch = true;
        user.salt = generateSalt();
        user.passwordHash = await hashPassword(password, user.salt);
        delete user.password;
        localStorage.setItem('aeris_users', JSON.stringify(users));
    }

    if (!isMatch) return { success: false, message: 'Invalid username or password.' };

    const session = {
        username: user.username,
        name: user.name || user.username,
        role: user.role || 'student',
        email: user.email || (user.username + '@umn.ac.id'),
        loginAt: new Date().toISOString()
    };
    localStorage.setItem('aeris_session', JSON.stringify(session));

    const isSubdir = window.location.pathname.includes('/user/') || window.location.pathname.includes('/admin/');
    if (user.role === 'student') {
        window.location.href = isSubdir ? 'home.html' : 'user/home.html';
    } else if (user.role === 'admin') {
        localStorage.setItem('aeris_admin_login_flag', 'true');
        window.location.href = isSubdir ? '../admin/dashboard.html' : 'admin/dashboard.html';
    }
    return { success: true };
}

/**
 * Register a new user with PBKDF2 salted hash
 */
async function register(username, password, name, role = 'student') {
    await usersReady;
    const cleanUser = (username || '').trim().toLowerCase();
    if (!cleanUser || cleanUser.length < 3) {
        return { success: false, message: 'Username must be at least 3 characters.' };
    }
    if (!password || password.length < 4) {
        return { success: false, message: 'Password must be at least 4 characters.' };
    }

    const users = JSON.parse(localStorage.getItem('aeris_users') || '[]');
    if (users.some(u => u.username.toLowerCase() === cleanUser)) {
        return { success: false, message: 'Username is already registered. Please choose another.' };
    }

    const salt = generateSalt();
    const passwordHash = await hashPassword(password, salt);

    const newUser = {
        username: cleanUser,
        name: name || cleanUser,
        role: role === 'admin' ? 'admin' : 'student',
        email: cleanUser + '@umn.ac.id',
        salt: salt,
        passwordHash: passwordHash,
        createdAt: new Date().toISOString()
    };
    users.push(newUser);
    localStorage.setItem('aeris_users', JSON.stringify(users));

    // Auto log in new user
    const session = {
        username: newUser.username,
        name: newUser.name,
        role: newUser.role,
        email: newUser.email,
        loginAt: new Date().toISOString()
    };
    localStorage.setItem('aeris_session', JSON.stringify(session));

    const isSubdir = window.location.pathname.includes('/user/') || window.location.pathname.includes('/admin/');
    if (newUser.role === 'student') {
        window.location.href = isSubdir ? 'home.html' : 'user/home.html';
    } else {
        localStorage.setItem('aeris_admin_login_flag', 'true');
        window.location.href = isSubdir ? '../admin/dashboard.html' : 'admin/dashboard.html';
    }
    return { success: true };
}

function logout() {
    localStorage.removeItem('aeris_session');
    const isSubdir = window.location.pathname.includes('/user/') || window.location.pathname.includes('/admin/');
    window.location.href = isSubdir ? '../login.html' : 'login.html';
}

function getCurrentUser() {
    try {
        return JSON.parse(localStorage.getItem('aeris_session'));
    } catch(e) {
        return null;
    }
}

function checkAuth(requiredRole) {
    const session = getCurrentUser();
    const isSubdir = window.location.pathname.includes('/user/') || window.location.pathname.includes('/admin/');
    const loginPath = isSubdir ? '../login.html' : 'login.html';

    if (!session) {
        window.location.href = loginPath;
        return null;
    }

    if (requiredRole && session.role !== requiredRole) {
        if (session.role === 'student') {
            window.location.href = isSubdir ? 'home.html' : 'user/home.html';
        }
        if (session.role === 'admin') {
            window.location.href = isSubdir ? '../admin/dashboard.html' : 'admin/dashboard.html';
        }
        return null;
    }

    return session;
}

async function changePassword(oldPassword, newPassword) {
    await usersReady;
    const session = getCurrentUser();
    if (!session || !session.username) {
        return { success: false, message: 'No active session found. Please log in.' };
    }
    if (!newPassword || newPassword.length < 4) {
        return { success: false, message: 'New password must be at least 4 characters.' };
    }

    const users = JSON.parse(localStorage.getItem('aeris_users') || '[]');
    const user = users.find(u => u.username.toLowerCase() === session.username.toLowerCase());
    if (!user) {
        return { success: false, message: 'User account not found.' };
    }

    // Verify old password
    let isMatch = false;
    if (user.passwordHash && user.salt) {
        const hash = await hashPassword(oldPassword, user.salt);
        if (hash === user.passwordHash) isMatch = true;
    } else if (user.password && user.password === oldPassword) {
        isMatch = true;
    }

    if (!isMatch) {
        return { success: false, message: 'Current password is incorrect.' };
    }

    // Update with new salt and PBKDF2 hash
    user.salt = generateSalt();
    user.passwordHash = await hashPassword(newPassword, user.salt);
    delete user.password;
    localStorage.setItem('aeris_users', JSON.stringify(users));

    return { success: true, message: 'Password successfully updated.' };
}

window.logout = logout;
window.checkAuth = checkAuth;
window.login = login;
window.register = register;
window.hashPassword = hashPassword;
window.changePassword = changePassword;
window.getCurrentUser = getCurrentUser;