/**
 * user.js - Specific logic for user pages (Home, Map, Study Spots, Room Directory)
 */

function createSpaceCard(space, i) {
    const health = window.calculateRoomHealth ? window.calculateRoomHealth(space) : { label: 'Optimal', badgeClass: 'status-optimal' };
    const imgSrc = window.resolveAssetUrl ? window.resolveAssetUrl(space.image) : space.image;
    let badgeClass = space.statusLevel === 'optimal' ? 'status-optimal' : (space.statusLevel === 'poor' ? 'status-poor' : 'status-moderate');

    return `
        <div class="space-card" onclick="window.location.href='../user/room.html?id=${space.id}'">
            <div class="sc-thumb">
                <img src="${imgSrc}" alt="${space.name}" class="sc-space-image" onerror="this.src='../assets/library.jpg'">
                <span class="br-rank ${i === 0 ? 'gold' : ''}">#${i + 1}${i === 0 ? ' Best' : ''}</span>
                <div class="status-badge ${health.badgeClass} sc-badge-img">
                    ${health.label} · IEQ ${space.comfortScore}%
                </div>
            </div>
            <div class="sc-content">
                <div class="flex-between" style="margin-bottom: 4px;">
                    <div class="sc-title">${space.name}</div>
                    <span style="font-size:0.75rem; font-weight:700; color:var(--primary-blue);">📷 ${space.roomCode || space.id}</span>
                </div>
                <div style="font-size: 0.8125rem; color: var(--text-muted); margin-bottom: 8px;">
                    ${space.building} · Floor ${space.floor} · ${space.roomType || 'Study Space'}
                </div>
                <div class="sc-metrics">
                    <span id="val-co2-${space.id}">🌬️ ${space.co2} ppm</span> · 
                    <span id="val-temp-${space.id}">🌡️ ${space.temperature.toFixed(1)}°C</span> · 
                    <span id="val-occ-${space.id}">👥 ${space.occupancy}% full</span>
                </div>
                <div class="sc-tags">${(space.tags || []).map(t => `<span class="tag">${t}</span>`).join('')}</div>
            </div>
        </div>
    `;
}

function renderHomeSpaces() {
    const container = document.getElementById('home-spaces');
    if(!container) return;
    const ranked = [...window.spaces].sort((a,b) => b.match - a.match);
    const text = (document.querySelector('.search-input')?.value || '').trim().toLowerCase();
    const tags = [...document.querySelectorAll('.chip.selected')].map(c => c.dataset.tag ? c.dataset.tag.toLowerCase() : '');
    
    const shown = ranked.map((s, i) => ({ s, i })).filter(({ s }) => {
        const hay = (s.name + ' ' + s.building + ' ' + (s.roomCode || '') + ' ' + (s.tags || []).join(' ')).toLowerCase();
        return hay.includes(text) && tags.every(t => !t || (s.tags || []).some(x => x.toLowerCase().includes(t)));
    });

    container.innerHTML = shown.length
        ? shown.map(({ s, i }) => createSpaceCard(s, i)).join('')
        : '<div class="no-results" style="padding:40px; text-align:center; color:var(--text-muted); background:var(--white); border-radius:var(--radius-md);">No spaces match your search criteria.</div>';
}

// Best Rooms at UMN: top 3 spaces by comfort score
function renderBestRooms() {
    const container = document.getElementById('best-rooms');
    if(!container) return;
    const top = [...window.spaces].sort((a,b) => b.comfortScore - a.comfortScore).slice(0, 3);
    container.innerHTML = top.map((s, i) => {
        const health = window.calculateRoomHealth ? window.calculateRoomHealth(s) : { label: 'Optimal', badgeClass: 'status-optimal' };
        const imgSrc = window.resolveAssetUrl ? window.resolveAssetUrl(s.image) : s.image;

        return `
        <div class="br-card" onclick="window.location.href='../user/room.html?id=${s.id}'">
            <div class="br-img">
                <img src="${imgSrc}" alt="${s.name}" onerror="this.src='../assets/library.jpg'">
                <span class="br-rank ${i === 0 ? 'gold' : ''}">#${i + 1}${i === 0 ? ' Best' : ''}</span>
            </div>
            <div class="br-body">
                <div class="flex-between">
                    <div class="br-name">${s.name}</div>
                    <span class="status-badge ${health.badgeClass}" style="font-size:0.6875rem;">${health.label}</span>
                </div>
                <div class="br-loc">${s.building} · Floor ${s.floor} · ${s.walkTime}</div>
                <div class="br-score"><b>${s.comfortScore}%</b><span>Comfort score · IEQ Telemetry</span></div>
                <div class="br-metrics">
                    <span>🌡️ <i id="br-temp-${s.id}">${s.temperature.toFixed(1)}</i>°C</span>
                    <span>💧 <i id="br-hum-${s.id}">${Math.round(s.humidity)}</i>%</span>
                    <span>🌬️ <i id="br-co2-${s.id}">${s.co2}</i> ppm</span>
                    <span>👥 ${Math.round(s.occupancy)}% full</span>
                </div>
            </div>
        </div>`;
    }).join('');
}

// Update the numbers in place (no re-render, so hover does not flicker)
function updateBestRooms() {
    window.spaces.forEach(s => {
        const t = document.getElementById('br-temp-' + s.id);
        const h = document.getElementById('br-hum-' + s.id);
        const c = document.getElementById('br-co2-' + s.id);
        if(t) t.textContent = s.temperature.toFixed(1);
        if(h) h.textContent = Math.round(s.humidity);
        if(c) c.textContent = s.co2;
    });
}

// 2D Campus Map Logic & Interactive Environmental Heatmap
let currentMapMode = '2D';
let currentFloor = 1;
let mapPopoverNode = null;
let activeHeatmapLayer = localStorage.getItem('aeris_heatmap_mode') || 'thermal';

function switchHeatmapLayer(mode) {
    activeHeatmapLayer = mode;
    localStorage.setItem('aeris_heatmap_mode', mode);
    if (window.setHeatmapMode) window.setHeatmapMode(mode);
    
    document.querySelectorAll('.layer-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.layer === mode);
    });
    
    renderMap(currentFloor);
    renderMapLegend();
}

function toggleRadarMode() {
    const current = window.isRadarModeEnabled ? window.isRadarModeEnabled() : true;
    const next = !current;
    if (window.setRadarMode) window.setRadarMode(next);
    
    const toggleEl = document.getElementById('map-radar-toggle');
    if (toggleEl) {
        toggleEl.className = `radar-mode-toggle ${next ? 'active' : 'inactive'}`;
        toggleEl.innerHTML = `<span>${next ? '●' : '○'}</span> Radar Mode: <b>${next ? 'ON' : 'OFF'}</b>`;
    }
    
    renderMap(currentFloor);
    renderMapLegend();
}

function renderMapLegend() {
    const container = document.getElementById('map-legend-items');
    if (!container) return;
    
    const legendData = window.getHeatmapLegendData ? window.getHeatmapLegendData(activeHeatmapLayer) : [
        { label: 'Optimal', color: '#5FCB82', desc: 'Good' },
        { label: 'Moderate', color: '#FF9800', desc: 'Attention' },
        { label: 'Poor', color: '#F06B67', desc: 'Critical' }
    ];
    
    const titleEl = document.getElementById('map-legend-title');
    if (titleEl) {
        if (activeHeatmapLayer === 'thermal') titleEl.textContent = 'Thermal Comfort Radar';
        else if (activeHeatmapLayer === 'humidity') titleEl.textContent = 'Relative Humidity (% RH)';
        else if (activeHeatmapLayer === 'health') titleEl.textContent = 'Facility Health Status';
        else titleEl.textContent = 'Campus Architectural Zones';
    }
    
    container.innerHTML = legendData.map(item => `
        <div class="legend-item" style="display:flex; align-items:center; gap:8px; margin-bottom:6px; font-size:0.8125rem;">
            <span class="color-dot" style="background:${item.color}; width:10px; height:10px; border-radius:50%; flex:none; box-shadow:0 0 4px ${item.color}88;"></span>
            <span style="font-weight:600; color:var(--text-main);">${item.label}</span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-left:auto;">${item.desc}</span>
        </div>
    `).join('');
}

function getZoneColor(spaceId) {
    const space = window.spaces.find(s => s.id === spaceId);
    if (!space) return '#CBD5E0';
    if (window.getSpaceHeatmapColor) {
        return window.getSpaceHeatmapColor(space, activeHeatmapLayer);
    }
    return space.statusLevel === 'poor' ? '#F06B67' : (space.statusLevel === 'moderate' ? '#FF9800' : '#5FCB82');
}

function getRadarBadgeSvg(spaceId, cx, cy) {
    if (!window.isRadarModeEnabled || !window.isRadarModeEnabled()) return '';
    const radar = window.calculateRadarColor ? window.calculateRadarColor(spaceId) : null;
    let label = '😊 Ideal';
    let bg = '#5FCB82';
    if (radar) {
        if (radar.color === 'RED') { label = '🔥 Ex. Hot'; bg = '#F06B67'; }
        else if (radar.color === 'ORANGE') { label = '☀️ Warm'; bg = '#FF9800'; }
        else if (radar.color === 'YELLOW') { label = '🌤️ Fair'; bg = '#F4C542'; }
        else if (radar.color === 'GREEN') { label = '😊 Ideal'; bg = '#5FCB82'; }
        else if (radar.color === 'BLUE') { label = '❄️ Cool'; bg = '#4A90E2'; }
    }
    const width = 84;
    const height = 22;
    const x = cx - (width / 2);
    const y = cy;
    return `
        <g class="radar-floating-badge" pointer-events="none" filter="drop-shadow(0 2px 5px rgba(0,0,0,0.35))">
            <rect x="${x}" y="${y}" width="${width}" height="${height}" rx="11" fill="${bg}" stroke="#ffffff" stroke-width="1.5" />
            <text x="${cx}" y="${y + 15}" fill="#ffffff" font-size="10" font-weight="800" text-anchor="middle" letter-spacing="0.3px">${label}</text>
        </g>
    `;
}

let currentSelectedRoomId = null;

function renderMap(floor = 1, selectedId = currentSelectedRoomId, targetContainerId = 'map-2d-view') {
    currentFloor = floor;
    currentSelectedRoomId = selectedId;
    const container = document.getElementById(targetContainerId);
    if (!container) return;

    const isRadarOn = window.isRadarModeEnabled ? window.isRadarModeEnabled() : true;

    // Helper for zone styling and selection highlighting
    function getZoneVisuals(zoneId, baseColor, defaultOpacity) {
        const isSelected = selectedId === zoneId;
        if (selectedId) {
            if (isSelected) {
                return {
                    fill: baseColor,
                    fillOpacity: '1.0',
                    stroke: '#FFFFFF',
                    strokeWidth: '4.5',
                    filter: 'filter="url(#heatGlow)"',
                    textColor: '#FFFFFF',
                    textWeight: '800',
                    isSelected: true
                };
            }
            return {
                fill: baseColor,
                fillOpacity: '0.22',
                stroke: '#94A3B8',
                strokeWidth: '1',
                filter: '',
                textColor: isRadarOn ? '#E2E8F0' : 'var(--text-muted)',
                textWeight: '500',
                isSelected: false
            };
        }
        return {
            fill: baseColor,
            fillOpacity: isRadarOn ? defaultOpacity : '0.4',
            stroke: isRadarOn ? baseColor : '#94A3B8',
            strokeWidth: isRadarOn ? '2.5' : '1.5',
            filter: '',
            textColor: isRadarOn ? '#FFFFFF' : 'var(--text-main)',
            textWeight: '700',
            isSelected: false
        };
    }

    // Helper for selected zone beacon pin
    function getSelectedBeacon(cx, cy, label) {
        return `
            <g class="selected-zone-beacon" pointer-events="none" filter="drop-shadow(0 4px 10px rgba(0,0,0,0.65))">
                <circle cx="${cx}" cy="${cy - 30}" r="14" fill="#20266F" stroke="#FFFFFF" stroke-width="2.5" />
                <text x="${cx}" y="${cy - 24}" fill="#FFFFFF" font-size="13" text-anchor="middle">📍</text>
                <rect x="${cx - 75}" y="${cy - 68}" width="150" height="26" rx="13" fill="#20266F" stroke="#FFFFFF" stroke-width="2" />
                <text x="${cx}" y="${cy - 51}" fill="#FFFFFF" font-size="10.5" font-weight="800" text-anchor="middle" letter-spacing="0.5px">SELECTED ROOM</text>
            </g>
        `;
    }

    let zonesSvg = '';

    if (floor === 1) {
        // Floor 1: Canteen, Student Lounge, Gedung D Lounge, Classroom A101, Gedung B Corridor
        const canteenVis = getZoneVisuals('canteen', getZoneColor('canteen'), '0.85');
        const loungeVis = getZoneVisuals('lounge', getZoneColor('lounge'), '0.85');
        const gdVis = getZoneVisuals('gedungD', getZoneColor('gedungD'), '0.85');
        const a101Vis = getZoneVisuals('A101', getZoneColor('A101'), '0.85');
        const corrVis = getZoneVisuals('corridor', getZoneColor('corridor'), '0.75');

        zonesSvg = `
            <!-- Canteen -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('canteen', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('canteen')">
                <path class="zone-path" d="M 60 40 L 260 40 L 260 210 L 60 210 Z" fill="${canteenVis.fill}" fill-opacity="${canteenVis.fillOpacity}" stroke="${canteenVis.stroke}" stroke-width="${canteenVis.strokeWidth}" ${canteenVis.filter} rx="8"/>
                <text x="160" y="105" fill="${canteenVis.textColor}" font-weight="${canteenVis.textWeight}" font-size="13.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Canteen &amp; Food Court</text>
                <text x="160" y="125" fill="${canteenVis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">SC-C1 · Fl 1</text>
                ${getRadarBadgeSvg('canteen', 160, 145)}
                ${canteenVis.isSelected ? getSelectedBeacon(160, 105, 'Canteen') : ''}
            </g>

            <!-- Student Lounge -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('lounge', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('lounge')">
                <path class="zone-path" d="M 280 40 L 490 40 L 490 160 L 280 160 Z" fill="${loungeVis.fill}" fill-opacity="${loungeVis.fillOpacity}" stroke="${loungeVis.stroke}" stroke-width="${loungeVis.strokeWidth}" ${loungeVis.filter} rx="8"/>
                <text x="385" y="85" fill="${loungeVis.textColor}" font-weight="${loungeVis.textWeight}" font-size="13.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Student Lounge</text>
                <text x="385" y="105" fill="${loungeVis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">SC-L1 · Fl 1</text>
                ${getRadarBadgeSvg('lounge', 385, 120)}
                ${loungeVis.isSelected ? getSelectedBeacon(385, 85, 'Student Lounge') : ''}
            </g>

            <!-- Gedung D Lounge -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('gedungD', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('gedungD')">
                <path class="zone-path" d="M 510 40 L 740 40 L 740 210 L 510 210 Z" fill="${gdVis.fill}" fill-opacity="${gdVis.fillOpacity}" stroke="${gdVis.stroke}" stroke-width="${gdVis.strokeWidth}" ${gdVis.filter} rx="8"/>
                <text x="625" y="105" fill="${gdVis.textColor}" font-weight="${gdVis.textWeight}" font-size="13.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Gedung D — Lounge</text>
                <text x="625" y="125" fill="${gdVis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">GD-L1 · Fl 1</text>
                ${getRadarBadgeSvg('gedungD', 625, 145)}
                ${gdVis.isSelected ? getSelectedBeacon(625, 105, 'Gedung D Lounge') : ''}
            </g>

            <!-- Gedung B Corridor -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('corridor', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('corridor')">
                <path class="zone-path" d="M 60 230 L 490 230 L 490 290 L 60 290 Z" fill="${corrVis.fill}" fill-opacity="${corrVis.fillOpacity}" stroke="${corrVis.stroke}" stroke-width="${corrVis.strokeWidth}" ${corrVis.filter} stroke-dasharray="4" rx="6"/>
                <text x="275" y="265" fill="${corrVis.textColor}" font-weight="${corrVis.textWeight}" font-size="12" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Gedung B Main Transit Corridor</text>
                ${corrVis.isSelected ? getSelectedBeacon(275, 260, 'Gedung B Corridor') : ''}
            </g>

            <!-- Smart Classroom A101 -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('A101', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('A101')">
                <path class="zone-path" d="M 60 310 L 360 310 L 360 380 L 60 380 Z" fill="${a101Vis.fill}" fill-opacity="${a101Vis.fillOpacity}" stroke="${a101Vis.stroke}" stroke-width="${a101Vis.strokeWidth}" ${a101Vis.filter} rx="8"/>
                <text x="210" y="348" fill="${a101Vis.textColor}" font-weight="${a101Vis.textWeight}" font-size="13.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Smart Classroom A101</text>
                ${a101Vis.isSelected ? getSelectedBeacon(210, 345, 'Classroom A101') : ''}
            </g>
        `;
    } else if (floor === 2) {
        // Floor 2: Library Fl 2, Multimedia Lab B201, Student Center Mezzanine
        const libVis = getZoneVisuals('lib2', getZoneColor('lib2'), '0.85');
        const b201Vis = getZoneVisuals('B201', getZoneColor('B201'), '0.85');
        const loungeVis = getZoneVisuals('lounge', getZoneColor('lounge'), '0.75');

        zonesSvg = `
            <!-- Library Fl 2 -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('lib2', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('lib2')">
                <path class="zone-path" d="M 60 40 L 380 40 L 380 260 L 220 260 L 220 370 L 60 370 Z" fill="${libVis.fill}" fill-opacity="${libVis.fillOpacity}" stroke="${libVis.stroke}" stroke-width="${libVis.strokeWidth}" ${libVis.filter} rx="8"/>
                <text x="200" y="125" fill="${libVis.textColor}" font-weight="${libVis.textWeight}" font-size="15.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Library — Floor 2</text>
                <text x="200" y="148" fill="${libVis.textColor}" font-weight="500" font-size="12" text-anchor="middle" pointer-events="none" opacity="0.9">Quiet Study Sanctuary · LIB-F2</text>
                ${getRadarBadgeSvg('lib2', 200, 165)}
                ${libVis.isSelected ? getSelectedBeacon(200, 125, 'Library Floor 2') : ''}
            </g>

            <!-- Multimedia Design Lab B201 -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('B201', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('B201')">
                <path class="zone-path" d="M 410 40 L 740 40 L 740 180 L 410 180 Z" fill="${b201Vis.fill}" fill-opacity="${b201Vis.fillOpacity}" stroke="${b201Vis.stroke}" stroke-width="${b201Vis.strokeWidth}" ${b201Vis.filter} rx="8"/>
                <text x="575" y="95" fill="${b201Vis.textColor}" font-weight="${b201Vis.textWeight}" font-size="14.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Multimedia Design Lab B201</text>
                <text x="575" y="118" fill="${b201Vis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">High-Performance Computing · GB-B201</text>
                ${getRadarBadgeSvg('B201', 575, 135)}
                ${b201Vis.isSelected ? getSelectedBeacon(575, 95, 'Multimedia Lab B201') : ''}
            </g>

            <!-- Mezzanine & Upper Gedung D -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('lounge', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('lounge')">
                <path class="zone-path" d="M 410 200 L 740 200 L 740 370 L 410 370 Z" fill="${loungeVis.fill}" fill-opacity="${loungeVis.fillOpacity}" stroke="${loungeVis.stroke}" stroke-width="${loungeVis.strokeWidth}" ${loungeVis.filter} rx="8"/>
                <text x="575" y="270" fill="${loungeVis.textColor}" font-weight="${loungeVis.textWeight}" font-size="14" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Student Center Upper Lounge</text>
                <text x="575" y="295" fill="${loungeVis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">Open Collaboration Zone</text>
                ${getRadarBadgeSvg('lounge', 575, 315)}
                ${loungeVis.isSelected ? getSelectedBeacon(575, 270, 'Upper Lounge') : ''}
            </g>
        `;
    } else {
        // Floor 3: Academic Study Hall, Collaborative Studio D302, Library Quiet Pods
        const studyVis = getZoneVisuals('studyHall', getZoneColor('studyHall'), '0.85');
        const d302Vis = getZoneVisuals('D302', getZoneColor('D302'), '0.85');
        const libVis = getZoneVisuals('lib2', getZoneColor('lib2'), '0.75');

        zonesSvg = `
            <!-- Academic Study Hall -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('studyHall', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('studyHall')">
                <path class="zone-path" d="M 60 40 L 430 40 L 430 250 L 60 250 Z" fill="${studyVis.fill}" fill-opacity="${studyVis.fillOpacity}" stroke="${studyVis.stroke}" stroke-width="${studyVis.strokeWidth}" ${studyVis.filter} rx="8"/>
                <text x="245" y="125" fill="${studyVis.textColor}" font-weight="${studyVis.textWeight}" font-size="15.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Academic Study Hall</text>
                <text x="245" y="148" fill="${studyVis.textColor}" font-weight="500" font-size="12" text-anchor="middle" pointer-events="none" opacity="0.9">AC-F3 · Deep Focus &amp; Ergonomics</text>
                ${getRadarBadgeSvg('studyHall', 245, 170)}
                ${studyVis.isSelected ? getSelectedBeacon(245, 125, 'Study Hall') : ''}
            </g>

            <!-- Collaborative Studio D302 -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('D302', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('D302')">
                <path class="zone-path" d="M 460 40 L 740 40 L 740 250 L 460 250 Z" fill="${d302Vis.fill}" fill-opacity="${d302Vis.fillOpacity}" stroke="${d302Vis.stroke}" stroke-width="${d302Vis.strokeWidth}" ${d302Vis.filter} rx="8"/>
                <text x="600" y="125" fill="${d302Vis.textColor}" font-weight="${d302Vis.textWeight}" font-size="14.5" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Collaborative Studio D302</text>
                <text x="600" y="148" fill="${d302Vis.textColor}" font-weight="500" font-size="11" text-anchor="middle" pointer-events="none" opacity="0.9">GD-D302 · Workshop &amp; Brainstorming</text>
                ${getRadarBadgeSvg('D302', 600, 170)}
                ${d302Vis.isSelected ? getSelectedBeacon(600, 125, 'Studio D302') : ''}
            </g>

            <!-- Floor 3 Upper Library Terrace -->
            <g class="map-zone" style="cursor:pointer;" onmouseover="showMapPopover('lib2', event)" onmouseout="hideMapPopover()" onclick="openSelectedAreaDetail('lib2')">
                <path class="zone-path" d="M 60 280 L 740 280 L 740 370 L 60 370 Z" fill="${libVis.fill}" fill-opacity="${libVis.fillOpacity}" stroke="${libVis.stroke}" stroke-width="${libVis.strokeWidth}" ${libVis.filter} stroke-dasharray="3" rx="6"/>
                <text x="400" y="330" fill="${libVis.textColor}" font-weight="${libVis.textWeight}" font-size="13" text-anchor="middle" pointer-events="none" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.6))">Upper Quiet Reading Mezzanine (Silent Zone)</text>
            </g>
        `;
    }

    const svg = `
    <svg width="100%" height="100%" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid meet" id="svg-map">
        <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="var(--soft-lavender)" stroke-width="0.5"/>
            </pattern>
            <filter id="heatGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="8" result="blur" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.5   0 0 0 0 0.56   0 0 0 0 0.95  0 0 0 1 0"/>
                <feMerge>
                    <feMergeNode />
                    <feMergeNode in="SourceGraphic" />
                </feMerge>
            </filter>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        
        <!-- Floor level indicator watermark -->
        <text x="760" y="45" fill="var(--soft-lavender)" font-size="32" font-weight="800" text-anchor="end" opacity="0.6">LEVEL 0${floor}</text>
        
        <g id="map-zones">
            ${zonesSvg}
        </g>
        
        <!-- Mascot visual watermark on 2D map -->
        <g transform="translate(680, 275)" opacity="0.85">
             <image href="data:image/svg+xml;base64,${btoa(window.mascotSVG)}" width="90" height="90" />
        </g>
    </svg>`;
    
    container.innerHTML = svg;
    if (targetContainerId === 'map-2d-view') {
        renderMapLegend();
        const map3dMascot = document.getElementById('map-mascot');
        if(map3dMascot) {
            map3dMascot.innerHTML = window.mascotSVG;
        }
    }
}

// ----------------------------------------------------------------------------
// Dedicated Selected Area Detail View (Level B Interaction)
// ----------------------------------------------------------------------------
function openSelectedAreaDetail(roomId) {
    const space = window.spaces.find(s => s.id === roomId || s.roomCode === roomId);
    if (!space) return;

    currentSelectedRoomId = space.id;
    currentFloor = space.floor || 1;

    // Highlight room directly on the 2D SVG map!
    renderMap(currentFloor, currentSelectedRoomId, 'map-2d-view');

    // Update floor switcher button state
    document.querySelectorAll('.floor-btn').forEach(b => {
        b.classList.toggle('active', b.textContent.includes(String(currentFloor)));
    });

    // Update sidebar quick filter
    document.querySelectorAll('.map-sidebar-menu .menu-item').forEach(m => {
        const matches = m.getAttribute('onclick') && m.getAttribute('onclick').includes(space.id);
        m.classList.toggle('active', !!matches);
    });

    const overview = document.getElementById('map-overview-section');
    const detail = document.getElementById('map-selected-detail-view');
    if (!detail) return;

    // IMPORTANT: Keep overview visible so user sees the 2D drawing of that room!
    if (overview) overview.classList.remove('hidden');

    const imgUrl = resolveAssetUrl(space.image || 'assets/library.jpg');
    const health = window.calculateRoomHealth ? window.calculateRoomHealth(space) : { status: 'GOOD', label: 'Good' };
    const radar = window.calculateRadarColor ? window.calculateRadarColor(space.id) : { hex: '#5FCB82', label: 'Comfortable' };

    // Find active reports for this room
    const activeReports = (window.reports || []).filter(r => {
        if (!r.location) return false;
        const matchesRoom = r.location.room === space.name || r.location.room === space.id || r.location.room === space.roomCode;
        return matchesRoom && r.status !== 'Resolved';
    });

    const equipmentList = (space.equipment && space.equipment.length > 0) ? space.equipment : [
        'Central HVAC Diffuser Ducting',
        'Ambient LED Panels (5000K)',
        'Standard Power Strip Outlets (x16)',
        'Environmental Air Quality Sensor Unit (AERIS IoT)'
    ];

    let healthColor = '#5FCB82';
    if (health.status === 'CRITICAL') healthColor = '#F06B67';
    else if (health.status === 'NEEDS ATTENTION') healthColor = '#FF9800';
    else if (health.status === 'UNDER MAINTENANCE') healthColor = '#7F8FF3';

    detail.innerHTML = `
        <!-- Top Banner Bar: Selected Zone Badge & Deselect Action -->
        <div class="flex-between" style="margin-bottom: 20px; align-items:center; background:var(--white); padding:16px 22px; border-radius:var(--radius-md); border:2px solid var(--primary-blue); box-shadow:var(--shadow-md); flex-wrap:wrap; gap:12px;">
            <div style="font-size:0.9375rem; color:var(--text-muted); font-weight:500;">
                <span style="background:var(--primary-blue); color:#FFFFFF; font-size:0.6875rem; font-weight:800; padding:3px 8px; border-radius:99px; text-transform:uppercase; letter-spacing:0.04em; margin-right:8px;">
                    📍 HIGHLIGHTED ON 2D MAP
                </span>
                <span>${space.building}</span>
                <span style="margin: 0 6px; color:var(--soft-lavender);">/</span>
                <span>Floor ${space.floor}</span>
                <span style="margin: 0 6px; color:var(--soft-lavender);">/</span>
                <strong style="color:var(--text-main); font-weight:800; font-size:1.05rem;">${space.name}</strong>
            </div>
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="background:${healthColor}22; color:${healthColor}; border:1px solid ${healthColor}; font-size:0.75rem; font-weight:700; padding:5px 12px; border-radius:99px;">
                    ● ${health.status}
                </span>
                <button class="btn btn-secondary btn-sm" onclick="closeSelectedAreaDetail()" style="display:flex; align-items:center; gap:6px;">
                    ✕ Deselect Room (Show All)
                </button>
            </div>
        </div>

        <!-- 2-Column Detail Grid -->
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:24px; align-items:start;">
            
            <!-- Left Column: Photo, Facility Info, Equipment & Reports -->
            <div style="display:flex; flex-direction:column; gap:20px;">
                <!-- Room Hero Card with High-Contrast Text -->
                <div style="background:var(--white); border-radius:var(--radius-lg); overflow:hidden; border:1px solid var(--soft-lavender); box-shadow:var(--shadow-sm);">
                    <div style="position:relative; height:250px; background:#1C2333;">
                        <img src="${imgUrl}" alt="${space.name}" style="width:100%; height:100%; object-fit:cover; display:block;" onerror="this.src='../assets/library.jpg'">
                        <!-- Solid High-Contrast Gradient Backdrop -->
                        <div style="position:absolute; inset:0; background:linear-gradient(180deg, rgba(15,23,42,0.15) 0%, rgba(15,23,42,0.55) 45%, rgba(15,23,42,0.92) 100%);"></div>
                        
                        <div style="position:absolute; top:16px; left:16px; background:rgba(32,38,111,0.9); backdrop-filter:blur(6px); color:#ffffff; padding:5px 12px; border-radius:99px; font-size:0.75rem; font-weight:700; border:1px solid rgba(255,255,255,0.3);">
                            📍 ${space.roomCode || space.id} · ${space.roomType || 'Campus Facility'}
                        </div>
                        
                        <!-- High-Contrast Pure White Room Name & Details -->
                        <div style="position:absolute; bottom:16px; left:20px; right:20px;">
                            <h2 style="font-size:1.75rem; font-weight:800; margin:0 0 4px; color:#FFFFFF !important; text-shadow:0 2px 10px rgba(0,0,0,0.95), 0 0 4px #000000; letter-spacing:-0.01em;">
                                ${space.name}
                            </h2>
                            <div style="font-size:0.9rem; color:#F1F5F9 !important; font-weight:600; text-shadow:0 1px 4px rgba(0,0,0,0.85);">
                                🏢 ${space.building} · Floor ${space.floor} · Max Capacity: ${space.capacity || 60} occupants
                            </div>
                        </div>
                    </div>

                    <div style="padding:20px;">
                        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px;">
                            ${(space.tags || []).map(t => `<span style="background:var(--bg-color); color:var(--text-body); font-size:0.75rem; font-weight:600; padding:4px 10px; border-radius:99px; border:1px solid var(--soft-lavender);"># ${t}</span>`).join('')}
                        </div>

                        <!-- Action Buttons -->
                        <div style="display:flex; gap:10px; flex-wrap:wrap;">
                            <a href="room.html?id=${space.id}" class="btn btn-primary" style="text-decoration:none; flex:1; min-width:180px; text-align:center; justify-content:center;">
                                🔍 Full Room Inspection Page →
                            </a>
                            <a href="reports.html?room=${space.id}" class="btn btn-outline" style="text-decoration:none; flex:1; min-width:180px; text-align:center; justify-content:center;">
                                ⚠️ Report an Issue Here
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Equipment List -->
                <div style="background:var(--white); border-radius:var(--radius-lg); padding:20px; border:1px solid var(--soft-lavender); box-shadow:var(--shadow-sm);">
                    <div style="font-size:1rem; font-weight:700; color:var(--text-main); margin-bottom:12px; display:flex; align-items:center; gap:8px;">
                        <span>🛠️</span> Verified Room Equipment &amp; Infrastructure
                    </div>
                    <ul style="list-style:none; padding:0; margin:0; display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:10px;">
                        ${equipmentList.map(item => `
                            <li style="background:var(--bg-color); padding:10px 12px; border-radius:var(--radius-sm); font-size:0.8125rem; color:var(--text-body); font-weight:500; display:flex; align-items:center; gap:8px; border:1px solid var(--soft-lavender);">
                                <span style="color:#5FCB82; font-weight:800;">✓</span> ${item}
                            </li>
                        `).join('')}
                    </ul>
                </div>

                <!-- Active Reports List -->
                <div style="background:var(--white); border-radius:var(--radius-lg); padding:20px; border:1px solid var(--soft-lavender); box-shadow:var(--shadow-sm);">
                    <div style="font-size:1rem; font-weight:700; color:var(--text-main); margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span>📋</span> Active Facility Reports in this Space
                        </div>
                        <span style="font-size:0.75rem; background:var(--bg-color); padding:2px 8px; border-radius:99px; font-weight:700; color:var(--text-muted);">
                            ${activeReports.length} Active
                        </span>
                    </div>

                    ${activeReports.length === 0 ? `
                        <div style="text-align:center; padding:24px 12px; background:var(--bg-color); border-radius:var(--radius-md); border:1px dashed var(--soft-lavender);">
                            <div style="font-size:2rem; margin-bottom:6px;">✨</div>
                            <div style="font-size:0.875rem; font-weight:700; color:var(--text-main);">All Systems Operating Normally</div>
                            <p style="font-size:0.75rem; color:var(--text-muted); margin:4px 0 0;">
                                No open maintenance tickets or student complaints for this zone.
                            </p>
                        </div>
                    ` : `
                        <div style="display:flex; flex-direction:column; gap:10px;">
                            ${activeReports.map(r => `
                                <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 14px; background:var(--bg-color); border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">
                                    <div>
                                        <div style="font-size:0.875rem; font-weight:700; color:var(--text-main);">${r.issue}</div>
                                        <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Category: ${r.category} · Priority: <b style="color:${r.priority === 'CRITICAL' ? '#F06B67' : '#FF9800'};">${r.priority}</b></div>
                                    </div>
                                    <span style="font-size:0.75rem; font-weight:700; padding:4px 8px; border-radius:6px; background:${r.status === 'In Progress' ? 'rgba(127,143,243,0.15)' : 'rgba(255,152,0,0.15)'}; color:${r.status === 'In Progress' ? '#7F8FF3' : '#FF9800'};">
                                        ${r.status}
                                    </span>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
            </div>

            <!-- Right Column: Physical Sensor Telemetry Grid & Embedded Radar Card -->
            <div style="display:flex; flex-direction:column; gap:20px;">
                <!-- Physical Sensor Telemetry Grid -->
                <div style="background:var(--white); border-radius:var(--radius-lg); padding:20px; border:1px solid var(--soft-lavender); box-shadow:var(--shadow-sm);">
                    <div style="font-size:0.8125rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:14px; display:flex; justify-content:space-between;">
                        <span>📡 Real-Time IoT Telemetry Stream</span>
                        <span style="color:#5FCB82; font-weight:700;">● STREAMING</span>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                        <!-- Temp -->
                        <div style="background:var(--bg-color); padding:14px; border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">
                            <div style="font-size:0.75rem; color:var(--text-muted); font-weight:600; margin-bottom:4px;">🌡️ Temperature</div>
                            <div style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${space.temperature.toFixed(1)}°C</div>
                            <div style="font-size:0.6875rem; color:#5FCB82; font-weight:600; margin-top:2px;">ASHRAE Standard</div>
                        </div>

                        <!-- Humidity -->
                        <div style="background:var(--bg-color); padding:14px; border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">
                            <div style="font-size:0.75rem; color:var(--text-muted); font-weight:600; margin-bottom:4px;">💧 Relative Humidity</div>
                            <div style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${Math.round(space.humidity)}%</div>
                            <div style="font-size:0.6875rem; color:${space.humidity > 65 ? '#8A4AF3' : '#5FCB82'}; font-weight:600; margin-top:2px;">${space.humidity > 65 ? 'Elevated' : 'Target 40-60%'}</div>
                        </div>

                        <!-- CO2 -->
                        <div style="background:var(--bg-color); padding:14px; border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">
                            <div style="font-size:0.75rem; color:var(--text-muted); font-weight:600; margin-bottom:4px;">🌬️ CO2 Indoor Air</div>
                            <div style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${space.co2} <span style="font-size:0.75rem; font-weight:500;">ppm</span></div>
                            <div style="font-size:0.6875rem; color:${space.co2 > 1000 ? '#FF9800' : '#5FCB82'}; font-weight:600; margin-top:2px;">${space.co2 > 1000 ? 'Ventilate' : 'Fresh Air'}</div>
                        </div>

                        <!-- Occupancy -->
                        <div style="background:var(--bg-color); padding:14px; border-radius:var(--radius-md); border:1px solid var(--soft-lavender);">
                            <div style="font-size:0.75rem; color:var(--text-muted); font-weight:600; margin-bottom:4px;">👥 Occupancy Load</div>
                            <div style="font-size:1.5rem; font-weight:800; color:var(--text-main);">${Math.round(space.occupancy)}%</div>
                            <div style="font-size:0.6875rem; color:var(--primary-blue); font-weight:600; margin-top:2px;">${space.tablesAvailable || 6} Desks Free</div>
                        </div>
                    </div>
                </div>

                <!-- Embedded Environmental Radar Card with 1-Tap Feedback -->
                <div id="selected-area-radar-container">
                    ${window.createRadarCardHtml ? window.createRadarCardHtml(space.id) : ''}
                </div>
            </div>
        </div>
    `;

    detail.classList.remove('hidden');
    detail.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeSelectedAreaDetail() {
    currentSelectedRoomId = null;
    const detail = document.getElementById('map-selected-detail-view');
    if (detail) detail.classList.add('hidden');
    
    // Restore all zones to normal opacity on current floor
    renderMap(currentFloor, null, 'map-2d-view');

    // Reset quick filter active menu item to 'All Campus Zones'
    document.querySelectorAll('.map-sidebar-menu .menu-item').forEach((m, idx) => {
        m.classList.toggle('active', idx === 0);
    });
}

function renderRoomBlueprintLocator(containerId, roomId, targetFloor) {
    const space = window.spaces.find(s => s.id === roomId || s.roomCode === roomId) || window.spaces[0];
    if (!space) return;
    const floorToRender = targetFloor || space.floor || 1;
    renderMap(floorToRender, space.id, containerId);
}

// User-Facing QR Code Lookup Modal
function openUserQrScanModal() {
    let modal = document.getElementById('user-qr-scan-modal');
    if (!modal) {
        const modalHtml = `
        <div id="user-qr-scan-modal" class="modal-overlay hidden" style="z-index: 5000;">
            <div class="modal-content centered-modal" style="max-width: 460px;">
                <button class="close-btn" onclick="document.getElementById('user-qr-scan-modal').classList.add('hidden')">×</button>
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📷</div>
                <h3 style="margin-bottom: 6px;">Scan or Enter Room Code</h3>
                <p style="font-size: 0.8125rem; color: var(--text-muted); margin-bottom: 20px;">
                    Scan the QR code placed on classroom doors, or enter the room code to access live status and report issues.
                </p>
                <form onsubmit="event.preventDefault(); handleUserQrSubmit();">
                    <input type="text" id="user-qr-input" class="form-control" placeholder="e.g. A101, LIB-F2, B201, SC-L1" style="text-align:center; font-size:1.125rem; font-weight:700; margin-bottom:14px;" required autocomplete="off">
                    <button type="submit" class="btn btn-primary full-width">Open Room Hub</button>
                </form>
                <div style="margin-top: 16px;">
                    <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 8px;">Quick Selection:</div>
                    <div style="display:flex; flex-wrap:wrap; gap:6px; justify-content:center;">
                        <button type="button" class="chip" onclick="document.getElementById('user-qr-input').value='A101'; handleUserQrSubmit();">A101 Classroom</button>
                        <button type="button" class="chip" onclick="document.getElementById('user-qr-input').value='lib2'; handleUserQrSubmit();">Library Fl 2</button>
                        <button type="button" class="chip" onclick="document.getElementById('user-qr-input').value='B201'; handleUserQrSubmit();">Multimedia Lab B201</button>
                        <button type="button" class="chip" onclick="document.getElementById('user-qr-input').value='gedungD'; handleUserQrSubmit();">Gedung D Lounge</button>
                    </div>
                </div>
            </div>
        </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('user-qr-scan-modal');
    }
    modal.classList.remove('hidden');
    document.getElementById('user-qr-input').focus();
}

function handleUserQrSubmit() {
    const raw = (document.getElementById('user-qr-input').value || '').trim();
    if (!raw) return;

    const match = window.spaces.find(s => 
        s.id.toLowerCase() === raw.toLowerCase() || 
        (s.roomCode && s.roomCode.toLowerCase() === raw.toLowerCase()) ||
        (s.qrCode && s.qrCode.toLowerCase() === raw.toLowerCase()) ||
        s.name.toLowerCase().includes(raw.toLowerCase())
    );

    if (match) {
        window.location.href = `../user/room.html?id=${match.id}`;
    } else {
        alert(`No room found with identifier "${raw}". Try choosing one from the quick selection.`);
    }
}

window.addEventListener('storage_spaces_updated', () => {
    if(window.location.pathname.includes('home.html') || window.location.pathname.includes('study-spots.html')) {
        renderHomeSpaces();
    }
});

// Exports
window.createSpaceCard = createSpaceCard;
window.renderHomeSpaces = renderHomeSpaces;
window.renderBestRooms = renderBestRooms;
window.updateBestRooms = updateBestRooms;
window.renderMap = renderMap;
window.switchFloor = switchFloor;
window.switchMapMode = switchMapMode;
window.showMapPopover = showMapPopover;
window.hideMapPopover = hideMapPopover;
window.openUserQrScanModal = openUserQrScanModal;
window.handleUserQrSubmit = handleUserQrSubmit;
window.switchHeatmapLayer = switchHeatmapLayer;
window.toggleRadarMode = toggleRadarMode;
window.renderMapLegend = renderMapLegend;
window.openSelectedAreaDetail = openSelectedAreaDetail;
window.closeSelectedAreaDetail = closeSelectedAreaDetail;
window.renderRoomBlueprintLocator = renderRoomBlueprintLocator;

document.addEventListener('DOMContentLoaded', () => {
    if(document.getElementById('home-spaces')) renderHomeSpaces();
    if(document.getElementById('map-2d-view')) renderMap(1);
    
    const ctaMascot = document.getElementById('cta-mascot');
    if(ctaMascot) ctaMascot.innerHTML = window.mascotSVG;
});

