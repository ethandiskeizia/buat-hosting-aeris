/**
 * notifications.js - Universal Notification Center & Celebration Engine
 * AERIS 2.1 - Universitas Multimedia Nusantara (UMN)
 * 
 * Features:
 * - Universal Notification Bell & Dropdown for both Students and Admins
 * - Real-time in-app celebratory achievement unlock popups with Canvas Confetti
 * - Unread notification counter with live badge
 * - "Mark All as Read" & individual notification dismissal
 * - In-app toast alerts for facility emergencies, report updates, and community verifications
 */

(function () {
    'use strict';

    const NOTIF_STORAGE_KEY = 'aeris_notifications';
    const SEEN_ACHIEVEMENTS_KEY = 'aeris_seen_achievement_notifs';

    function getStoredNotifications() {
        try {
            const raw = localStorage.getItem(NOTIF_STORAGE_KEY);
            if (raw) return JSON.parse(raw);
        } catch (e) {}
        return [
            {
                id: 'NOTIF-INIT-1',
                type: 'achievement',
                title: 'Welcome to AERIS!',
                message: 'Explore campus rooms, check environmental heatmaps, and report issues to earn XP.',
                icon: '🌱',
                link: '../user/achievements.html',
                is_read: false,
                created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString()
            },
            {
                id: 'NOTIF-INIT-2',
                type: 'system',
                title: 'Smart Environmental Radar Active',
                message: 'Community comfort ratings are now active across 9 campus zones.',
                icon: '🌡️',
                link: '../user/campus-map.html',
                is_read: false,
                created_at: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString()
            }
        ];
    }

    function saveStoredNotifications(list) {
        localStorage.setItem(NOTIF_STORAGE_KEY, JSON.stringify(list));
        window.dispatchEvent(new Event('aeris_notifications_updated'));
    }

    function getNotifications() {
        return getStoredNotifications();
    }

    function addNotification(notif) {
        const list = getStoredNotifications();
        const fullNotif = {
            id: notif.id || ('NOTIF-' + Math.floor(Math.random() * 900000 + 100000)),
            type: notif.type || 'system',
            title: notif.title || 'Notification',
            message: notif.message || '',
            icon: notif.icon || '🔔',
            link: notif.link || null,
            is_read: false,
            created_at: new Date().toISOString()
        };
        list.unshift(fullNotif);
        saveStoredNotifications(list);
        showToast(fullNotif);
        renderNotificationUI();
        return fullNotif;
    }

    function markAsRead(id) {
        const list = getStoredNotifications();
        const target = list.find(n => n.id === id);
        if (target) {
            target.is_read = true;
            saveStoredNotifications(list);
            renderNotificationUI();
        }
    }

    function markAllAsRead() {
        const list = getStoredNotifications();
        list.forEach(n => { n.is_read = true; });
        saveStoredNotifications(list);
        renderNotificationUI();
    }

    // -------------------------------------------------------------------------
    // Canvas Confetti Celebratory Burst (Self-Contained)
    // -------------------------------------------------------------------------
    function fireCelebratoryConfetti() {
        let canvas = document.getElementById('aeris-confetti-canvas');
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.id = 'aeris-confetti-canvas';
            canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:99999;';
            document.body.appendChild(canvas);
        }

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        const ctx = canvas.getContext('2d');
        const particles = [];
        const colors = ['#7F8FF3', '#5FCB82', '#F06B67', '#F4C542', '#4A90E2', '#FF9800', '#20266F'];

        for (let i = 0; i < 90; i++) {
            particles.push({
                x: window.innerWidth / 2,
                y: window.innerHeight / 2 - 80,
                vx: (Math.random() - 0.5) * 16,
                vy: (Math.random() - 0.8) * 18,
                size: Math.random() * 8 + 4,
                color: colors[Math.floor(Math.random() * colors.length)],
                rotation: Math.random() * 360,
                vRot: (Math.random() - 0.5) * 12,
                opacity: 1
            });
        }

        let animationFrame;
        const startTime = Date.now();

        function renderFrame() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const elapsed = Date.now() - startTime;

            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.35; // Gravity
                p.rotation += p.vRot;
                p.opacity = Math.max(0, 1 - (elapsed / 2500));

                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate((p.rotation * Math.PI) / 180);
                ctx.fillStyle = p.color;
                ctx.globalAlpha = p.opacity;
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 1.4);
                ctx.restore();
            });

            if (elapsed < 2600) {
                animationFrame = requestAnimationFrame(renderFrame);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                cancelAnimationFrame(animationFrame);
            }
        }
        renderFrame();
    }

    // -------------------------------------------------------------------------
    // Achievement Unlock Celebration Modal
    // -------------------------------------------------------------------------
    function triggerAchievementCelebration(achievement) {
        if (!achievement) return;

        // Check if already notified
        let seenList = [];
        try { seenList = JSON.parse(localStorage.getItem(SEEN_ACHIEVEMENTS_KEY)) || []; } catch(e) {}
        if (seenList.includes(achievement.id)) return;
        seenList.push(achievement.id);
        localStorage.setItem(SEEN_ACHIEVEMENTS_KEY, JSON.stringify(seenList));

        // Add to notification center
        addNotification({
            type: 'achievement',
            title: `Achievement Unlocked: ${achievement.title}!`,
            message: achievement.description || 'You unlocked a new campus contribution badge!',
            icon: achievement.icon || '🏆',
            link: '../user/achievements.html'
        });

        // Fire Confetti
        fireCelebratoryConfetti();

        // Show Modal Popup
        let modal = document.getElementById('aeris-celebrate-modal');
        if (!modal) {
            const html = `
            <div id="aeris-celebrate-modal" class="modal-overlay hidden" style="z-index: 100000; background: rgba(32,38,111,0.7); backdrop-filter: blur(6px);">
                <div class="modal-content centered-modal" style="max-width: 420px; text-align: center; padding: 36px 28px; border: 2px solid var(--primary-blue); box-shadow: 0 20px 50px rgba(127,143,243,0.3); border-radius: var(--radius-lg); animation: popIn 0.35s cubic-bezier(0.16, 1, 0.3, 1);">
                    <div style="font-size: 3.5rem; margin-bottom: 12px; filter: drop-shadow(0 4px 12px rgba(0,0,0,0.15));" id="cel-icon">🏆</div>
                    <div style="font-size: 0.75rem; font-weight: 800; color: var(--primary-blue); letter-spacing: 2px; text-transform: uppercase; margin-bottom: 6px;">ACHIEVEMENT UNLOCKED</div>
                    <h2 id="cel-title" style="font-size: 1.5rem; margin: 0 0 8px; color: var(--deep-navy);">First Step</h2>
                    <p id="cel-desc" style="font-size: 0.875rem; color: var(--text-body); margin: 0 0 20px; line-height: 1.5;">
                        Submitted your very first campus facility report.
                    </p>
                    <div style="background: rgba(127,143,243,0.1); border-radius: var(--radius-sm); padding: 10px; margin-bottom: 24px; font-weight: 700; color: var(--primary-blue); font-size: 0.875rem;" id="cel-xp">
                        +50 XP Awarded
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-outline full-width" onclick="document.getElementById('aeris-celebrate-modal').classList.add('hidden')">Awesome!</button>
                        <button class="btn btn-primary full-width" onclick="window.location.href='../user/achievements.html'">View All</button>
                    </div>
                </div>
            </div>`;
            document.body.insertAdjacentHTML('beforeend', html);
            modal = document.getElementById('aeris-celebrate-modal');
        }

        document.getElementById('cel-icon').textContent = achievement.icon || '🏆';
        document.getElementById('cel-title').textContent = achievement.title;
        document.getElementById('cel-desc').textContent = achievement.description || achievement.desc || '';
        document.getElementById('cel-xp').textContent = `+${achievement.xp_reward || 50} XP Awarded · Progress Saved`;

        modal.classList.remove('hidden');
    }

    // -------------------------------------------------------------------------
    // Toast Alert
    // -------------------------------------------------------------------------
    function showToast(notif) {
        let toastStack = document.getElementById('aeris-toast-stack');
        if (!toastStack) {
            toastStack = document.createElement('div');
            toastStack.id = 'aeris-toast-stack';
            toastStack.style.cssText = 'position:fixed;top:20px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:10px;max-width:360px;width:calc(100vw - 40px);pointer-events:none;';
            document.body.appendChild(toastStack);
        }

        const toast = document.createElement('div');
        toast.style.cssText = `
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(32,38,111,0.25);
            border-left: 5px solid ${notif.type === 'achievement' ? '#5FCB82' : '#7F8FF3'};
            padding: 14px 16px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            pointer-events: auto;
            animation: slideInRight 0.3s ease;
            transition: all 0.3s ease;
        `;
        toast.innerHTML = `
            <div style="font-size:1.6rem; line-height:1;">${notif.icon || '🔔'}</div>
            <div style="flex:1;">
                <div style="font-size:0.875rem; font-weight:700; color:#20266F; margin-bottom:2px;">${notif.title}</div>
                <div style="font-size:0.75rem; color:#4A5568; line-height:1.4;">${notif.message}</div>
            </div>
            <button style="border:none; background:none; color:#A0AEC0; cursor:pointer; font-size:1.1rem; line-height:1; padding:0 4px;" onclick="this.parentElement.remove()">×</button>
        `;

        toastStack.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(30px)';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    // -------------------------------------------------------------------------
    // Mount Universal Notification Bell & UI
    // -------------------------------------------------------------------------
    function mountNotificationBell() {
        // Try user navbar action row first, then admin action row
        const target = document.querySelector('.header-actions') || document.querySelector('.fac-top-actions');
        if (!target) return;

        if (document.getElementById('aeris-universal-bell')) return;

        const wrap = document.createElement('div');
        wrap.id = 'aeris-universal-bell';
        wrap.className = 'aeris-bell-container';
        wrap.style.cssText = 'position:relative; display:inline-block;';

        wrap.innerHTML = `
            <button class="aeris-bell-btn" type="button" aria-label="Notifications" title="Notifications" style="
                position: relative;
                width: 38px;
                height: 38px;
                border-radius: 50%;
                border: 1px solid var(--soft-lavender);
                background: var(--white);
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.1rem;
                transition: var(--transition);
            ">
                🔔
                <span class="aeris-bell-badge" style="
                    position: absolute;
                    top: -4px;
                    right: -4px;
                    background: var(--status-poor);
                    color: #fff;
                    font-size: 0.6875rem;
                    font-weight: 800;
                    padding: 2px 6px;
                    border-radius: 99px;
                    display: none;
                ">0</span>
            </button>

            <!-- Dropdown Menu -->
            <div class="aeris-notif-dropdown hidden" style="
                position: absolute;
                right: 0;
                top: 48px;
                width: 340px;
                max-height: 480px;
                background: var(--white);
                border-radius: var(--radius-md);
                box-shadow: 0 16px 40px rgba(32,38,111,0.25);
                border: 1px solid var(--soft-lavender);
                z-index: 10000;
                overflow: hidden;
                display: flex;
                flex-direction: column;
            ">
                <div style="padding: 12px 16px; border-bottom: 1px solid var(--soft-lavender); display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-weight: 700; color: var(--deep-navy); font-size: 0.875rem;">Notifications</div>
                    <button type="button" style="border: none; background: none; color: var(--primary-blue); font-size: 0.75rem; font-weight: 600; cursor: pointer;" onclick="AerisNotify.markAllRead()">Mark all read</button>
                </div>
                <div class="aeris-notif-list" style="overflow-y: auto; max-height: 380px;">
                    <!-- Injected items -->
                </div>
                <div style="padding: 8px 16px; border-top: 1px solid var(--soft-lavender); text-align: center; background: var(--bg-color);">
                    <a href="../user/achievements.html" style="font-size: 0.75rem; color: var(--primary-blue); text-decoration: none; font-weight: 600;">🏆 View Achievements &amp; Rewards →</a>
                </div>
            </div>
        `;

        target.insertBefore(wrap, target.firstChild);

        const bellBtn = wrap.querySelector('.aeris-bell-btn');
        const dropdown = wrap.querySelector('.aeris-notif-dropdown');

        bellBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('hidden');
            renderNotificationUI();
        });

        document.addEventListener('click', (e) => {
            if (!wrap.contains(e.target)) {
                dropdown.classList.add('hidden');
            }
        });

        renderNotificationUI();
    }

    function renderNotificationUI() {
        const notifs = getStoredNotifications();
        const unreadCount = notifs.filter(n => !n.is_read).length;

        // Update badges
        const badges = document.querySelectorAll('.aeris-bell-badge');
        badges.forEach(b => {
            if (unreadCount > 0) {
                b.style.display = 'block';
                b.textContent = unreadCount > 9 ? '9+' : unreadCount;
            } else {
                b.style.display = 'none';
            }
        });

        const listContainer = document.querySelector('.aeris-notif-list');
        if (!listContainer) return;

        if (notifs.length === 0) {
            listContainer.innerHTML = '<div style="padding:24px; text-align:center; color:var(--text-muted); font-size:0.8125rem;">No notifications right now.</div>';
            return;
        }

        listContainer.innerHTML = notifs.map(n => `
            <div class="aeris-notif-row" onclick="AerisNotify.handleClick('${n.id}', '${n.link || ''}')" style="
                padding: 12px 16px;
                border-bottom: 1px solid #F3F4FA;
                display: flex;
                gap: 10px;
                align-items: flex-start;
                cursor: pointer;
                background: ${n.is_read ? 'transparent' : 'rgba(127,143,243,0.06)'};
                transition: background 0.2s ease;
            ">
                <span style="font-size: 1.3rem;">${n.icon || '🔔'}</span>
                <div style="flex:1;">
                    <div style="font-size: 0.8125rem; font-weight: ${n.is_read ? '600' : '700'}; color: var(--text-main);">${n.title}</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">${n.message}</div>
                    <div style="font-size: 0.6875rem; color: var(--text-muted); margin-top: 4px;">${new Date(n.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                </div>
                ${!n.is_read ? '<span style="width:8px; height:8px; border-radius:50%; background:var(--primary-blue); margin-top:6px; flex:none;"></span>' : ''}
            </div>
        `).join('');
    }

    function handleNotificationClick(id, link) {
        markAsRead(id);
        const dropdown = document.querySelector('.aeris-notif-dropdown');
        if (dropdown) dropdown.classList.add('hidden');
        if (link) window.location.href = link;
    }

    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(mountNotificationBell, 100);
    });

    window.AerisNotify = {
        add: addNotification,
        celebrateAchievement: triggerAchievementCelebration,
        markRead: markAsRead,
        markAllRead: markAllAsRead,
        handleClick: handleNotificationClick,
        getNotifications: getNotifications,
        mount: mountNotificationBell
    };
})();
