/**
 * splash.js - Brand splash screen for AERIS.
 * Shows logo + mascot + loading bar for ~2 seconds, then fades out.
 * Shown once per login session (sessionStorage); shows again after the next login.
 * Load it in <head> of user/home.html, after the CSS links.
 */
(function () {
    var KEY = 'aeris_splash_seen';
    var DURATION = 2200;   // ms before the splash closes by itself
    var root = document.documentElement;

    // Reset the flag when the user logs out, so the splash shows again on the next login
    document.addEventListener('DOMContentLoaded', function () {
        var origLogout = window.logout;
        if (typeof origLogout === 'function') {
            window.logout = function () {
                try { sessionStorage.removeItem(KEY); } catch (e) {}
                return origLogout.apply(this, arguments);
            };
        }
    });

    var seen = false;
    try { seen = sessionStorage.getItem(KEY) === '1'; } catch (e) {}
    if (seen) return;

    // Cover the page right away so the Home content does not flash before the splash is built
    root.classList.add('splash-on');
    var base = document.createElement('style');
    base.textContent = 'html.splash-on{overflow:hidden}' +
        'html.splash-on::before{content:"";position:fixed;inset:0;background:var(--bg-color,#F7F8FC);z-index:19999}';
    document.head.appendChild(base);

    var el = null, timer = null;

    function close() {
        clearTimeout(timer);
        try { sessionStorage.setItem(KEY, '1'); } catch (e) {}
        if (!el) { root.classList.remove('splash-on'); return; }
        el.classList.add('closing');
        setTimeout(function () {
            if (el && el.parentNode) el.parentNode.removeChild(el);
            root.classList.remove('splash-on');
            el = null;
        }, 500);
    }

    function css() {
        var st = document.createElement('style');
        st.textContent = '\
#aeris-splash{position:fixed;inset:0;z-index:20000;display:flex;flex-direction:column;align-items:center;justify-content:center;background:linear-gradient(160deg,var(--bg-color),var(--soft-lavender));font-family:Inter,system-ui,sans-serif;cursor:pointer}\
#aeris-splash.closing{opacity:0;transform:scale(1.04);transition:opacity .5s ease,transform .5s ease;pointer-events:none}\
.sp-mascot{width:120px;height:132px;animation:sp-pop .7s cubic-bezier(.2,.9,.3,1.2) both}\
.sp-brand{font-size:2.75rem;font-weight:700;letter-spacing:6px;color:var(--primary-blue);margin:12px 0 0;padding-left:6px;animation:sp-up .6s .2s ease both}\
.sp-tag{color:var(--text-body);font-size:1.0625rem;margin:6px 0 0;animation:sp-up .6s .35s ease both}\
.sp-bar{width:160px;height:4px;border-radius:99px;background:var(--soft-lavender);margin-top:36px;overflow:hidden;animation:sp-up .6s .5s ease both}\
.sp-bar i{display:block;height:100%;width:0;border-radius:99px;background:var(--primary-blue);animation:sp-load ' + (DURATION - 300) + 'ms .3s ease-out forwards}\
.sp-hint{position:absolute;bottom:28px;font-size:.75rem;color:var(--text-muted)}\
@keyframes floatMascot{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}\
@keyframes sp-pop{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:none}}\
@keyframes sp-up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}\
@keyframes sp-load{to{width:100%}}\
@media (prefers-reduced-motion:reduce){.sp-mascot,.sp-brand,.sp-tag,.sp-bar{animation:none}.sp-bar i{animation-duration:1ms}}';
        document.head.appendChild(st);
    }

    function build() {
        if (document.getElementById('aeris-splash')) return;
        css();
        el = document.createElement('div');
        el.id = 'aeris-splash';
        el.setAttribute('role', 'status');
        el.setAttribute('aria-label', 'Loading AERIS');
        el.innerHTML =
            '<div class="sp-mascot">' + (window.mascotSVG || '') + '</div>' +
            '<h1 class="sp-brand">AERIS</h1>' +
            '<p class="sp-tag">Find your comfort zone.</p>' +
            '<div class="sp-bar"><i></i></div>' +
            '<div class="sp-hint">Tap to skip</div>';
        document.body.appendChild(el);
        el.addEventListener('click', close);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && el) close(); });
        timer = setTimeout(close, DURATION);
    }

    document.addEventListener('DOMContentLoaded', build);
})();
