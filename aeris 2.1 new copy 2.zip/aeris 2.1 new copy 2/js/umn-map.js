/**
 * umn-map.js - Interactive layer for the 3D UMN campus map.
 *
 * Sits on top of umn-viewer.js (window.UMNViewer) and adds the same kind of
 * interaction as a web campus map (e.g. map.smu.edu) while keeping the
 * oblique 3D view:
 *   - building pins read from the POI_* nodes inside UMN.gltf
 *   - click a pin -> camera flies to the building + info popup opens
 *   - popup says whether the building has active problem reports (or is clear)
 *   - pin colour / badge / pulse show report severity, live
 *   - map controls: home, layers, compass, zoom +/-, fullscreen
 *   - left-drag = pan on the ground, right-drag = rotate, wheel = zoom
 *
 * Public API: window.UMNMap { focus(poiId), focusReport(reportId), home(), closePanel(), pois }
 */
(function () {
    'use strict';
    if (window.UMNMap) return;

    var SELECTORS = ['#map-3d-view', '.admin-map-panel'];
    var IS_ADMIN = document.body.classList.contains('admin-mode');
    var PRI_RANK = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
    var LEVELS = {
        4: { key: 'crit', label: 'Critical' },
        3: { key: 'high', label: 'High' },
        2: { key: 'med', label: 'Medium' },
        1: { key: 'low', label: 'Low' },
        0: { key: 'clear', label: 'No active problems' }
    };

    var S = {
        ready: false, V3: null, container: null, root: null, panel: null, summary: null,
        pois: [], pins: {}, selected: null, home: null, anim: null, groundY: 0, radius: 1,
        showLabels: true, onlyProblems: false, fresh: {}, hintDone: false
    };

    /* ------------------------------------------------------------------ utils */
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function lc(s) { return String(s || '').trim().toLowerCase(); }
    function ago(iso) {
        var t = Date.parse(iso); if (!t) return '';
        var m = Math.max(0, Math.round((Date.now() - t) / 60000));
        if (m < 1) return 'just now';
        if (m < 60) return m + ' min ago';
        var h = Math.round(m / 60); if (h < 24) return h + ' h ago';
        return Math.round(h / 24) + ' d ago';
    }
    function reportsList() { return Array.isArray(window.reports) ? window.reports : []; }
    function belongsTo(poi, r) {
        var b = lc(r && r.location && r.location.building);
        return poi.buildings.some(function (x) { return lc(x) === b; });
    }
    function reportsFor(poi) {
        var all = reportsList().filter(function (r) { return belongsTo(poi, r); });
        var active = all.filter(function (r) { return r.status !== 'Resolved'; });
        active.sort(function (a, b) {
            return (PRI_RANK[b.priority] || 0) - (PRI_RANK[a.priority] || 0) ||
                (Date.parse(b.timestamp) || 0) - (Date.parse(a.timestamp) || 0);
        });
        return { active: active, resolved: all.length - active.length };
    }
    function levelOf(active) {
        var top = 0;
        active.forEach(function (r) { top = Math.max(top, PRI_RANK[r.priority] || 1); });
        return top;
    }
    function poiById(id) { return S.pois.filter(function (p) { return p.id === id; })[0]; }
    function poiForReport(r) { return S.pois.filter(function (p) { return belongsTo(p, r); })[0]; }

    /* ----------------------------------------------------------------- styles */
    function injectStyles() {
        if (document.getElementById('umnm-styles')) return;
        var css = '\
.umn3d-reset{display:none !important}\
.umnm-root{position:absolute;inset:0;pointer-events:none;z-index:4;overflow:hidden;font-family:"Inter",system-ui,sans-serif}\
.umnm-root *{box-sizing:border-box}\
.umnm-has-panel .umn3d-hint{display:none}.umnm-has-panel .umnm-legend{display:none}\
.umnm-pin{position:absolute;left:0;top:0;width:0;height:0;pointer-events:none;will-change:transform}\
.umnm-pin-btn{position:absolute;left:-18px;top:-46px;width:36px;height:46px;padding:0;border:0;background:none;cursor:pointer;pointer-events:auto;filter:drop-shadow(0 3px 5px rgba(32,38,111,.35));transition:transform .15s ease;transform-origin:50% 100%}\
.umnm-pin-btn:hover,.umnm-pin.selected .umnm-pin-btn{transform:scale(1.18)}\
.umnm-pin-btn:focus-visible{outline:2px solid #20266F;outline-offset:2px;border-radius:8px}\
.umnm-pin-svg{display:block;width:36px;height:46px}\
.umnm-badge{position:absolute;top:-6px;right:-8px;min-width:20px;height:20px;padding:0 5px;border-radius:99px;background:#20266F;color:#fff;font:700 11px/20px "Inter",system-ui,sans-serif;text-align:center;border:2px solid #fff;font-style:normal}\
.umnm-label{position:absolute;left:0;top:5px;transform:translateX(-50%);white-space:nowrap;font-weight:700;font-size:12px;color:#20266F;pointer-events:none;text-shadow:-1px -1px 0 #fff,1px -1px 0 #fff,-1px 1px 0 #fff,1px 1px 0 #fff,0 0 5px #fff}\
.umnm-pulse{position:absolute;left:50%;bottom:-6px;width:12px;height:12px;margin-left:-6px;border-radius:50%;background:var(--c);opacity:0;pointer-events:none}\
.umnm-pin.crit .umnm-pulse,.umnm-pin.high .umnm-pulse{animation:umnm-pulse 1.6s ease-out infinite}\
.umnm-pin.med .umnm-pulse,.umnm-pin.low .umnm-pulse{animation:umnm-pulse 2.8s ease-out infinite}\
.umnm-pin.fresh .umnm-pin-btn{animation:umnm-shake .8s ease 4}\
.umnm-new{position:absolute;left:50%;top:-64px;transform:translateX(-50%);background:#F06B67;color:#fff;font:700 10px/1 "Inter",system-ui,sans-serif;padding:4px 7px;border-radius:99px;letter-spacing:.04em;display:none;pointer-events:none}\
.umnm-pin.fresh .umnm-new{display:block}\
@keyframes umnm-pulse{0%{transform:scale(1);opacity:.55}100%{transform:scale(5);opacity:0}}\
@keyframes umnm-shake{0%,100%{transform:rotate(0)}20%{transform:rotate(-12deg)}40%{transform:rotate(10deg)}60%{transform:rotate(-7deg)}80%{transform:rotate(5deg)}}\
.umnm-pin.crit{--c:#F06B67}.umnm-pin.high{--c:#FF9800}.umnm-pin.med{--c:#F4C542}.umnm-pin.low{--c:#7F8FF3}.umnm-pin.clear{--c:#5FCB82}\
.umnm-pin.hidden-by-filter{display:none !important}\
.umnm-ctrls{position:absolute;z-index:200000;right:16px;top:68px;display:flex;flex-direction:column;gap:8px;pointer-events:auto}\
.umnm-group{display:flex;flex-direction:column;background:#fff;border-radius:12px;box-shadow:0 4px 12px rgba(32,38,111,.18);overflow:hidden}\
.umnm-btn{width:38px;height:38px;border:0;background:#fff;color:#20266F;cursor:pointer;display:grid;place-items:center;padding:0;transition:background .15s ease}\
.umnm-btn:hover{background:#D9DEFA}.umnm-btn:focus-visible{outline:2px solid #7F8FF3;outline-offset:-2px}\
.umnm-btn+.umnm-btn{border-top:1px solid #EEF1FF}\
.umnm-btn.active{background:#7F8FF3;color:#fff}\
.umnm-btn svg{width:20px;height:20px;display:block}\
.umnm-needle{transition:transform .1s linear;transform-origin:50% 50%}\
.umnm-layers{position:absolute;right:54px;top:0;background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(32,38,111,.22);padding:10px 14px;width:210px;font-size:13px;color:#4A5568;display:none}\
.umnm-layers.open{display:block}\
.umnm-layers label{display:flex;align-items:center;gap:8px;padding:6px 0;cursor:pointer;font-weight:500}\
.umnm-layers h4{margin:0 0 4px;font-size:12px;color:#20266F;text-transform:uppercase;letter-spacing:.05em}\
.umnm-summary{position:absolute;z-index:200000;left:50%;top:16px;transform:translateX(-50%);pointer-events:auto;background:#fff;border:0;border-radius:99px;padding:8px 16px;font:600 13px/1 "Inter",system-ui,sans-serif;color:#20266F;box-shadow:0 4px 12px rgba(32,38,111,.18);cursor:pointer;display:flex;align-items:center;gap:8px;white-space:nowrap}\
.umnm-summary .dot{width:10px;height:10px;border-radius:50%;background:#5FCB82}\
.umnm-summary.crit .dot{background:#F06B67;animation:umnm-blink 1s ease infinite}\
.umnm-summary.high .dot{background:#FF9800}.umnm-summary.med .dot{background:#F4C542}.umnm-summary.low .dot{background:#7F8FF3}\
@keyframes umnm-blink{50%{opacity:.25}}\
.umnm-legend{position:absolute;z-index:200000;left:16px;top:60px;display:flex;gap:12px;background:rgba(255,255,255,.92);border-radius:99px;padding:6px 12px;font-size:11px;font-weight:600;color:#4A5568;box-shadow:0 4px 12px rgba(32,38,111,.12);pointer-events:none}\
.umnm-legend i{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px;vertical-align:-1px}\
.umnm-panel{position:absolute;z-index:200000;left:16px;top:68px;bottom:16px;width:320px;max-width:calc(100% - 32px);background:#fff;border-radius:16px;box-shadow:0 12px 32px rgba(32,38,111,.25);display:none;flex-direction:column;pointer-events:auto;overflow:hidden;color:#4A5568;font-size:13px}\
.umnm-panel.open{display:flex;animation:umnm-in .22s ease}\
@keyframes umnm-in{from{opacity:0;transform:translateX(-12px)}to{opacity:1;transform:none}}\
.umnm-ph{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:14px 14px 10px;border-bottom:1px solid #EEF1FF}\
.umnm-ph h3{margin:0;font-size:16px;color:#20266F;font-weight:700;line-height:1.2}\
.umnm-ph p{margin:2px 0 0;font-size:12px;color:#A0AEC0}\
.umnm-x{border:0;background:#F7F8FC;border-radius:50%;width:28px;height:28px;font-size:18px;line-height:1;color:#20266F;cursor:pointer;flex:none}\
.umnm-x:hover{background:#D9DEFA}\
.umnm-pb{overflow-y:auto;padding:12px 14px 14px;flex:1}\
.umnm-status{display:flex;align-items:center;gap:8px;border-radius:12px;padding:10px 12px;font-weight:700;margin-bottom:12px}\
.umnm-status.clear{background:rgba(95,203,130,.15);color:#2E9E58}\
.umnm-status.crit{background:rgba(240,107,103,.15);color:#D64540}\
.umnm-status.high{background:rgba(255,152,0,.15);color:#D17F00}\
.umnm-status.med{background:rgba(244,197,66,.2);color:#8F6C00}\
.umnm-status.low{background:rgba(127,143,243,.15);color:#4F5FD0}\
.umnm-ieq{display:grid;grid-template-columns:1fr 1fr;gap:6px 10px;background:#F7F8FC;border-radius:12px;padding:10px 12px;margin-bottom:12px;font-size:12px}\
.umnm-ieq strong{color:#20266F}\
.umnm-ieq .full{grid-column:1/-1;display:flex;justify-content:space-between;align-items:center}\
.umnm-h{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#A0AEC0;margin:4px 0 8px}\
.umnm-rep{border:1px solid #EEF1FF;border-left-width:4px;border-radius:12px;padding:10px 12px;margin-bottom:8px;background:#fff}\
.umnm-rep.crit{border-left-color:#F06B67}.umnm-rep.high{border-left-color:#FF9800}.umnm-rep.med{border-left-color:#F4C542}.umnm-rep.low{border-left-color:#7F8FF3}\
.umnm-rep-top{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px}\
.umnm-rep strong{color:#20266F;font-size:13px}\
.umnm-rep .meta{font-size:11px;color:#A0AEC0}\
.umnm-rep p{margin:4px 0 0;font-size:12px;color:#4A5568;word-break:break-word}\
.umnm-acts{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}\
.umnm-acts button,.umnm-cta{border:1px solid #D9DEFA;background:#fff;color:#20266F;border-radius:99px;padding:5px 11px;font:600 11px/1.2 "Inter",system-ui,sans-serif;cursor:pointer}\
.umnm-acts button:hover{background:#D9DEFA}\
.umnm-acts button.primary{background:#7F8FF3;border-color:#7F8FF3;color:#fff}\
.umnm-acts button.primary:hover{background:#6676e0}\
.umnm-cta{display:block;width:100%;padding:10px 14px;font-size:13px;margin-top:8px;background:#7F8FF3;color:#fff;border-color:#7F8FF3}\
.umnm-cta.secondary{background:#fff;color:#7F8FF3}\
.umnm-cta:hover{filter:brightness(.95)}\
.umnm-muted{font-size:12px;color:#A0AEC0;margin-top:6px}\
.umnm-pri{font-size:10px;font-weight:700;padding:3px 8px;border-radius:99px;letter-spacing:.03em}\
.umnm-pri.crit{background:rgba(240,107,103,.15);color:#D64540}.umnm-pri.high{background:rgba(255,152,0,.15);color:#D17F00}.umnm-pri.med{background:rgba(244,197,66,.2);color:#8F6C00}.umnm-pri.low{background:rgba(95,203,130,.15);color:#2E9E58}\
@media (max-width:600px){\
 .umnm-panel{left:8px;right:8px;width:auto;max-width:none;top:auto;bottom:8px;max-height:55%}\
 .umnm-legend{display:none}.umnm-ctrls{right:8px}.umnm-summary{font-size:12px;padding:7px 12px}\
}';
        var st = document.createElement('style');
        st.id = 'umnm-styles'; st.textContent = css; document.head.appendChild(st);
    }

    /* ------------------------------------------------------------------ icons */
    var ICON = {
        home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg>',
        layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/></svg>',
        plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
        minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M5 12h14"/></svg>',
        full: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
        exit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
        compass: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.6"/><g class="umnm-needle"><path d="M12 4l3.2 8H8.8z" fill="#F06B67"/><path d="M12 20l-3.2-8h6.4z" fill="currentColor" opacity=".55"/></g></svg>'
    };
    function pinSvg() {
        return '<svg class="umnm-pin-svg" viewBox="0 0 36 46" aria-hidden="true">' +
            '<path d="M18 45C18 45 3 28.5 3 17a15 15 0 0 1 30 0c0 11.5-15 28-15 28z" fill="var(--c)" stroke="#fff" stroke-width="2.5"/>' +
            '<circle cx="18" cy="17" r="10" fill="#fff"/>' +
            '<g fill="var(--c)"><path d="M12.5 23V12.5L18 10l5.5 2.5V23z"/></g>' +
            '<g fill="#fff"><rect x="14.4" y="14" width="2" height="2"/><rect x="19.6" y="14" width="2" height="2"/><rect x="14.4" y="18" width="2" height="2"/><rect x="19.6" y="18" width="2" height="2"/></g></svg>';
    }

    /* --------------------------------------------------------------- overlay */
    function buildOverlay() {
        var root = document.createElement('div');
        root.className = 'umnm-root';
        root.innerHTML =
            '<button class="umnm-summary clear" type="button" aria-live="polite"><span class="dot"></span><span class="txt"></span></button>' +
            '<div class="umnm-ctrls">' +
            '  <div class="umnm-group"><button class="umnm-btn" data-a="home" title="Reset view" aria-label="Reset view">' + ICON.home + '</button>' +
            '  <button class="umnm-btn" data-a="layers" title="Map layers" aria-label="Map layers">' + ICON.layers + '</button>' +
            '  <button class="umnm-btn" data-a="compass" title="Face north" aria-label="Face north">' + ICON.compass + '</button>' +
            '  <button class="umnm-btn" data-a="full" title="Fullscreen" aria-label="Fullscreen">' + ICON.full + '</button></div>' +
            '  <div class="umnm-group"><button class="umnm-btn" data-a="zin" title="Zoom in" aria-label="Zoom in">' + ICON.plus + '</button>' +
            '  <button class="umnm-btn" data-a="zout" title="Zoom out" aria-label="Zoom out">' + ICON.minus + '</button></div>' +
            '  <div class="umnm-layers"><h4>Map layers</h4>' +
            '    <label><input type="checkbox" data-l="labels" checked> Building names</label>' +
            '    <label><input type="checkbox" data-l="problems"> Only buildings with problems</label></div>' +
            '</div>' +
            '<div class="umnm-legend"><span><i style="background:#F06B67"></i>Critical</span><span><i style="background:#FF9800"></i>Needs attention</span><span><i style="background:#5FCB82"></i>No problems</span></div>' +
            '<aside class="umnm-panel" role="dialog" aria-label="Building details"></aside>';
        S.container.appendChild(root);
        S.root = root;
        S.panel = root.querySelector('.umnm-panel');
        S.summary = root.querySelector('.umnm-summary');

        S.pois.forEach(function (p) {
            var el = document.createElement('div');
            el.className = 'umnm-pin clear';
            el.innerHTML = '<button class="umnm-pin-btn" type="button">' + pinSvg() + '<i class="umnm-badge" style="display:none"></i><span class="umnm-pulse"></span></button>' +
                '<span class="umnm-new">NEW</span><span class="umnm-label">' + esc(p.label) + '</span>';
            el.querySelector('.umnm-pin-btn').addEventListener('click', function () { focus(p.id); });
            root.appendChild(el);
            S.pins[p.id] = el;
        });

        root.querySelector('.umnm-ctrls').addEventListener('click', onControl);
        root.querySelector('.umnm-layers').addEventListener('change', function (e) {
            var k = e.target.getAttribute('data-l');
            if (k === 'labels') S.showLabels = e.target.checked;
            if (k === 'problems') S.onlyProblems = e.target.checked;
            refresh();
        });
        S.summary.addEventListener('click', function () {
            var worst = null, wl = 0;
            S.pois.forEach(function (p) { var l = levelOf(reportsFor(p).active); if (l > wl) { wl = l; worst = p; } });
            if (worst) focus(worst.id);
        });
        S.panel.addEventListener('click', onPanelClick);
        document.addEventListener('fullscreenchange', function () {
            var b = root.querySelector('[data-a="full"]');
            b.innerHTML = document.fullscreenElement === S.container ? ICON.exit : ICON.full;
        });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && S.selected && !document.fullscreenElement) closePanel(); });
    }

    function onControl(e) {
        var b = e.target.closest('[data-a]'); if (!b) return;
        var a = b.getAttribute('data-a'), V = window.UMNViewer;
        if (a === 'home') { closePanel(); animateTo(S.home.pos, S.home.target, 800); }
        if (a === 'zin') zoomBy(0.65);
        if (a === 'zout') zoomBy(1.55);
        if (a === 'compass') faceNorth();
        if (a === 'layers') S.root.querySelector('.umnm-layers').classList.toggle('open');
        if (a === 'full') {
            if (document.fullscreenElement === S.container) document.exitFullscreen();
            else if (S.container.requestFullscreen) S.container.requestFullscreen();
        }
    }

    /* ---------------------------------------------------------------- camera */
    function cancelAnim() { S.anim = null; }
    function animateTo(toPos, toTarget, ms) {
        var V = window.UMNViewer, cam = V.camera, ctl = V.controls;
        var fp = cam.position.clone(), ft = ctl.target.clone(), t0 = performance.now();
        var a = S.anim = {};
        (function step(now) {
            if (S.anim !== a) return;
            var k = Math.min(1, (now - t0) / ms);
            var e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
            cam.position.lerpVectors(fp, toPos, e);
            ctl.target.lerpVectors(ft, toTarget, e);
            ctl.update();
            if (k < 1) requestAnimationFrame(step); else S.anim = null;
        })(t0);
    }
    function zoomBy(f) {
        var V = window.UMNViewer, cam = V.camera, ctl = V.controls;
        var off = cam.position.clone().sub(ctl.target);
        var d = Math.min(ctl.maxDistance, Math.max(ctl.minDistance * 1.01, off.length() * f));
        off.setLength(d);
        animateTo(ctl.target.clone().add(off), ctl.target.clone(), 280);
    }
    function faceNorth() {
        // Camera sitting on +Z (south) looking towards -Z (north) = north up.
        var V = window.UMNViewer, cam = V.camera, ctl = V.controls;
        var off = cam.position.clone().sub(ctl.target);
        var horiz = Math.hypot(off.x, off.z);
        animateTo(ctl.target.clone().add(new S.V3(0, off.y, horiz)), ctl.target.clone(), 600);
    }
    function focus(id, opts) {
        var p = poiById(id); if (!p) return;
        var V = window.UMNViewer, cam = V.camera, ctl = V.controls;
        var dir = cam.position.clone().sub(ctl.target).normalize();
        if (dir.y < 0.5) { dir.y = 0.5; dir.normalize(); }
        var target = new S.V3(p.scenePos.x, S.groundY + p.roofHeight * 0.5, p.scenePos.z);
        // tall buildings need the camera further back so roof + pin stay in frame
        var dist = Math.max(p.focusDistance, p.roofHeight * 2.2, ctl.minDistance * 1.2);
        var rect = S.container.getBoundingClientRect();
        if (rect.width >= 500) {
            // keep the building visible to the right of the popup (popup is ~320px wide, docked left)
            var right = new S.V3().setFromMatrixColumn(cam.matrixWorld, 0);
            var worldPerPx = 2 * dist * Math.tan(cam.fov * Math.PI / 360) / rect.height;
            var shiftPx = Math.min(320, rect.width - 32) / 2 + 16;
            target.add(right.multiplyScalar(-shiftPx * worldPerPx));
        }
        animateTo(target.clone().add(dir.multiplyScalar(dist)), target, 850);
        select(id);
        if (!opts || opts.scroll !== false) {
            var r = S.container.getBoundingClientRect();
            if (r.top < 0 || r.bottom > window.innerHeight) S.container.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    function focusReport(rid) {
        var r = reportsList().filter(function (x) { return x.id === rid; })[0];
        var p = r && poiForReport(r);
        if (p) focus(p.id);
        return !!p;
    }
    function clampPan() {
        var ctl = window.UMNViewer.controls, cam = window.UMNViewer.camera, h = S.home.target, lim = S.radius * 0.85;
        var dx = ctl.target.x - h.x, dz = ctl.target.z - h.z, d = Math.hypot(dx, dz);
        if (d > lim) {
            var k = lim / d, nx = h.x + dx * k, nz = h.z + dz * k;
            cam.position.x += nx - ctl.target.x; cam.position.z += nz - ctl.target.z;
            ctl.target.x = nx; ctl.target.z = nz;
        }
    }

    /* ------------------------------------------------------------ state/render */
    function select(id) {
        S.selected = id;
        S.container.classList.add('umnm-has-panel');
        renderPanel();
        refresh();
    }
    function closePanel() { S.selected = null; S.panel.classList.remove('open'); S.container.classList.remove('umnm-has-panel'); refresh(); }

    function refresh() {
        if (!S.ready) return;
        var problemBuildings = 0, worst = 0;
        S.pois.forEach(function (p) {
            var rep = reportsFor(p), lvl = levelOf(rep.active), el = S.pins[p.id], L = LEVELS[lvl];
            if (rep.active.length) problemBuildings++;
            worst = Math.max(worst, lvl);
            el.className = 'umnm-pin ' + L.key + (S.selected === p.id ? ' selected' : '') +
                ((S.fresh[p.id] || 0) > Date.now() ? ' fresh' : '') +
                (S.onlyProblems && !rep.active.length ? ' hidden-by-filter' : '');
            var badge = el.querySelector('.umnm-badge');
            badge.style.display = rep.active.length ? '' : 'none';
            badge.textContent = rep.active.length;
            el.querySelector('.umnm-label').style.display = S.showLabels ? '' : 'none';
            el.querySelector('.umnm-pin-btn').setAttribute('aria-label',
                p.label + ': ' + (rep.active.length ? rep.active.length + ' active problem report' + (rep.active.length > 1 ? 's' : '') + ' (' + L.label + ')' : 'no active problems'));
        });
        var sm = S.summary, W = LEVELS[worst];
        sm.className = 'umnm-summary ' + W.key;
        var narrow = S.root.clientWidth < 760;
        sm.querySelector('.txt').textContent = problemBuildings
            ? (narrow ? problemBuildings + ' with problems' : problemBuildings + (problemBuildings > 1 ? ' buildings have' : ' building has') + ' active problems')
            : (narrow ? 'All clear' : 'All buildings clear - no active problems');
        sm.style.cursor = problemBuildings ? 'pointer' : 'default';
        if (S.selected) renderPanel(true);
    }

    function renderIeq(p) {
        var box = S.panel.querySelector('.umnm-ieq'); if (!box) return;
        var sp = (window.spaces || []).filter(function (s) { return p.spaces.indexOf(s.id) > -1; })[0];
        if (!sp) { box.style.display = 'none'; if (box.previousElementSibling) box.previousElementSibling.style.display = 'none'; return; }
        var cls = sp.statusLevel === 'optimal' ? 'status-optimal' : (sp.statusLevel === 'poor' ? 'status-poor' : 'status-moderate');
        box.style.display = '';
        box.innerHTML = '<div class="full"><strong>' + esc(sp.name) + '</strong><span class="status-badge ' + cls + '">IEQ ' + sp.comfortScore + '%</span></div>' +
            '<div>🌡️ ' + Number(sp.temperature).toFixed(1) + '°C</div><div>💧 ' + Math.round(sp.humidity) + '%</div>' +
            '<div>🌬️ ' + Math.round(sp.co2) + ' ppm</div><div>👥 ' + Math.round(sp.occupancy) + '%</div>';
    }

    function renderPanel(keepScroll) {
        var p = poiById(S.selected);
        if (!p) { S.panel.classList.remove('open'); return; }
        var rep = reportsFor(p), lvl = levelOf(rep.active), L = LEVELS[lvl];
        var scroll = keepScroll && S.panel.querySelector('.umnm-pb') ? S.panel.querySelector('.umnm-pb').scrollTop : 0;
        var statusHtml = rep.active.length
            ? '<div class="umnm-status ' + L.key + '">⚠️ ' + rep.active.length + ' active problem' + (rep.active.length > 1 ? 's' : '') + ' reported</div>'
            : '<div class="umnm-status clear">✅ No active problems reported</div>';
        var cards = rep.active.map(function (r) {
            var k = LEVELS[PRI_RANK[r.priority] || 1].key;
            var acts = '';
            if (IS_ADMIN) {
                acts = '<div class="umnm-acts" data-id="' + esc(r.id) + '">' +
                    (r.status !== 'In Progress' ? '<button data-act="progress">Mark in progress</button>' : '') +
                    '<button class="primary" data-act="resolve">Resolve</button>' +
                    '<button data-act="detail">Details</button></div>';
            }
            return '<div class="umnm-rep ' + k + '"><div class="umnm-rep-top"><span class="umnm-pri ' + k + '">' + esc(r.priority) + '</span>' +
                '<span class="meta">' + esc(ago(r.timestamp)) + '</span></div>' +
                '<strong>' + esc(r.issue || r.category) + '</strong>' +
                '<div class="meta">Floor ' + esc(r.location.floor || '-') + ' · ' + esc(r.location.room || 'Unknown zone') + ' · ' + esc(r.status) + '</div>' +
                (r.description ? '<p>' + esc(r.description) + '</p>' : '') + acts + '</div>';
        }).join('');
        var footer = IS_ADMIN
            ? '<a class="umnm-cta secondary" style="text-align:center;text-decoration:none" href="reports.html">Open all reports</a>'
            : '<button class="umnm-cta" data-act="report">Report a problem here</button>';

        S.panel.innerHTML =
            '<div class="umnm-ph"><div><h3>' + esc(p.label) + '</h3><p>' + esc(p.buildings.join(', ') === p.label ? 'UMN campus building' : p.buildings.join(', ')) + '</p></div>' +
            '<button class="umnm-x" data-act="close" aria-label="Close">×</button></div>' +
            '<div class="umnm-pb">' + statusHtml +
            (rep.active.length ? '<div class="umnm-h">' + (IS_ADMIN ? 'Reports to check' : 'Known problems') + '</div>' + cards : '') +
            '<div class="umnm-h">Air quality &amp; comfort</div><div class="umnm-ieq"></div>' +
            (rep.resolved ? '<div class="umnm-muted">' + rep.resolved + ' earlier report' + (rep.resolved > 1 ? 's' : '') + ' resolved</div>' : '') +
            footer + '</div>';
        S.panel.classList.add('open');
        renderIeq(p);
        if (scroll) S.panel.querySelector('.umnm-pb').scrollTop = scroll;
    }

    function onPanelClick(e) {
        var b = e.target.closest('[data-act]'); if (!b) return;
        var act = b.getAttribute('data-act'), p = poiById(S.selected);
        if (act === 'close') return closePanel();
        if (act === 'report' && typeof window.openReportModal === 'function') return window.openReportModal(p.buildings[0]);
        var holder = b.closest('[data-id]'); if (!holder) return;
        var id = holder.getAttribute('data-id');
        if (act === 'progress' && window.updateReportStatus) window.updateReportStatus(id, 'In Progress');
        if (act === 'resolve' && window.updateReportStatus) window.updateReportStatus(id, 'Resolved');
        if (act === 'detail' && window.openAdminReportDetail) window.openAdminReportDetail(id);
    }

    /* ------------------------------------------------------------- per frame */
    function frame() {
        var V = window.UMNViewer;
        if (!V) return;
        if (S.ready !== true) { if (!S.ready && V.state === 'ready' && window.UMN_GLTF_SCENE) setup(); return; }
        if (!S.container.getClientRects().length) return; // hidden (e.g. 2D mode)
        if (!S.hintDone) {
            var hint = S.container.querySelector('.umn3d-hint');
            if (hint) { hint.textContent = 'Drag to pan · Right-drag to rotate · Scroll to zoom · Click a pin'; S.hintDone = true; }
        }
        clampPan();
        var cam = V.camera, canvas = V.renderer.domElement;
        cam.updateMatrixWorld();
        var cr = canvas.getBoundingClientRect(), or = S.root.getBoundingClientRect();
        var ox = cr.left - or.left, oy = cr.top - or.top, now = Date.now();
        var placed = [], proj = [];
        S.pois.forEach(function (p) {
            var v = p.scenePos.clone().project(cam);
            var x = ox + (v.x * 0.5 + 0.5) * cr.width, y = oy + (-v.y * 0.5 + 0.5) * cr.height;
            proj.push({ p: p, v: v, x: x, y: y, vis: v.z > -1 && v.z < 1 && x > -40 && x < or.width + 40 && y > -10 && y < or.height + 70 });
        });
        proj.sort(function (a, b) { return a.v.z - b.v.z; }); // nearest first
        function hit(a, b) { return a[0] < b[0] + b[2] && a[0] + a[2] > b[0] && a[1] < b[1] + b[3] && a[1] + a[3] > b[1]; }
        proj.forEach(function (o) {
            var el = S.pins[o.p.id];
            el.style.visibility = o.vis ? '' : 'hidden';
            if (o.vis) {
                el.style.transform = 'translate3d(' + o.x.toFixed(1) + 'px,' + o.y.toFixed(1) + 'px,0)';
                el.style.zIndex = Math.round((1 - o.v.z) * 100000);
                // keep labels readable: try below the pin, then right, then left; hide if all clash
                var lw = o.p.label.length * 7 + 8, head = [o.x - 20, o.y - 48, 40, 48];
                var opts = [
                    { r: [o.x - lw / 2, o.y + 3, lw, 18], l: '0px', t: '5px', tr: 'translateX(-50%)' },
                    { r: [o.x + 22, o.y - 38, lw, 18], l: '24px', t: '-36px', tr: 'none' },
                    { r: [o.x - 22 - lw, o.y - 38, lw, 18], l: '-24px', t: '-36px', tr: 'translateX(-100%)' }
                ];
                var pick = null;
                for (var k = 0; k < opts.length && !pick; k++) {
                    if (!placed.some(function (r) { return hit(opts[k].r, r); })) pick = opts[k];
                }
                var lab = el.querySelector('.umnm-label');
                if (pick) { lab.style.left = pick.l; lab.style.top = pick.t; lab.style.transform = pick.tr; placed.push(pick.r); lab.style.visibility = ''; }
                else lab.style.visibility = S.selected === o.p.id ? '' : 'hidden';
                placed.push(head);
            }
            if (S.fresh[o.p.id] && S.fresh[o.p.id] < now) { delete S.fresh[o.p.id]; refresh(); }
        });
        // compass needle follows camera azimuth
        var off = cam.position.clone().sub(V.controls.target);
        var deg = Math.atan2(off.x, off.z) * 180 / Math.PI;
        var needle = S.root.querySelector('.umnm-needle');
        if (needle) needle.style.transform = 'rotate(' + deg.toFixed(1) + 'deg)';
    }

    /* ------------------------------------------------------------------ setup */
    function setup() {
        var V = window.UMNViewer, root = window.UMN_GLTF_SCENE;
        S.V3 = V.camera.position.constructor;
        var merged = null;
        V.scene.traverse(function (o) { if (!merged && o.isMesh) merged = o; });
        if (!merged) return;
        merged.updateWorldMatrix(true, false);
        root.updateMatrixWorld(true);
        S.groundY = new S.V3(0, 0, 0).applyMatrix4(merged.matrixWorld).y;

        var found = [];
        root.traverse(function (o) {
            var d = o.userData && o.userData.aeris_poi;
            if (!d) return;
            var g = new S.V3().setFromMatrixPosition(o.matrixWorld);
            found.push({
                id: d.id, label: d.label || d.id, buildings: d.buildings || [d.label], spaces: d.spaces || [],
                focusDistance: d.focusDistance || 3000, roofHeight: d.roofHeight || 400,
                scenePos: g.applyMatrix4(merged.matrixWorld)
            });
        });
        if (!found.length) { console.warn('[UMN map] No POI_* nodes found in UMN.gltf'); S.ready = 'none'; return; }
        S.pois = found;
        S.container = SELECTORS.map(function (s) { return document.querySelector(s); }).filter(Boolean)[0];

        var ctl = V.controls;
        ctl.autoRotate = false;
        ctl.screenSpacePanning = false;                       // pan along the ground like a map
        ctl.mouseButtons = { LEFT: 2, MIDDLE: 1, RIGHT: 0 };  // left = pan, right = rotate
        ctl.touches = { ONE: 1, TWO: 3 };                     // 1 finger pan, 2 fingers zoom+rotate
        ctl.addEventListener('start', cancelAnim);
        S.home = { pos: V.camera.position.clone(), target: ctl.target.clone() };
        S.radius = ctl.maxDistance / 3.2;

        S.ready = true;
        injectStyles();
        buildOverlay();
        refresh();
        wire();
        window.UMNMap.pois = S.pois;
        window.dispatchEvent(new CustomEvent('umnmap:ready'));

        var q = new URLSearchParams(location.search).get('focus');
        if (q) setTimeout(function () { focusReport(q); }, 500);
    }

    function wire() {
        window.addEventListener('storage_reports_updated', refresh);
        window.addEventListener('storage_spaces_updated', function () {
            var p = poiById(S.selected); if (p) renderIeq(p);
        });
        window.addEventListener('aeris:new-reports', function (e) {
            (e.detail || []).forEach(function (r) {
                var p = poiForReport(r); if (p) S.fresh[p.id] = Date.now() + 30000;
            });
            refresh();
        });
        // Left sidebar (student campus-map page): make the zone list drive the 3D map.
        var items = document.querySelectorAll('.map-sidebar .map-sidebar-menu:first-child .menu-item');
        var targets = [null, 'library', 'gedung_d', 'academic', 'gedung_b'];
        items.forEach(function (it, i) {
            it.addEventListener('click', function () {
                if (!S.container.getClientRects().length) return;
                items.forEach(function (x) { x.classList.remove('active'); });
                it.classList.add('active');
                if (targets[i]) focus(targets[i], { scroll: false });
                else { closePanel(); animateTo(S.home.pos, S.home.target, 800); }
            });
        });
        // Dev helper: ?calibrate=1 -> click the map to print world coordinates for a new POI_* node.
        if (new URLSearchParams(location.search).get('calibrate')) {
            var cv = window.UMNViewer.renderer.domElement;
            cv.addEventListener('dblclick', function (ev) {
                var r = cv.getBoundingClientRect(), cam = window.UMNViewer.camera;
                var nx = ((ev.clientX - r.left) / r.width) * 2 - 1, ny = -((ev.clientY - r.top) / r.height) * 2 + 1;
                var a = new S.V3(nx, ny, -1).unproject(cam), b = new S.V3(nx, ny, 1).unproject(cam);
                var t = (S.groundY - a.y) / (b.y - a.y), hit = a.clone().lerp(b, t);
                var m = null; window.UMNViewer.scene.traverse(function (o) { if (!m && o.isMesh) m = o; });
                var gl = hit.clone().applyMatrix4(m.matrixWorld.clone().invert());
                console.log('[UMN map] glTF coords (ground): translation = [' + gl.x.toFixed(1) + ', ROOF_Y, ' + gl.z.toFixed(1) + ']');
                alert('glTF ground position:\nx = ' + gl.x.toFixed(1) + '\nz = ' + gl.z.toFixed(1) + '\n(set y to the roof height + ~140)');
            });
        }
    }

    window.UMNMap = {
        pois: S.pois, focus: focus, focusReport: focusReport, closePanel: closePanel,
        home: function () { if (S.ready === true) animateTo(S.home.pos, S.home.target, 800); },
        get ready() { return S.ready === true; }
    };
    (function tick() { requestAnimationFrame(tick); try { frame(); } catch (err) { console.error('[UMN map]', err); S.ready = S.ready || 'error'; } })();
})();
