/**
 * audio.js - Calming Campus Ambient Soundscape Engine
 * AERIS 2.1 - Universitas Multimedia Nusantara (UMN)
 * 
 * Features:
 * - Peaceful, gentle ambient synthesizer chords generated via HTML5 Web Audio API
 * - Zero external streaming dependencies; 100% reliable offline playback
 * - Controls: Play/Pause, Volume Slider (0-100%), Mute/Unmute
 * - Persistent preferences saved in localStorage ('aeris_music_enabled', 'aeris_music_volume')
 * - Respects browser autoplay policy: plays only after explicit user interaction
 */

(function () {
    'use strict';

    let audioCtx = null;
    let masterGain = null;
    let isPlaying = false;
    let isMuted = false;
    let currentVolume = 0.35; // Default 35%
    let schedulerTimer = null;
    let stepIndex = 0;

    // Soothing pentatonic chord frequencies (F major / D minor peaceful ambient progression)
    const chords = [
        [174.61, 220.00, 261.63, 349.23], // F3, A3, C4, F4 (Warm, calm)
        [130.81, 196.00, 261.63, 329.63], // C3, G3, C4, E4 (Bright, hopeful)
        [146.83, 220.00, 261.63, 349.23], // D3, A3, C4, F4 (Serene, contemplative)
        [116.54, 174.61, 233.08, 293.66]  // Bb2, F3, Bb3, D4 (Peaceful resolution)
    ];

    function initAudioContext() {
        if (!audioCtx) {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) return null;
            audioCtx = new AudioContextClass();

            masterGain = audioCtx.createGain();
            masterGain.gain.setValueAtTime(currentVolume, audioCtx.currentTime);
            masterGain.connect(audioCtx.destination);
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        return audioCtx;
    }

    function playChord(notes, duration = 6.0) {
        if (!audioCtx || !isPlaying) return;

        const now = audioCtx.currentTime;
        const chordGain = audioCtx.createGain();
        chordGain.connect(masterGain);

        // Soft, gentle envelope attack and release
        chordGain.gain.setValueAtTime(0.001, now);
        chordGain.gain.exponentialRampToValueAtTime(0.25, now + 2.0); // 2s gentle swell
        chordGain.gain.exponentialRampToValueAtTime(0.0001, now + duration); // Soft fade

        notes.forEach((freq, idx) => {
            const osc = audioCtx.createOscillator();
            const filter = audioCtx.createBiquadFilter();

            // Warm low-pass warmth filter
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(700 + (idx * 150), now);
            filter.Q.setValueAtTime(1.5, now);

            osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
            osc.frequency.setValueAtTime(freq, now);

            // Subtle pitch vibrato for organic human acoustic feel
            const lfo = audioCtx.createOscillator();
            const lfoGain = audioCtx.createGain();
            lfo.frequency.setValueAtTime(0.2 + (idx * 0.05), now);
            lfoGain.gain.setValueAtTime(0.8, now);
            lfo.connect(lfoGain);
            lfoGain.connect(osc.frequency);
            lfo.start(now);
            lfo.stop(now + duration);

            osc.connect(filter);
            filter.connect(chordGain);

            osc.start(now);
            osc.stop(now + duration);
        });

        // Add soft bell chime
        const bellFreq = notes[notes.length - 1] * 2;
        const bellOsc = audioCtx.createOscillator();
        const bellGain = audioCtx.createGain();
        bellOsc.type = 'sine';
        bellOsc.frequency.setValueAtTime(bellFreq, now + 1.0);
        bellGain.gain.setValueAtTime(0.001, now + 1.0);
        bellGain.gain.exponentialRampToValueAtTime(0.04, now + 1.2);
        bellGain.gain.exponentialRampToValueAtTime(0.00001, now + 4.5);

        bellOsc.connect(bellGain);
        bellGain.connect(masterGain);
        bellOsc.start(now + 1.0);
        bellOsc.stop(now + 4.6);
    }

    function scheduleNextChord() {
        if (!isPlaying) return;
        const currentChord = chords[stepIndex % chords.length];
        stepIndex++;
        playChord(currentChord, 5.5);
        schedulerTimer = setTimeout(scheduleNextChord, 4500); // Gentle overlap
    }

    // Public Audio Controls
    function startMusic() {
        const ctx = initAudioContext();
        if (!ctx) return;

        isPlaying = true;
        localStorage.setItem('aeris_music_enabled', 'true');
        scheduleNextChord();
        updateUI();
        window.dispatchEvent(new CustomEvent('aeris_music_state_changed', { detail: { isPlaying: true } }));
    }

    function stopMusic() {
        isPlaying = false;
        if (schedulerTimer) clearTimeout(schedulerTimer);
        localStorage.setItem('aeris_music_enabled', 'false');
        updateUI();
        window.dispatchEvent(new CustomEvent('aeris_music_state_changed', { detail: { isPlaying: false } }));
    }

    function toggleMusic() {
        if (isPlaying) stopMusic();
        else startMusic();
    }

    function setVolume(pct) {
        currentVolume = Math.max(0, Math.min(100, pct)) / 100;
        localStorage.setItem('aeris_music_volume', pct.toString());
        if (masterGain && audioCtx) {
            masterGain.gain.setValueAtTime(isMuted ? 0 : currentVolume, audioCtx.currentTime);
        }
        updateUI();
    }

    function toggleMute() {
        isMuted = !isMuted;
        if (masterGain && audioCtx) {
            masterGain.gain.setValueAtTime(isMuted ? 0 : currentVolume, audioCtx.currentTime);
        }
        updateUI();
    }

    function updateUI() {
        const btns = document.querySelectorAll('.music-toggle-btn');
        btns.forEach(btn => {
            btn.classList.toggle('playing', isPlaying);
            btn.innerHTML = isPlaying 
                ? '<span>🎵</span> <b>Sound: ON</b>' 
                : '<span>🔇</span> <b>Sound: OFF</b>';
        });

        const sliders = document.querySelectorAll('.music-volume-slider');
        sliders.forEach(s => {
            s.value = Math.round(currentVolume * 100);
        });

        const switches = document.querySelectorAll('#pref-music-toggle, #setting-music-toggle');
        switches.forEach(sw => {
            sw.checked = isPlaying;
        });
    }

    // Initialize from storage
    document.addEventListener('DOMContentLoaded', () => {
        const savedVol = localStorage.getItem('aeris_music_volume');
        if (savedVol !== null) {
            currentVolume = parseInt(savedVol, 10) / 100;
        }

        const wasEnabled = localStorage.getItem('aeris_music_enabled') === 'true';
        // Auto-resume only if user has interacted with document
        if (wasEnabled) {
            const resumeOnFirstClick = () => {
                if (localStorage.getItem('aeris_music_enabled') === 'true' && !isPlaying) {
                    startMusic();
                }
                document.removeEventListener('click', resumeOnFirstClick);
                document.removeEventListener('keydown', resumeOnFirstClick);
            };
            document.addEventListener('click', resumeOnFirstClick, { once: true });
            document.addEventListener('keydown', resumeOnFirstClick, { once: true });
        }
        updateUI();
    });

    window.AerisAudio = {
        start: startMusic,
        stop: stopMusic,
        toggle: toggleMusic,
        setVolume: setVolume,
        toggleMute: toggleMute,
        isPlaying: () => isPlaying,
        getVolume: () => Math.round(currentVolume * 100)
    };
})();
