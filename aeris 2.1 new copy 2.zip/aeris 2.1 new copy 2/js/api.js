/**
 * api.js - Unified REST API Client & Synchronization Layer
 * AERIS 2.1 - Universitas Multimedia Nusantara (UMN)
 * 
 * Works both with the live Python backend (/api/v1/...) and seamlessly 
 * falls back to client-side storage when run statically.
 */

(function () {
    'use strict';

    const API_BASE = (window.location.origin && window.location.origin !== 'null' && !window.location.origin.startsWith('file')) 
        ? `${window.location.origin}/api/v1` 
        : 'http://localhost:8000/api/v1';

    let serverOnline = null;

    function getToken() {
        return localStorage.getItem('aeris_api_token') || '';
    }

    function setToken(token) {
        if (token) localStorage.setItem('aeris_api_token', token);
        else localStorage.removeItem('aeris_api_token');
    }

    async function checkServer() {
        if (serverOnline !== null) return serverOnline;
        if (window.location.protocol === 'file:') {
            serverOnline = false;
            return false;
        }
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 1200);
            const res = await fetch(`${API_BASE}/locations`, { signal: controller.signal });
            clearTimeout(timeoutId);
            serverOnline = res.ok;
        } catch (e) {
            serverOnline = false;
        }
        return serverOnline;
    }

    async function request(endpoint, options = {}) {
        const isOnline = await checkServer();
        if (!isOnline) {
            return { offline: true };
        }

        const headers = options.headers || {};
        headers['Content-Type'] = 'application/json';
        const token = getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        try {
            const res = await fetch(`${API_BASE}${endpoint}`, {
                ...options,
                headers
            });
            const data = await res.json();
            return data;
        } catch (err) {
            return { success: false, message: err.message, offline: true };
        }
    }

    const AerisApi = {
        checkServer,
        getToken,
        setToken,

        // Auth
        async login(username, password) {
            const res = await request('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ username, password })
            });
            if (res.token) setToken(res.token);
            return res;
        },

        async logout() {
            await request('/auth/logout', { method: 'POST' });
            setToken(null);
        },

        async getMe() {
            return await request('/auth/me');
        },

        // Profile & Avatar
        async getProfile() {
            return await request('/profile');
        },

        async uploadAvatar(base64Image) {
            const res = await request('/profile/avatar', {
                method: 'POST',
                body: JSON.stringify({ image: base64Image })
            });
            return res;
        },

        async deleteAvatar() {
            return await request('/profile/avatar', { method: 'DELETE' });
        },

        // Achievements & Gamification
        async getAchievements() {
            return await request('/achievements');
        },

        async getMyAchievements() {
            return await request('/achievements/my');
        },

        async getAchievementProgress() {
            return await request('/achievements/progress');
        },

        // Notifications
        async getNotifications() {
            return await request('/notifications');
        },

        async markNotificationRead(id) {
            return await request(`/notifications/${id}/read`, { method: 'PATCH' });
        },

        async markAllNotificationsRead() {
            return await request('/notifications/read-all', { method: 'PATCH' });
        },

        // Locations & Radar
        async getLocations() {
            return await request('/locations');
        },

        async getLocationDetail(id) {
            return await request(`/locations/${id}`);
        },

        async getRadarSummary() {
            return await request('/environment/radar');
        },

        async submitThermalFeedback(roomId, rating) {
            return await request('/environment/feedback', {
                method: 'POST',
                body: JSON.stringify({ roomId, rating })
            });
        },

        // Reports & Verifications
        async getReports() {
            return await request('/reports');
        },

        async submitReport(payload) {
            return await request('/reports', {
                method: 'POST',
                body: JSON.stringify(payload)
            });
        },

        async verifyReport(reportId, response) {
            return await request(`/reports/${encodeURIComponent(reportId)}/verify`, {
                method: 'POST',
                body: JSON.stringify({ response })
            });
        },

        // QR Codes
        async getQrCodes() {
            return await request('/qr-codes');
        },

        async toggleQrCode(roomId) {
            return await request(`/qr-codes/${roomId}/toggle`, { method: 'PATCH' });
        },

        async regenerateQrCode(roomId) {
            return await request(`/qr-codes/${roomId}/regenerate`, { method: 'POST' });
        },

        // Maintenance
        async getMaintenance() {
            return await request('/maintenance');
        },

        async createMaintenanceTask(payload) {
            return await request('/maintenance', {
                method: 'POST',
                body: JSON.stringify(payload)
            });
        },

        // Preferences
        async getPreferences() {
            return await request('/preferences');
        },

        async updatePreferences(prefs) {
            return await request('/preferences', {
                method: 'PATCH',
                body: JSON.stringify(prefs)
            });
        }
    };

    window.AerisApi = AerisApi;
})();
