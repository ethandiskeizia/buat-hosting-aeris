/**
 * theme.js - Dark / light mode for AERIS
 * Adds or removes the class "dark" on <html>; the colors live in css/global.css
 * (html.dark { ...variables }). The choice is remembered in localStorage.
 */
(function () {
    var KEY = 'aeris_theme';
    var root = document.documentElement;

    function saved() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
    function isDark() { return root.classList.contains('dark'); }

    // Runs in <head>, before the page is drawn, so there is no white flash
    if (saved() === 'dark') root.classList.add('dark');

    document.addEventListener('DOMContentLoaded', function () {
        // Chart.js text color follows the theme (set before the page creates its charts)
        if (window.Chart) Chart.defaults.color = isDark() ? '#B4BBD4' : '#666666';

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'theme-toggle';

        function label() {
            btn.textContent = isDark() ? '☀️' : '🌙';
            btn.title = isDark() ? 'Switch to light mode' : 'Switch to dark mode';
            btn.setAttribute('aria-label', btn.title);
        }

        btn.addEventListener('click', function () {
            root.classList.toggle('dark');                       // DOM class change
            try { localStorage.setItem(KEY, isDark() ? 'dark' : 'light'); } catch (e) {}
            label();
            // Charts that are already drawn keep their old colors, so reload those pages
            if (window.Chart && Chart.instances && Object.keys(Chart.instances).length) location.reload();
        });

        label();
        document.body.appendChild(btn);
    });
})();
